# Security Onion on SN-3100

## Installing Bare Metal Security Onion

!!! warning
    There is a chance that the SN-3100 may need to be wiped using gParted prior to installing Security Onion. Follow [this guide](./Clear%20SN-3100%20Disks.md) for instructions on how to complete this.
    
1. Plug a bootable drive with the latest version of security onion into the SN-3100
2. Log into the IPMI of the SN-3100, select the power button on the right and select "Power Reset" then apply
3. Refresh your browser and it will prompt you to login again. Do this and then proceed to "Remote Console" on the left, then select "Launch Console" on the next page
4. When the console window opens, select the keyboard icon on the bottom left of the screen. Spam the [F11] key on the pop up keyboard until you see the screen say "Invoking boot menu" on the bottom left
5. When the boot menu loads, select the "Generic Mass Storage" option. This will boot into the security onion OS. Wait until it loads
6. Type "nvme0n1" (Or whatever the smaller drive is) for the OS filesystem
7. Type "no" to the next prompt asking if you'd like to use the same device for NSM storage
8. Type "nvme1n1" (Or whatever the larger drive is) for the NSM storage
9. When prompted with the "ALL DATA WILL BE LOST" warning, type 'yes' to proceed
10. Enter an admin username and password (Note: Enter whatever the agreed upon schema is for the username and password)
11. Let the setup scripts run
    !!! note
        The setup scripts may take 5-10mins. Go take a well earned break.
12. After the setup scripts finish hit [enter] on the prompt to reboot security onion. Once the device reboots, remove the bootable drive
13. After it reboots, there will be a prompt to login. Login and you will be met with a prompt that says "Welcome to Security Onion Setup". Select "Yes" to continue.
14. Hit [enter] on install
15. On the next page, scroll to "DISTRIBUTED" and hit [enter]
16. Select "Existing Deployment"
17. Select "SENSOR" and hit [enter]
18. Give this sensor a host name
19. A description is not required for the purposes of the install. Add one if it is desired
20. Select "eno1" for the management NIC/Port
21. Select "static" for configuration and input the IP address for the manager (ex: 10.83.69.21/24). Enter the default gateway (ex: 10.83.69.1) and enter the DNS Server IP (ex: 10.83.69.53). Enter the domain (ex: domain.local). Select okay to continue.
22. Enter the Security Onion manager's hostname
23. Enter the Security Onion manager's IP address
24. If you have not yet run the so-firewall rule on the manager, a box will pop up. Run this command on the manager's command line:
```bash
sudo so-firewall-minion --role=SENSOR --ip=<YOUR SENSOR IP>
```
25. Return to the sensor and select "Yes" on the retry connection prompt
26. Select all the eno interfaces to add them as monitor interfaces. Do not add the enp0s.... interface. This is the IPMI.
27. Confirm your settings on the next page and hit [enter]
28. Let the setup scripts run (AGAIN?!)
    !!! note
        Setup scripts for the sensor dont take long. Maybe 5mins.
28. Once the scripts are done, your security onion install should be complete! Return to the web interface and accept this node on to the grid.

## Security Onion extra steps

### Expand the LVM disk for Security Onion

!!! warning inline end "Pay attention to devices"
    The example uses `/dev/sdc` and `/dev/sdd` which are the defaults on SN-3000, but pay attention not overwrite existing LVM.

```bash
sudo lvm
>pvcreate /dev/sdc /dev/sdd
>lvmdiskscan -l
>vgdisplay
>vgextend nsm /dev/sdb
>lvdisplay
>lvextend -l +100%FREE /dev/nsm/nsm
>exit
sudo xfs_growfs /dev/nsm/nsm
```

!!! tip "pvcreate fails"
    If `pvcreate` fails with the error *pvcreate cannot use disk device is partitioned* use `wipefs` on the device first.
    `wipefs -a /dev/sdc /dev/sdd`

### A sensor joining the grid troubleshooting

If a minion failed to join the grid (or previously existed) it cannot join with the same name; a salt key exists with that name already.

Determine the hostname for all the minions in the grid by logging into the Security Manager CLI.

- Display all known keys: `sudo salt-key -L`
- If a key exist for the minion name that is failing to join - delete it: `sudo salt-key -d {hostname}_sensor`
