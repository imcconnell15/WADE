## Security Onion Installation

1. Download/Copy the latest Security Onion ISO to the analyst laptop 
2. Go to the ESXi/VCSA web interface to proceed with installation
3. Select "virtual machines" tab on the left side of the screen  
4. Click "create/register VM"  
5. Select "create a new virtual machine" and hit next  
6. Create a name for the VM (example: "so-manager")  
7. Change the "Guest OS Family" to Linux 
8. Change the "Guest OS Version" to "Oracle Linux 9 (64-bit)" or later and click next  
9. Select the largest datastore and click next.  
    !!! info "Largest Datastore"
        After ESXi installation the additional datastores must be created.  For this VM installation the datastore should have already been created and do not select the NVMe datastore where ESXI is installed.  The NVMe datastore should be around 3TB and the largest datastore should be much bigger, along the lines of 110TB.
10. Reference the [Resource Requirements](../Resource%20Requirements.md) to see what resources you need to assign this VM
11. Select the drop down for "Hard Disk 1" and select "thin provision"  
	!!! warning "Do Not Skip Step 11"
12. Change "Network Adapter 1" to the port group associated with your LAN
13. Set "CD/DVD Drive 1" location "to Datastore ISO" and locate or upload your Security Onion ISO to the datastore
14. Select "Continue", then verify your settings on the next page and select "Finish"
15. Power on and open the VM in your choice console
16. Select the first security onion version and wait for it to boot
17. When prompted with the "ALL DATA WILL BE LOST" warning, type 'yes' to proceed
18. Enter an admin username and password (Note: Enter whatever the agreed upon schema is for the username and password)
19. Let the setup scripts run
    !!! note "Note"
        The setup scripts may take 5-10mins. Go take a well earned break.
21. After the setup scripts finish, hit [enter] on the prompt to reboot security onion
22. After it reboots, there will be a prompt to login. Login and you will be met with a prompt that says "Welcome to Security Onion Setup". Select "Yes" to continue.
23. Hit [enter] on install
24. On the next page, scroll to "DISTRIBUTED" and hit [enter]
## Manager Install

1. Select "New Deployment"
2. If you intend to build a search node(s), select "MANAGER". If you intend for this to be a standalone manager, select "MANGERSEARCH"
3. Type "AGREE" and hit [enter] on the next page
4. For "How should this manager be installed?", choose Standard (Unless you know this instance will need to be airgapped)
5. Give the manager a hostname
    !!! note "Note"
        It is important to remember the hostname of the manager, as you will need this to set up all search nodes and sensors.
6. A description is not required for the purposes of the install. Add one if it is desired
7. Select "ens192" for the management NIC/Port
8. Select "static" for configuration and input the IP address for the manager (ex: 10.83.69.21/24). Enter the default gateway (ex: 10.83.69.1) and enter the DNS Server IP (ex: 10.83.69.53). Enter the domain (ex: domain.local). Select okay to continue.
9. If there is internet to the machine, then select to install Direct method (unless you know you need a proxy).
10. Accept the default docker IP range
11. Enter an email address for the admin account (i.e. admin@domain.cpt)
12. When prompted "How would you like to access the web interface?", select "IP"
13. Select "Yes" to allow access to the web interface
14. Enter your user subnet to allow access to the web interface (i.e. 10.83.69.0/24)
    !!! info "so-allow"
        If you have multiple subnets that need access to the web interface, you will have to run the `so-allow` command at a later time to give access to these other subnets.
15. Select whether or not you want to allow SOC Telemetry (It is recommended to not allow this)
16. Confirm your settings on the next page and hit [enter]
17. Let the setup scripts run (AGAIN?!)
    !!! note "Note"
        This time, the setup scripts run even longer, roughly 30-40min. Go take another well earned break!
18. Once the scripts are done, your security onion install should be complete!
## Search Node Install

1. Select "Existing Deployment"
2. Select "SEARCHNODE" and hit [enter]
3. Give this search node a host name
4. A description is not required for the purposes of the install. Add one if it is desired
5. Select "ens192" for the management NIC/Port
6. Select "static" for configuration and input the IP address for the manager (ex: 10.83.69.21/24). Enter the default gateway (ex: 10.83.69.1) and enter the DNS Server IP (ex: 10.83.69.53). Enter the domain (ex: domain.local). Select okay to continue.
7. Enter the Security Onion manager's hostname
8. Enter the Security Onion manager's IP address
9. If you have not yet run the so-firewall rule on the manager, a box will pop up. Run this command on the manager's command line:
```bash
sudo so-firewall-minion --role=SEARCHNODE --ip=<YOUR SEARCHNODE IP>
```
10. Return to the search node and select "Yes" on the retry connection prompt
11. Confirm your settings on the next page and hit [enter]
12. Let the setup scripts run (AGAIN?!)
    !!! note "Note"
        Setup scripts for the search node dont take long. Maybe 5mins.
13. Once the scripts are done, your security onion install should be complete!
## Web GUI Steps Post Install

### Modifying PCAP Storage Limits
        
1. Login to the web interface and go to Administration>Configuration
2. At the top, hit the options drop down and turn on "Show all configurable settings, including advanced settings."
3. Scroll to PCAP>config>diskfreepercentage and change all of the sensors to 10 and save.
4. Scroll to PCAP>config>maxdirectoryfiles and change this to 9,999,999 or some very large number
### Adding Nodes to the Grid

1. Log into the web interface and on the left, click on Administration>Grid Members
2. Under "Pending Members", select review next to any minions you'd like to add to the grid
3. On the pop up, select "Accept" and this minion will now be added to the grid
