# Clear SN-3100 Disks

1. Plug a bootable drive with gParted on it into the SN-3100
2. Log into the IPMI of the SN-3100, select the power button on the right and select "Power Reset" then apply
3. Refresh your browser and it will prompt you to login again. Do this and then proceed to "Remote Console" on the left, then select "Launch Console" on the next page
4. When the console window opens, select the keyboard icon on the bottom left of the screen. Spam the [F11] key on the pop up keyboard until you see the screen say "Invoking boot menu" on the bottom left
5. When the boot menu loads, select the inserted USB to boot from. This will boot into the gParted OS. Wait until it loads
!!! note "Note"
	The name of the bootable drive should be either "Generic Mass Storage" or "USB Disk". Something along these lines.
6. When it boots to the first page with the CDs background, just hit [Enter]
7. On the next 3 prompts, accept the default options. Hit [Enter] 3 times
8. When gParted boots, right click the desktop and select `Terminals>lxterminal with root privileges`
9. Run the following command to wipe the two nvme drives:
```bash
wipefs -af /dev/nvme0n1 /dev/nvme1n1
```
!!! tip "Drive Names"
	Verify the drive names by checking the gParted GUI app. There's a drop down in the top right that lists all drives. Make sure you don't wipe your bootable drive!
10. The drives should now be wiped. Run the `reboot` command and remove the drive.