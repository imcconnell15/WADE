# SN-3100 Configuration

## Always On Power Configuration

1. With either monitor and keyboard or the KVM attached press the power button to turn on the SN3000
2. Press delete key repeatedly once the Supermicro splash screen appears
      - Once the "Entering Setup" message appears, stop pressing the delete key
3. Go to the “Advanced” Tab and select “Boot Feature”
4. Go down to “Restore on AC power loss” and change it to power on.

## Confirm and set Boot options

1. From the main BIOS screen move over and highlight **BOOT**
2. Change **Boot mode select** to **UEFI**
3. Ensure that **UEFI Hard Disk** is set at **Dual Boot Option #1**

## IPMI Configuration

1. From the main BIOS configuration screen, using the arrow keys, go to the IPMI tab.
2. Hit enter on "BMC Network Configuration"
3. Hit enter on "Update IPMI LAN Configuration" and change it to "yes"
4. Using the arrow keys, go down to "Configuration Address Source" and change it to "Static"
5. Go down to "Station IP Address" and change it to whatever IP scheme you decide for the IPMI ports ( for example X.X.X.240 ).
6. Go down to "Subnet Mask" and change it to 255.255.255.0
7. Go down to "Gateway IP Address" and change it to the default gateway for the network
8. Press "F4" to save and exit the boot menu
9. Reboot the device

## IPMI Access

1. In a web browser go to the IP you set for IPMI and type in the credentials (U:ADMIN, P:ADMIN are the default)
2. Click on Remote Console in the left column
3. Select "HTML5", "Set Mode to Absolute (Windows, Ubuntu, RH6.x later)" and "Launch Console"
4. Wait for interface to appear and click on the keyboard button on the bottom of the screen

## Dedicated IPMI

1. After IPMI has been configured, open a web browser and login to the IPMI web access for the SN3000
2. Select the Configuration tab on the top menu and select Network from the list on the left
3. Scroll down to **LAN Interface** - ensure that **Dedicated** is selected from the drop down
4. Scroll to the bottom and click save
