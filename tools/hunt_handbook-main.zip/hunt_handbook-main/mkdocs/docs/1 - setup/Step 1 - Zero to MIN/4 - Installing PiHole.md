# Installing PiHole

## From the Command Line

1. A basic Ubuntu VM on the ESXi server is required before starting to install PiHole. Ensure the [setting up an Ubuntu VM](./6%20-%20Installing%20Ubuntu%20Server.md) is completed prior to starting. Reference the [Resource Requirements](../Resource%20Requirements.md) to see what resources you need to assign this VM.
!!! warning
	When setting up the ubuntu VM, ensure that this is the one and only VM where you set the DNS server to 9.9.9.9
2. Once the server is up, run the curl command to install pihole:
```bash
curl -sSL https://install.pi-hole.net | bash
```
3. Once the script runs, continue past the first two pop-up boxes and confirm you are using a static IP on the next three windows. 
4. Select your DNS provider (Cloudflare is always a solid choice)
5. Select 'No' on the prompted block lists (We'll add our own in a future step)
6. Select 'Yes' on installing the Admin Web Interface, and 'Yes' for the PHP modules on the next window
7. Decide whether or not to enable query logging. (It is usually best to enable logging)
8. Once the setup is finished running, we need to create a password for the web GUI:
```bash
# This command allows you to create a password for the admin web account
pihole -a -p
```

## On to the Web GUI

1. You can now reach the web interface via `http://<IP ADDRESS>/admin`. Once logged in, proceed to step 10.
2. It is suggested to add adlists to pihole so that malicious/phishing/ad domains are blocked. This can be done via the 'Adlists' tab on the left menu
3. [This website](https://firebog.net) has a pretty solid collection of adlists. I'd recommend adding all the ones that are verified with a green check mark to the pihole adlists. Copy and paste the URLs into pihole and hit the 'Add' button
4. Once all desired adlists have been added, return to the command prompt and run this command:
```bash
pihole -g
```
5. Custom DNS resolution can be done through the 'Local DNS > DNS Records' dropdown on the left.
6. Select 'Settings' on the left and go to 'DNS' on the top
7. Under 'Interface Settings' on the right, change this option to 'Respond only on interface ens160'.
8. Scroll down a bit further and look for 'Rate Limiting'. Change this limit to 10000. There are applications that need a higher limit or they will be blocked by this setting.