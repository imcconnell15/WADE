# Installing Ubuntu Server

1. Download/Copy the latest Ubuntu LTS Live Server release ISO to the analyst laptop 
2. Go to the ESXi/VCSA web interface to proceed with installation
3. Select "virtual machines" tab on the left side of the screen  
4. Click "create/register VM"  
5. Select "create a new virtual machine" and hit next  
6. Create a name for the VM (example: "Splunk")  
7. Change the "Guest OS Family" to Linux  
8. Change the "Guest OS Version" to "Ubuntu Linux (64-bit)" and click next  
9. Select the largest datastore and click next.  
    !!! info "Largest Datastore"
        After ESXi installation the additional datastores must be created.  For this VM installation the datastore should have already been created and do not select the NVMe datastore where ESXI is installed.  The NVMe datastore should be around 3TB and the largest datastore should be much bigger, along the lines of 110TB.
10. Reference the [Resource Requirements](../Resource%20Requirements.md) to see what resources you need to assign this VM. It is based on what service you intend to run.
11. Select the drop down for "Hard Disk 1" and select "thin provision"  
	!!! warning "Do Not Skip Step 11"
12. Change "Network Adapter 1" to the port group associated with your LAN
13. Set "CD/DVD Drive 1" location "to Datastore ISO" and locate or upload your ubuntu ISO to the datastore
14. Select "Continue", then verify your settings on the next page and select "Finish"
15. Power on and open the VM in your choice console
16. Hit "Enter" to begin installation of Ubuntu Live Server
17. Select "English" for the language and keyboard settings
18. If prompted, update to the newest installer
19. Continue with the default keyboard configuration
20. Continue with the default type of installation (Ubuntu Server)
21. Select the interface for the VM and edit the "IPv4" configuration. Change the method to "manual"
	1. Subnet: Your Subnet w/CIDR (i.e. 10.83.69.0/24)
	2. Address: The actual IP address of this server
	3. Gateway: Firewall IP
	4. Name Servers: Either your firewall IP, or PiHole IP if you intend to use it
	5. Search Domains: Your domain name (i.e. domain.cpt)
22. Skip the proxy setup page
23. Use the default mirror for the mirror input page
24. Continue with the default settings on the "Guided storage configuration" page
25. On the "Storage configuration" page, scroll to the top. Under "MOUNT POINT", select the "/" mount point and select "Unmount"
26. Scroll down under "DEVICE" and select "ubuntu-lv" then select "Edit"
	1. Change the size to spamming 9 in front of this number, then hit the down key to let it auto-format
	2. Once the number auto-formats to the max size, remove the last number (i.e. if it is 497.996G, remove the 6 to make it 497.99) then hit down again to let it reformat
	3. On the "Mount" drop down, remount it to the "/" mount point and hit "Save", then "Done" on the "Storage configuration" page
    !!! note "Ubuntu-lv Bug"
        There is a bug with the auto formatting of the max drive size of the lv. This is why we its crucial to remove the final number and let it reformat again. If this step is skipped, ubuntu will not install properly.
27. When the "Confirm destructive action" pops up, select "Continue"
28. On the "Profile configuration" page, enter your desired username, hostname, and password, then select "Done"
29. Skip the "Upgrade to Ubuntu Pro" page
30. Select "Install OpenSSH server" on the next page and then "Done"
31. On the "Featured server snaps" page, just select "Done"
32. Wait for the OS to install. Once it's done, a new option will pop up at the bottom that says "Reboot Now". You will get a cdrom error on the next page. Just disregard this and hit enter. Your installation is now complete!