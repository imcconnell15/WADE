# MIN Setup

## Download MIN

!!! note "Download min"
    MIN is an N-CPT83 project that is available at `code.levelup.cce.af.mil` if you have access please download the project there.  If you do not have access ask some who does for the latest copy.  It is preferred to download the file each time to ensure the latest updates are included.

1. Ensure that you have the “min.tar” file on a hard drive or on the kit laptop.

## Background

- A basic Ubuntu VM on the ESXi server is required before starting to install MIN. Ensure the [setting up an Ubuntu VM](./6%20-%20Installing%20Ubuntu%20Server.md) is completed prior to starting. Reference the [Resource Requirements](../Resource%20Requirements.md) to see what resources you need to assign this VM.
- Ensure **easy-rsa** is installed through server package manager.

!!! note
    The base domain must be set is very important to get correct during installation.  If the base domain is incorrectly provided, delete the MIN folders and start over.
## MIN Install on Ubuntu VM in ESXi

1. [Install an Ubuntu VM](./6%20-%20Installing%20Ubuntu%20Server.md) on ESXi and log in to the Ubuntu VM that will be used for MIN
2. From the host machine, scp the min.tar to the MIN vm:

    ```bash
    scp "min-master.tar" <MIN user>@<MIN IP>:/home/<MIN user>
    ```

3. Install Docker - Use `wget` to retrieve and run a docker install script at the same time.

    !!! warning "Internet Access Required"
        The VM will need internet access to run a wget command which will install docker and all dependencies with the following script. If the full command doesn't work download the `install_docker.sh` file, make it executable (`chmod +x`) and run the local copy.

    ```bash
    wget -O - install_docker.sh https://raw.githubusercontent.com/deathnmind/satus-velox/main/scripts/install%20scripts/install_docker.sh | bash
    ```

    !!! warning "Spaces!"
        The above `wget` must have the correct options: that is `wget` SPACE `-O` (Capital O) SPACE `-` SPACE

- Add current user to docker group: `sudo usermod -aG docker $USER`
- Log out and log back in so that the user will be put into the correct group for executing the `docker-compose` command with the correct permissions

4. Uarchive the *min.tgz* file

    ```bash
    tar -xvf min-master.tar
    ```

5. Change directory into the min folder and change the permissions of the setup.py file

    ```bash
    cd min-master
    chmod +x setup.py
    ```

6. Run the setup.py file and establish the domain to be used for all services on the kit

    ```bash
    ./setup.py -d <desired base domain>
    ```

    !!! example "example domain"
        `./setup.py -d domain.local`

    - When prompted enter the following:
        - sudo users password
        - LDAP admin password
        - LDAP readonly password
        - CA key passphrase

    !!! note "Note"
        These passwords should be unique

7.  Wait for the `docker-compose` command to finish (which could take some time).

    ```bash
    sudo docker-compose up -d
    ```

8. In a web browser go to: `https://min.<configured domain>/links`.

    !!! note "Troubleshooting DNS"
        If you are unable to reach the MIN links page try the following commands:
  
    Windows:
  
      ```cmd
      nslookup min.<domain>
      ```
  
    Linux:
  
      ```bash   
      dig min.<domain>
      ```
  
    - If the no IP is return check your systems DNS server
    - If DNS server is correct move to step 9 to create a DNS record
### Description

This is a docker compose config designed to build a basic util server providing the following services:

- OpenLDAP
- Reverse Proxy
- Self service password rest
- gostatic
- phpLDAPadmin
- IPchecker3000
- IPtoASN
- Dashmachine
- Rocketchat
- CyberChef
- N8N
- MKDocs

All services are designed to sit behind the reverse proxy, except LDAP and LDAPS, and should be redirected to HTTPS.

### Default Credentials

| Service | Username | Password |
| --- | --- | --- |
| dashmachine | admin | admin |
| thehive4 | admin@thehive.local | secret |
| MISP | admin@admin.test | admin |
| N8N | thehive | thehive |

### Reverse Proxy mappings

| Scheme | Forward Hostname / IP | Forward Port |
| --- | --- | --- |
| http | dashmachine | 5000 |
| http | gostatic | 8043 |
| http | phpldapadmin | 80  |
| http | nginxproxymanager | 81  |
| http | selfservicepassword | 80  |
| http | thehive4 | 9000 |
| http | rocketchat | 3000 |
| http | n8n | 5678 |
| http | mkdocs | 8000 |
| http | iptoasn | 53661 |

### IPtoASN

IPtoASN is a webservice to map IP addresses to AS information. It uses a tsv downloaded from iptoasn.com.

Example usage:

In this example we are getting the ASN information for the IP address 8.8.8.8

  ```bash
  curl 127.0.0.1:53661/v1/as/ip/8.8.8.8
  ```

Example Output:

  ```json
  {"announced":true,"as_country_code":"US","as_description":"GOOGLE","as_number":15169,"first_ip":"8.8.8.0","ip":"8.8.8.8","last_ip":"8.8.8.255"}
  ```

### Creating a Server certificate with easy-rsa

If additional server certifcates are needed for services that are not a part of min.

  ```bash
  ./easyrsa build-server-full links.example.com nopass
  ```

When Prompted enter the CA password

### MIN Directory Structure

???- note "Complete directory structure."

    ```shell
    .
    ├── configs
    │   ├── cortex
    │   │   └── application.conf
    │   ├── self-service-password
    │   │   └── config.inc.php
    │   └── thehive
    │   └── application.conf
    ├── data
    │   ├── cassandra
    │   │   └── data
    │   ├── dashmachine
    │   ├── elasticsearch
    │   │   ├── data
    │   ├── gostatic
    │   │   ├── ca.crt
    │   │   ├── cyberchef
    │   │   └── ip2asn-combined.tsv.gz
    │   ├── n8n
    │   │   └── workflows
    │   ├── openldap
    │   │   ├── certs
    │   │   │   ├── ca.crt -> /container/service/:ssl-tools/assets/default-ca/default-ca.pem
    │   │   │   ├── dhparam.pem
    │   │   │   ├── ldap.crt
    │   │   │   └── ldap.key
    │   ├── postgres
    │   ├── proxy
    │   │   ├── backend-not-found.html
    │   │   ├── default.conf
    │   │   ├── includes
    │   │   │   ├── proxy.conf
    │   │   │   └── ssl.conf
    │   │   └── ssl
    │   │   ├── min.test.internal.crt
    │   │   └── min.test.internal.key
    │   ├── rocketchat
    │   └── thehive
    ├── docker-compose.yml
    ├── How_Tos
    │   ├── nextcloud_ldap.md
    │   └── rocketchat_ldap.md
    ├── README.md
    ├── scripts
    │   └── enable\_hive\_webhooks.py
    ├── setup.py
    ├── templates
    │   ├── application.cortex.conf.tmp
    │   ├── application.thehive.conf.tmp
    │   ├── config.inc.php.tmp
    │   ├── config.ini.tmp
    │   ├── default.conf.tmp
    │   ├── docker-compose.yml.tmp
    │   ├── env.tmp
    │   ├── proxy.conf.tmp
    │   ├── ssl.conf.tmp
    │   └── traefik_dynamic.yml.tmp
    ├── <domain>_CA
    │   ├── easyrsa -> /usr/share/easy-rsa/easyrsa
    │   ├── openssl-easyrsa.cnf
    │   ├── pki
    │   │   ├── ca.crt
    │   │   ├── certs\_by\_serial
    │   │   │   └── FE3C967E265CC1A73C353D4536B29460.pem
    │   │   ├── issued
    │   │   ├── openssl-easyrsa.cnf
    │   │   ├── private
    │   │   │   ├── ca.key
    │   │   │   └── min.<domain>.key
    │   │   ├── renewed
    │   │   │   ├── certs\_by\_serial
    │   │   │   ├── private\_by\_serial
    │   │   │   └── reqs\_by\_serial
    │   │   ├── reqs
    │   │   ├── revoked
    │   │   │   ├── certs\_by\_serial
    │   │   │   ├── private\_by\_serial
    │   │   │   └── reqs\_by\_serial
    │   │   ├── safessl-easyrsa.cnf
    │   │   ├── serial
    │   │   └── serial.old
    │   ├── vars
    │   └── x509-types -> /usr/share/easy-rsa/x509-types
    └──
    ```
