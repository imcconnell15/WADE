# Install VCSA

## VCSA Download

1. Download the desired VCSA ISO by logging into VMware Customer Connect
2. Navigate to Products and Accounts > All Products
3. Find VMware vSphere and click View Download Components
4. Select a VMware vSphere version from the Select Version drop-down
5. Select a version of VMware VCenter Server and click Go to Downloads
6. Download the vCenter Server Appliance ISO image
7. Recommend to confirm that the md5sum is correct by using an MD5 checksum tool

## VCSA Installation

!!! warning "Mounting the ISO"
    If 7-zip is installed on the Windows laptop (ie the standard image) it may be the default application to open ISO files. 7-zip will not allow the ISO to be mounted. To mount the ISO, right click on the ISO file and select Open With > Windows Explorer. This will mount the ISO and allow the installation to proceed.

1. Mount the ISO image (double clicking on the ISO)
2. Open the mounted ISO and navigate to the vcsa-ui-installer folder
3. Select the Win32 folder
4. Select the Installer application prompting the VCSA Installer Module
5. Click on Install
6. Click Next on the Introduction Menu
7. Accept the license agreement and Click Next
8. Type in the desired credentials for the vCenter Server Deployment Target (IP Address, Port 443, User Name, Password) Click next
9. Certificate Warning prompt will display. Click Yes
10. Type in your vCenter Server VM Name (VMware vCenter Server), set root password, click Next
11. Select Deployment size (Tiny) and Storage size (Default) Click Next
12. Select Datastore menu enable radio button “Install an existing datastore accessible from the target host, Check the “show only compatible datastores” box, and Check the “Thin Disk Mode” box. Click Next
13. Configure Network Settings menu:
    1. Network: VM Network
    2. IP Version: IPv4
    3. IP Assignment: Static
    4. FQDN: LEAVE BLANK
    5. IP Address: desired IP
    6. Subnet Mask: desired subnet mask
    7. Default Gateway: desired Default Gateway
    8. DNS Servers: desired DNS
    9. Common Ports: HTTP: 80
    10. Click Next
14. Review and Click Finish
15. Click Continue to conclude Stage 1 and begin Stage 2

## VCSA Installation Stage 2

1. Click Setup
2. Introduction: Click Next (setting up the vCenter Server)
3. vCenter Server Configuration
    1. Time synchronization mode: Synchronize time with the ESXi host
    2. SSH access: Disabled (unless required for specific mission use)
    3. Click Next
4. SSO Configuration
    1. Enable the “Create a new SSO domain” radio button
    2. Single Sign-On domain name: desired domain name (DO NOT USE LDAP DOMAIN)
    3. Single Sign-On username: administrator (or whatever you designate)
    4. Single Sign-On password: select a password (and confirm)
    5. Click Next
5. Configure CEIP: Can be joined at a later time if needed (Click Next)
6. Warning Prompt displayed: “You will not be able to pause or stop the install from completing once its started…” Click Ok
7. Once install is complete, Click Close

## VCSA Configuration

1. Login to vSphere (use administrator@WhateverDomainYouChose during the VCSA Installation Wizard earlier)
2. On the vSphere Client home screen (Summary tab should be selected already) right-click the IP Address in the left pane and select New Datacenter
3. Name: Datacenter (Consider meaningful naming convention for multiple data centers if you intend to create more than one)
4. Returning to the Summary Tab right-click on the newly created Datacenter and click “New Cluster”
5. New Cluster Basics:
    1. Name: Cluster (Consider a meaningful naming convention for multiple clusters. They could be used for multiple sites using connectivity such as a VPN to VCSA server)
    2. Location: Datacenter (pre-filled)
    3. Check the "Disable" for image management
    4. Click Next
    5. Select the most recent ESXi version 7 update
    6. Click Next
6. Returning to the Summary Tab Right-Click on the Datacenter in the left pane again and click “Add Hosts” ( For now, just the ESXi (all existing or future VMs will automatically be clustered beneath ESXi). Hosts must be added to the datastore/cluster for VCSA to manage)

    !!! warning inline end "Install License"
        Prior to being able to add the hosts to the cluster the licenses must be installed.  You can continue with evaulation licenses and then add the licenses later.  The licenses can be added at any time.

7. Add new and existing hosts to your cluster:
    1. Enter IP Addresses for each host that you’d like to add along with username and password (Note that Hosts can be added using differing credentials or all the same credentials.) (To mediate security concerns, you can disable the ability to log directly into the host rather than use VCSA)
    2. Host Summary: Click Next
    3. Review and Click Finish
    4. Hosts will appear within the Cluster once complete
8. Returning to vSphere home Click on the hamburger menu at the top left (next to vSphere Client)
9. Select Administration
10. In the left pane select Licenses and Click “Add”
    1. Enter License Keys (Able to add multiple licenses at a time and of different variations (ESXi6,7,8, VCSA6,7,8, etc.)
        1. Obtain licenses from 83 CPT Software Manager (POC: Aaron Wild)
    2. Edit License Names to whatever you’d like (if using multiple licenses, a naming convention to differentiate would be recommended)
    3. Ready to Complete: Click Finish
11. Returning to the License Menu Click on the hamburger menu at the top left (next to vSphere Client)
12. Select Inventory
13. In the left pane right-click the top-level IP Address and Select “Assign License”
14. The licenses that can be applied to the server will appear. Select the appropriate license and Click Ok
15. Back at the Inventory Menu right-click each host within the Cluster Tree and Select Assign License (one at a time)
Collapse

## VM VMotion Configuration

1. From Vsphere main page, ensure that "Host and Clusters" are select in the left side bar.
2. Expand the datacenter and cluster (if they exist) and select an ESXi host and in the right-pane Select the Configure Tab
3. Under the **Networking** category in the configure bar select **VMkernel adapters" -**"vmk0"** (the default) should show under VMkernel adapters
4. Click the three dots next to **vmk0** and choose edit
5. From the **vmk0 - Edit Settings** options that open - ensure that under *Enabled services* that **vMotion** is checked
6. Click OK
7. Repeat the aboves steps for the **vmk0** adapter on all ESXi hosts.

## Trust Root CA

1. Root CA Cert
    1. On the “Getting started” screen when navigating to your Server IP Address you can see in the URL window that it is not secure
    2. On the right hand side of the page at the bottom link is a “Download trusted root CA Certificates”
    3. Right-Click and save link as.. (to your desktop)
    4. Install the Root CA Cert
        1. Click on Start > Run > Type MMC > Click OK
        2. Click on File > Add/Remove Snap-in
        3. Click on Certificates > Add
        4. Click on User Account > Finish
        5. Expand Certificates > Trusted Root Certification Authority > Certificates
        6. Right Click on the right pane > All Tasks > Import
        7. Complete the Import Wizard (Browse to the certificate file, Click Next, Select Trusted Root Certification Authorities, Click Next, then Finish
        8. Click “Yes” on the security warning prompt
