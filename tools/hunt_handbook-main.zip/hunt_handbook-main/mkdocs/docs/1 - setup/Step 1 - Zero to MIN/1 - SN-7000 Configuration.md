# SN-7000 Configuration
## Raid Configuration

### Enter BIOS Raid Configuration

1. With either monitor and keyboard or the KVM attached press the power button to turn on the SN7000
2. Press delete key repeatedly once the Supermicro splash screen appears
      - Once the "Entering Setup" message appears, stop pressing the delete key
3. Use arrow keys to go to the "Boot" tab at the top of the menu
4. Ensure that the "Boot Mode Select" is set to "UEFI", if not hit enter and change to "UEFI"
5. Use arrow keys to go to the "Advanced" tab, go down to "PCIe/PCI/PnP Configuration" and hit "enter"
6. Go down to "NVMe Firmware Source" and ensure it is set "AMI Native Support", if not hit enter and change.
7. Hit "escape" to go back to the advanced tab (Note: may have to reboot system be sure to save changes)
8. Select the raid card at the bottom of the menu ("BROADCOM \<MegaRAID...\> is an example)

### Mark Unconfigured Drives Good

!!!warning "Unconfigured Drives"
      Before a drive can be added to the RAID configuration the Unconfigured state must be Unconfigured Good.  The default is the disk drives are in JBOD configuration.  Follow the steps below to change the drives to Unconfigured Good.

1. If the drives are in JBOD configuration
2. Go down to "View Server Profile" and hit enter
3. Go down to "Drive Management" and hit enter
4. Select a drive, hit enter on "Operation" and change it to "Unconfigured Good"
5. hit go
6. change "Confirm" to Enabled
7. Hit enter on "Yes"
8. Repeat steps 4-7 for the remaining drives
9. Verify all drives show unconfigured goods

!!! note "Unconfigured Good"
      The drives will not show "Unconfigured Good" after the change until you escape back to previous menu in advanced and then select "Drive Management" again.  They should all show Unconfigured good after that.

### Configuring the RAID-10

RAID-10 is there desired RAID level because of the faster disk read times when compared to RAID 5 OR RAID 6.  RAID 5 is redundant to one disk failure and provides more space, but RAID-10 is redundant for more disk failure and the read speed increase by a multiplier for number of disk used.

1. Go to the Broadcomm RAID main menu and under "Actions" select "Configure"
2. Select "Create Virtual Drive" and set it to "RAID10" for the "RAID Level"
3. Under select Span(s) "Span 0" should appear, choose "Select Drives", select either the odd or even number drives to add to the Span (i.e. Drive 0,2,4,6)
      - Hit enter on the drive to add it to the Span
      - Change to "Enabled" and hit enter to confirm
4. At the very bottom choose "Apply" to save the "Span0" configuration
5. Select "Add more Spans" to create another Span and make it "Span1"
6. Select the other half of the drives not used by "Span0" and add them to "Span1" (i.e. 1,3,5,7)
7. At the very bottom choose "Apply" to save the "Span1" configuration
8. Once the 2 Spans have been created on the "Virtual Drive Management" menu, select "Save Configuration" at the very bottom
      - Change "Confirm" to Enabled
      - Hit enter on "Yes"
9. Go back to the "View Server Profile" menu and select "Virtual Drive Management"
10. Verify that the newly created virtual drive is up and is using "RAID10"

## Always On Power Configuration

1. From the main BIOS screen, go to the “Advanced” tab and select “Boot Feature”
2. Change “Restore on AC power loss” to “Power On”

## Intel NIC Configuration

!!!note "Option may not be available"
      The option to change the port option may not be available if the BIOS is not updated to the latest version.  If the option is not available skip this section.

1. From the main BIOS screen, go to the “Advanced” tab and select the first listing for "Intel Ethernet Network Adapter E810-C-Q2"
2. There should a option for "Device Level Configuration" select this and hit enter
3. Port Option Configuration should be the next option to select, hit enter
4. Hit enter on "Port Option" and change to **"Option 0: 2x1x100G"**

## IPMI Configuration

1. From the main BIOS screen, go to the IPMI tab.
2. Hit enter on "BMC Network Configuration"
3. Hit enter on "Update IPMI LAN Configuration" and change it to "yes"
4. Using the arrow keys, go down to "Configuration Address Source" and change it to "Static"
5. Go down to "Station IP Address" and change it to whatever IP scheme you decide for the IPMI ports ( for example X.X.X.240 ).
6. Go down to "Subnet Mask" and change it to 255.255.255.0
7. Go down to "Gateway IP Address" and change it to the default gateway for the network
8. Press "F4" to save and exit the boot menu
9. Reboot the device

## IPMI Access

1. In a web browser go to the IP you set for IPMI and type in the credentials (U:ADMIN, P:ADMIN are the default)
2. Click on Remote Console in the left column
3. Select "HTML5", "Set Mode to Absolute (Windows, Ubuntu, RH6.x later)" and "Launch Console"
4. Wait for interface to appear and click on the keyboard button on the bottom of the screen

## Dedicated IPMI

1. After IPMI has been configured, open a web browser and login to the IPMI web access for the SN7000
2. Expand Configuration and select Network
3. Under **General** >> **LAN Interface** - ensure that **Dedicated** radio button is selected
4. Scroll to the bottom and click save
