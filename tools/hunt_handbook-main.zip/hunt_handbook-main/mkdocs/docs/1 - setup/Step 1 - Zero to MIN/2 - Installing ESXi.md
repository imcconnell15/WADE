# Installing ESXi

ESXi version needs to be ESXi **version 7 update 3r** or newer.  The kit license is only for ESXi version 7.

## ESXi Installation

Installing and Setting Up ESXi on SN-7000

!!! info "Bootable USB"
    These installation steps are completed using a USB Drive with ventoy and the ESXi iso.  The USB drive needs to be plugged into the back of the SN-7000.  The SN-7000 will boot to the USB drive and the ventoy menu will be displayed.  Select the ESXi iso from the ventoy menu to begin the installation.

!!! tip "UEFI Boot mode"
    The SN-7000 needs to be in UEFI boot mode to install ESXi, which should have been set during the RAID/Hardware configuration.

1. Press "F11" during boot to go to the boot mode selection
2. Choose the "SMI USB..." option that describe the USB device
3. Utilize the ventoy menu to select "Vmware-VMvisor-...-7.0..."
4. Choose boot in Normal Mode
5. After waiting for the initial startup scripts, hit "enter" to continue with the installation
6. Hit "F11" to accept the end user license agreement
7. Wait for the installer to scan the system, select the correct drive to install the ESXi OS (Note: for the SN-7000 it should have "NVMe" in the label for the drive)
    - If pervious ESXi and VMFS is found choose "Install ESXI and Overwrite VMFS"
8. Select a keyboard layout and language
9. Set a root password
10. Hit "F11" to confirm the install
11. After waiting for the installation, remove installation media, hit "enter" to reboot the system
12. After the reboot, hit "F2" to login to ESXi
13. Go down the menu to "Configure Management Network" Select IPv4 Configuration
14. Enable Radio Button “Set static IPv4 address and network configuration”
    1. Assign IP Address (ie 10.10.10.5)
    2. Assign subnet mask
    3. Assign default gateway
15. Returning to the Configure Management Network menu Select "VLAN (Optional)"
16. Set VLAN to 4095 (Port 4095 allows all VLANs on that port/port group)
17. Return to Configure Management Network menu Select DNS Configuration
18. Enable Radio Button “Use the following DNS server addresses and hostname”
    1. Assign Primary DNS Server (ie gateway 10.10.10.1)
    2. Alternate DNS Server – BLANK
    3. Assign hostname (FQDN ie esxi01.domain.com)
19. Return to Configure Management Network menu Select IPv6 Configuration
20. Enable Radio Button “Disable IPv6 (restart required) and Hit Enter
21. Go to "Network Adapters", and select the "vmnic" to enable (ie check box next to vmnic0)
22. Hit "Enter"
23. Hit "Esc" to return to the main menu
24. Apply changes and reboot hosts - hit "Y" to confirm

## ESXi Datastore Creation

!!! note "RAID Configuration"
    RAID configuration should be completed before continuing with the Datastore Creation steps.

!!! warning "Connection devices"
    Make sure that the correct management network is connected to the correct switch port.  The management network should be connected to the switch port that is configured for the management VLAN.  The VM network should be connected to the switch port that is configured for the VM VLAN.

!!! info "**LARGEST** Partition"
    The largest partition is the one that should be used for the datastore, should be larger than 100+TB. 

1. Login to ESXi on the SN-7000 by entering the IP address in the web browser
2. Select the "Storage" tab on the left in ESXi
3. Click on “New Datastore”
4. For “Select Creation Type” Click “Create new VMFS datastore” Click Next
5. Type a Name for the Datastore (Use a meaningful name such as Host_DriveType_Datastore_Number) Click Next
6. Under Partitioning Options use the first dropdown to select “Use Full Disk” and the second dropdown for “VMFS 6” Click Next
7. Review and verify that configurations are set correctly and click “Finish”
8. A warning prompt will display with the message “The entire contents of this disk are about to be erased and replaced with the specified configuration, are you sure” Click “Yes”
