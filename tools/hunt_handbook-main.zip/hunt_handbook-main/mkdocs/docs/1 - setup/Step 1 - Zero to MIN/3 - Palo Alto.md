!!! warning "Network Plan"
	Before beginning the firewall build, it is highly advised to have a solid network architecture plan. See the [suggested network baseline](../Network%20Architecture.md) for reference. 
## Configuring Palo Alto (Physical)

### Setting the Management IP

1. Connect a console cable to the console port on the Palo Alto, and the USB to a laptop, then open 'Device Manager'
2. Look for 'Ports (COM & LPT)'. Hit the drop down on this and check the COM port number.

!!! note
	The COM port number should be anything from COM1 - COM5. You'll need this for PuTTy.
	
3. Open up an instance of PuTTY and for connection type, select 'Serial'
4. Enter the COM number from step 2 and then hit 'Open' at the bottom of the window
5. Once the session is open, it should prompt you to log in. The default credentials are `UN: admin | PW: admin`
6. You will be prompted to change the admin password upon logging in. Set this to something secure
7. We're going to set the management IP to access the Palo Alto by the web GUI. Run the following commands:
```python
configure
set deviceconfig system ip-address <IP_ADDRESS>
```
8. If after running this command, you receive an error saying zero touch provisioning is in progress, exit the configure mode and run the following commands:
```python
exit
set system ztp disable
```
9. If you did not receive an error, proceed with the next commands. If you received the error, wait for the device to reboot and start over with the commands from step 7 and then the following commands:
```python
set deviceconfig system netmask <SUBNET_MASK>
set deviceconfig system default-gateway <GATEWAY_IP>
commit
```

!!! success
	You should now be able to access the Palo Alto web interface for management.

### Device Configuration

1. Log into the Palo Alto web interface and select the **Device** tab at the top of the page
2. Under the Management tab, click the gear wheel next to general settings:
	1. Give the device a hostname
	2. Define the base domain
	3. Choose the correct timezone
3. Under the **Services** tab, click the gear wheel next to Services:
	1. Define a primary and optionally a secondary DNS server
	2. Select the **NTP** tab and set an NTP server (us.pool.ntp.org)
4. Under the **Telemetry** tab, click the gear wheel next to Telemetry:
	1. Uncheck 'Enable Telemetry'
### Network Configuration

Navigate to the **Network** tab at the top of the page.
#### WAN

1. Select interface `ethernet1/1` to open it's settings
	1. Give this interface a description in the comment. "WAN" is fine
	2. Change the interface type to 'Layer 3'
	3. Under the **Config** tab:
		1. Change the virtual router to 'default'
		2. In the **Security Zone** drop down, create a new zone and name it "WAN". Don't worry about the other settings on this page
	4. Under the **IPv4** tab:
		1. Set the type to either Static or DHCP client, depending on the scenario. If static, ensure the IP you use is acceptable for use in the environment
	5. Click **OK** on the interface editing window
!!! warning "CIDR with Interface IP"
	When entering the interface IP be sure to enter the IP Address with CIDR (example 192.168.1.1/24)
#### LAN

Repeat the above steps for configuring the WAN on interface `ethernet1/2`, with these differences:
1. Replace "WAN" with "LAN" in all descriptions/zones
2. Optionally, apply a 'Management Profile' in the **Advanced** tab to allow access to the web interface from this port

#### Virtual Wires

1. Click on the **Virtual Wires** tab on the left
2. Click the checkbox next to the 'default-vwire' and delete this.

### Policy Configuration

Navigate to the **Policies** tab at the top of the page.

#### Security Policy

1. Delete the default 'rule1' by clicking on it and selecting '- Delete' at the bottom of the page
!!! note
	Delete the rule by clicking on the whitespace by the rule name. If a window pops up to edit the rule, close this and the rule should now be selected regardless.
2. Create a new rule by clicking '+ Add' at the bottom of the page
	1. Name the rule. This first rule should be something pertaining to allowing traffic out from the internal network
	2. If desired, give the rule a description. This is highly recommended for more complex rules
	3. Select the **Source** tab:
		1. Under source zone, select '+ Add' and add the 'LAN' zone
		2. For Source address, select 'Any'
	4. Select the **Destination** tab:
		1. Under destination zone, select '+ Add' and add the 'WAN' zone
		2. For destination address, select 'Any'
	5. Select the **Actions** tab:
		1. Ensure the Action Setting is set to 'Allow'
	6. Click **OK** to add this rule

#### NAT Policy

1. Select 'NAT' on the left menu
2. Create a new NAT rule by clicking '+ Add' at the bottom of the page
	1. Give the rule a name, such as 'NAT Internal to External'
	2. Select the **Original Packet** tab:
		1. Under source zone, select '+ Add' and add the 'LAN' zone
		2. Under destination zone, hit the drop down and select 'WAN'
	3. Select the **Translated Packet** tab:
		1. Hit the **Translation Type** drop down and select 'Dynamic IP and Port'
		2. Hit the **Address Type** drop down and select 'Interface Address'
		3. Hit the **Interface** drop down and select 'ethernet1/1' (or whatever you have your WAN interface set to)
		4. Leave the **Destination Address Translation** set to 'None'
	4. Click **Ok**

!!! success "Commit"
    Commit can be chosen at any time but it takes a while to apply.  Now would be a good time to click **Commit** at the top right of the page.

!!! tip
	You can test connectivity to the internet with the ping function located under the **Device** tab, then select the **Troubleshooting** tab on the left. Change the Select Test to ping.

## Configuring Palo Alto (Virtual)

### SN-7000 Network Configuration

1. On the back of the SN-7000, there are two ethernet NICs towards the bottom. Looking at the back, the lower left port is where the LAN cable should be plugged in, and the lower right port is where the DMZ cable should be plugged in.
2. Login to ESXi on the SN-7000 by entering the IP address in the web browser
3. Select the "Networking" tab on the left in ESXi
4. At the top of the page, select "Virtual Switches"
5. Select "Add standard virtual switch". Name this switch "DMZ" and change uplink 1 to "vmnic1" then select "Add"
6. At the top of the page, select "Port groups"
7. Select "Add port group". Name this port group "DMZ" and associate it with the DMZ virtual switch then select "Add"
8. Create another port group and name it "Managment". Use the "vSwitch0" as the virtual switch for this port group. Repeat this step for the port groups "Users" and "Services"

### Creating the VM

1. On ESXi, create a new VM and select 'Deploy a Virtual Machine from an OVF or OVA file'
2. Name the virtual machine and drop the OVA for Palo Alto (Cody has a copy of this)
3. Select the largest datastore for storage
4. Select the network for the VM (This doesnt matter. It will be changed later anyways) and make sure thin provision is selected. Continue and click **Finish** on the next page
5. Wait for the VM to power on and then open it in your console of choice
6. Log in with the credentials `UN: admin | PW: admin`

!!! warning
	The CLI of Palo Alto can be weird. If it says incorrect password, just try, try again and it will work eventually.
	
7. Change the default creds to something secure
### Setting the Management Interface

1. Enter configuration mode by running the `configure` command
2. We're going to set the management IP to access the Palo Alto by the web GUI. Run the following commands:
```python
delete deviceconfig system
set deviceconfig system ip-address <IP_ADDRESS>
set deviceconfig system netmask <SUBNET_MASK>
set deviceconfig system default-gateway <GATEWAY_IP>
```
3. Run the `commit` command to save the changes

!!! success
	You should now be able to access the Palo Alto web interface for management.

### Adding Network Adapters

You will need 5 network adapters for this VM, and the OVA only deploys with 3. Go to ESXi and add two more to the VM. The network adapters should look like such:

| Network Adapter | Port Group |
| --------------- | ---------- |
| 1               | Management |
| 2               | DMZ        |
| 3               | Management |
| 4               | Users      |
| 5               | Services   |


### Device Configuration

1. Log into the Palo Alto web interface and select the **Device** tab at the top of the page
2. Under the Management tab, click the gear wheel next to general settings:
	1. Give the device a hostname
	2. Define the base domain
	3. Choose the correct timezone
3. Under the **Services** tab, click the gear wheel next to Services:
	1. Define a primary and optionally a secondary DNS server
	2. Select the **NTP** tab and set an NTP server (us.pool.ntp.org)
4. Under the **Telemetry** tab, click the gear wheel next to Telemetry:
	1. Uncheck 'Enable Telemetry'
### Network Configuration
	
1. Go to the web GUI via `https://<palo-alto-IP>`
2. Log in with the credentials you set previously
3. Select interface `ethernet1/1` to open it's settings
	1. Give this interface a description in the comment. "DMZ" is fine
	2. Change the interface type to 'Layer 3'
	3. Under the **Config** tab:
		1. Change the virtual router to 'default'
		2. In the **Security Zone** drop down, create a new zone and name it "DMZ". Don't worry about the other settings on this page
	4. Under the **IPv4** tab:
		1. Set the type to either Static or DHCP client, depending on the scenario. If static, ensure the IP you use is acceptable for use in the environment
	5. Click **OK** on the interface editing window

!!! warning "CIDR with Interface IP"
	When entering the interface IP be sure to enter the IP Address with CIDR (example 192.168.1.1/24)
4. Repeat step 3, but for `ethernet1/2`, `ethernet1/3` and `ethernet1/4`. These interfaces will be for the MGMT, Users, and Services, respectively.

#### Default Route

1. You need to define a default route so that the router knows where to send traffic. Go to **Virtual Routers** on the left menu and edit the 'default' router
2. In the Virtual Router pop-up, go to **Static Routes** on the left and hit '+ Add'
	1. Name it 'Default Route'
	2. Destination: 0.0.0.0/0
	3. Interface: ethernet1/1
	4. Next Hop: This will be the IP of the gateway above this instance of Palo Alto
	5. Click **OK**

#### DHCP Server

1. On the left menu, select DHCP and then "+ Add" at the bottom
2. In the DHCP Server pop-up: 
	1. Change the **Interface** to 'ethernet1/3' or whatever interface you want a DHCP server on
	2. Change the **Mode** to enabled
	3. Under **IP Pools**, enter your range of assignable IPs (ex: 10.83.69.66-10.83.69.92)
	4. Change tabs to Options:
		1. Set the gateway that will be assigned in the lease (ex: 10.83.69.65)
		2. Enter the Subnet Mask (ex: 255.255.255.224)
3. Select **OK**

### Policy

#### Security Policy

1. Create a new rule by clicking '+ Add' at the bottom of the page
	1. Name the rule. This first rule should be something pertaining to allowing traffic out from the internal network
	2. If desired, give the rule a description. This is highly recommended for more complex rules
	3. Select the **Source** tab:
		1. Under source zone, select 'Any'
		2. For Source address, select 'Any'
	4. Select the **Destination** tab:
		1. Under destination zone, select '+ Add' and add the 'DMZ' zone
		2. For destination address, select 'Any'
	5. Select the **Actions** tab:
		1. Ensure the Action Setting is set to 'Allow'
	6. Click **OK** to add this rule

#### NAT Policy

1. Select 'NAT' on the left menu
2. Create a new NAT rule by clicking '+ Add' at the bottom of the page
	1. Give the rule a name, such as 'NAT LAN to DMZ'
	2. Select the **Original Packet** tab:
		1. Under source zone, select 'Any'
		2. Under destination zone, hit the drop down and select 'DMZ'
	3. Select the **Translated Packet** tab:
		1. Hit the **Translation Type** drop down and select 'Dynamic IP and Port'
		2. Hit the **Address Type** drop down and select 'Interface Address'
		3. Hit the **Interface** drop down and select 'ethernet1/1' (or whatever you have your DMZ interface set to)
		4. Leave the **Destination Address Translation** set to 'None'
	4. Click **Ok**

!!! success "Commit"
    Now is a good time to hit the commit button. You should be able to reach the internet from the LAN after completing these steps.