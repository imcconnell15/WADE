# Timesketch

Timesketch is a data analysis platform for host data with timestamps. This tool is primarily focused on understanding the context of Sigma/Hayabusa alerts with Plaso timelines from a disk image.

# Build Virtual Machine

This server may ingest substantial amounts of plaso files and requires decent computing resources for searching and analyzing. A full plaso file from a busy server may reach 5GB, most hosts generate a plaso of 1-2 GB.

The plaso can be generated on a different workstation, but there may be version mismatch issues. Timesketch is deployed with a log2timeline/plaso Docker that is known to work. Generating the plaso from the Timesketch server may be required, though this can be done over a network share.

Current recommendations:
- 10 TB storage thin provisioned
- 16 CPU
- 64GB RAM

# Installation Instructions

1. Follow the instructions for an Ubuntu server installation.
2. Install Docker from Docker Hub.
> [!WARNING] Install Docker from Dockerhub directly. The default Ubuntu version of docker is a snap and not suitable for our purposes.
> [!NOTE] Use `wget` to download the Dockerhub gpg key.
3. Download the Timesketch deployment script.
4. Execute the script in the chose directory (probably `/opt`).
5. If the script asks to start the docker containers, say yes. Otherwise use the following commands:
```
cd timesketch
sudo docker compose up -d
```
6. Check that the website is available at the correct IP address.  If not, ensure that the nginx.conf file path matches the one listed in docker-compose.yml.
7. Create users in Timesketch with `sudo docker compose exec timesketch-web tsctl create-user [name]`. The first user will be an administrator account.  Additional configuration options are available in the `admin-cli`.


# References:
- https://timesketch.org/guides/admin/install/
- https://docs.docker.com/engine/install/ubuntu/
- https://timesketch.org/guides/admin/admin-cli/