# Installing Iris

1. A basic Ubuntu VM on the ESXi server is required before starting to install Iris.  Ensure the [setting up an Ubuntu VM](../Step%201%20-%20Zero%20to%20MIN/6%20-%20Installing%20Ubuntu%20Server.md) is completed prior to starting. Reference the [Resource Requirements](./Resource%20Requirements.md) to see what resources you need to assign this VM.
2. Clone the Iris Web git repository:
```bash
git clone https://github.com/dfir-iris/iris-web.git
cd iris-web
```
3. Checkout the latest version. Verify the most recent version on their website [here](https://github.com/dfir-iris/iris-web). As of writing this, it is v2.4.16:
```bash
git checkout v2.4.16
```
4. Rename the .env.model file:
```bash
mv .env.model .env
```
5. Run the docker commands to spin up Iris:
```bash
sudo docker-compose pull
```
6. If you get an error regarding 'depends_on', make the following changes to the `docker-compose.base.yml`:
```yaml
nano docker-compose.base.yml

# Remove all instances of depends_on (There should be 3 of them):
depends_on:
	- "rabbitmq"
	- "db"

# etc
```
7. Save the file and run the docker-compose command:
```bash
sudo docker-compose pull
sudo docker-compose up -d
```

8. Run the following command to get the admin password:
```sh
sudo docker-compose logs app | grep "WARNING :: post_init :: create_safe_admin"
```

9.  The Iris web GUI should now be accessible via HTTPS. Username is administrator with the password from the previous step.