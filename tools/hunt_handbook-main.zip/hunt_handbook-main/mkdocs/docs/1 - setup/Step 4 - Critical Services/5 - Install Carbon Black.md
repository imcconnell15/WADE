# Carbon Black Installation Guide

## Carbon Black Server Installation

1. A basic RHEL VM (Centos7, Rocky, etc.) on the ESXi server is required before starting to install Mattermost. Ensure this VM is completed prior to starting. Reference the [Resource Requirements](./Resource%20Requirements.md) to see what resources you need to assign this VM.

2. Copy the Carbon Black-provided RPM file to the newly created VM.
    - `carbon-black-release-<customer dependent>. x86_64.rpm`

3. From the VM, install the RPM package.
    - `rpm -ivh carbon-black-release-<customer dependent>. x86_64.rpm`

4. Modify yum.conf file.
    - `vi /etc/yum.conf`

5. Configure cachedir and keepcache

    ```conf
    [main]
    cachedir=/var/cache/yum/$basearch/$releasever
    keepcache=1
    ```

6. Download and install Carbon Black EDR packages and dependencies. Install cb­enterprise:
    - `yum install cb-enterprise -y

7. Once Carbon Black is downloaded, run the following command to initialize and configure the Carbon Black server:
    - `sudo /usr/share/cb/cbinit`
        - add the following arguments to the command to substitute your own certificate over the server-provided one: `--server-cert-file= <certpath> --server-cert-key= <keypath>`

8. Press [Enter] to open the EULA, once complete type [q] and then [yes] to continue.

9. Choose a storage location (default is [/var/cb/data]), press [Enter] to continue.

10. Configure Administrator account with the following information:
    - Username, First Name, Last Name, E-Mail, Password, Confirm Password
    - Type [y] after validating above information.

11. In the Sensor Communications section, define the address that the sensors will use to communicate to the Carbon Black EDR server.
    - If the networking information was correctly entered when creating the Carbon Black VM, the default option should be correct. Type [y] to continue.
    - Type [n] if the default is incorrect.
        - Use SSL [Y/n]: Y.
        - Hostname [192.168.117.141]: cbr.example.com
        - Port [443]: type [enter]
        - If the Verify Account Information looks correct type [Y]

12. Do you want to enable communication with the Carbon Black Alliance? Type [n]

13. For the SSL Certificate Generation Section, press [enter]
    - This command will be run after the server setup to create a SSL backup
        - `/usr/share/cb/cbssl backup --out <backup_file_name>`

14. In the Security – Firewall Configuration section, type [Y]. This opens port 443 in the server’s IP tables.

15. The POSTGRESQL Database Setup section is automated and requires no user input.

16. In the Setup Complete section, type [Y] to start the services. The services could take a couple of minutes to start.

17. Create the backup from step 13 after services are starte-
    - `/usr/share/cb/cbssl backup --out <backup_file_name>`
    - Enter password for backup file.
    - Once Nextcloud is configured, copy the backup file to Nextcloud and add a text document with the backup file password in the same location.

## Carbon Black Sensor Installation

1. Browse to Carbon Black IP address in your browser and login with the credentials used during server setup.
    `https[:]//<Server IP>`

    !!!note "HTTP"  
        If https is not working, try http.

2. Using the navigation bar on the left side of the screen, click the screen icon for sensors.
3. In the top left next to “Groups” select “NEW”
    - General
        -  Type name of group
        - Confirm Server URL matches web interface IP.
    - Sharing
        - Deselect all 3 options.
    - Advanced
        - Deselect filter known modloads and process banning.
            1. These can be changed later if necessary.
        - Change Retention Maximization to Maximum Retention
            1. If this takes up too much space on Disk, change to recommended retention.
    - Permissions
        - Next to Analysts, select the dropdown and choose Analyst.
            1. Analysts is the default team in Carbon Black
    e. Event Collection
        - Select ALL options.
            1. This can be changed later.
    f. Upgrade Policy
        - Default option is “No Automatic Upgrades.”
        - Determined by lea-
    g. Select “Create Group” at the bottom.
4. Selected the newly created group under the groups pane.
    - The group name will appear at the top of the page when selecte-
5. Choose the dropdown for “Download Sensor Installer” in the top right corner of the page and select the appropriate sensor OS installation file.
    - File will be downloaded as a zip. Extract to get files.
    - Sensor deployment can be done individually, or via GPO/script.
6. Install Sensor on endpoint.
    - Individual Install
        - Run “CarbonBlackClientSetup.exe”
            1. Click install then finish once complete.
    - Group Policy Install
        - After unzipping, reference GPO_README.txt to configure for group policy.
    - Command Line
        - `Msiexe-exe /qn /i cbsetup.msi`
        
        !!!note "Command explaination"
            Command is explained under “Additional Notes” in GPO_README.txt

7. Verify Sensor is properly installed by refreshing the sensors page on the carbon black server.

## Enable Boot-Start for Carbon Black

1. Lists runlevel carbon black service
    - `Chkconfig –list | grep cb-enterprise`
        - Runlevel 3 and 5 need to be set to “on.”
2. Enable boot-start for Carbon Black service.
    - `Chkconfig cb-enterprise on`
    - Enables runlevels 3 and 5.
3. Restart Carbon black VM to complete changes
