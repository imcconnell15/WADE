# Installing Mattermost

1. A basic Ubuntu VM on the ESXi server is required before starting to install Mattermost. Ensure the [setting up an Ubuntu VM](../Step%201%20-%20Zero%20to%20MIN/6%20-%20Installing%20Ubuntu%20Server.md) is completed prior to starting. Reference the [Resource Requirements](./Resource%20Requirements.md) to see what resources you need to assign this VM.
2. Run the following commands:
```bash
sudo apt update && sudo apt upgrade
sudo apt install docker
sudo apt install docker-compose
sudo apt install openssl
```
3. Clone the mattermost git repo:
```bash
git clone https://github.com/mattermost/docker
cd docker
```
4. Create the required directories and set their permissions:
```bash
mkdir -p ./volumes/app/mattermost/{config,data,logs,plugins,client/plugins,bleve-indexes}
sudo chown -R 2000:2000 ./volumes/app/mattermost
```
5. Edit the environment file for mattermost:
```bash
nano env.example

# Modify the following line:
DOMAIN=<domain>

# Comment out the following lines:
NGINX_IMAGE_TAG=alpine
NGINX_CONFIG_PATH=./nginx/conf.d
NGINX_DHPARAMS_FILE=./nginx/dhparams4096.pem
CERT_PATH=./volumes/web/cert/cert.pem
KEY_PATH=./volumes/web/cert/key-no-password.pem
```
6. Rename the environment file:
```bash
mv env.example .env
```
7. Run the docker compose command to bring mattermost up:
```bash
sudo docker-compose -f docker-compose.yml -f docker-compose.without-nginx.yml up -d
```
8. You should now be able to reach mattermost via `http://<IP ADDRESS>:8065`
9. Select continue in browser and then create your initial admin user.