## Installing Velociraptor

1. Obtain the latest version of velociraptor from their [github](https://github.com/Velocidex/velociraptor/releases)
2. A basic Ubuntu VM on the ESXi server is required before starting to install Velociraptor. Ensure the [setting up an Ubuntu VM](../Step%201%20-%20Zero%20to%20MIN/6%20-%20Installing%20Ubuntu%20Server.md) is completed prior to starting. Reference the [Resource Requirements](./Resource%20Requirements.md) to see what resources you need to assign this VM.
```bash
cd ~
wget https://github.com/Velocidex/velociraptor/releases/<PATH TO LATEST VERSION>
```
3. Make the binary executable, then move it to /usr/local/bin and rename it to velociraptor:
```bash
chmod +x ~/velociraptor-v0.72.0-linux-amd64
sudo mv ~/velociraptor-v0.72.0-linux-amd64 /usr/local/bin/velociraptor
```
4.  Create the server and client config files:
```bash
velociraptor config generate -i
```
5. When prompted, enter the following:
	1. What OS will the server be deployed on?
		- Linux
	2. Path to the datastore directory.
		- Accept default, hit enter
	3. What is the public DNS name of the Master Frontend (e.g. www.example.com):
		- **For Internal Velo**: Enter the IP of the velociraptor server.
		- **For Customer Network Velo**: Enter the public IP for the WAN interface of the kit
	4. Enter the frontend port to listen on.
		- Accept default, hit enter
	5. Enter the port for the GUI to listen on.
		- Accept default, hit enter
	6. Would you like to try the new experimental websocket comms?
		- No
	7. Would you like to use the registry to store the writeback files? (Experimental)
		- No
	8. Which DynDns provider do you use?
		- None
	9. GUI Username or email address to authorize (empty to end):
		- Enter the admin UN & PW for velociraptor
	10. Path to the logs directory.
		- Accept default, hit enter
	11. Do you want to restrict VQL functionality on the server?
		- No
	12.  Where should I write the server config file?
		- Accept default, hit enter
	13. Where should I write the client config file?
		- Accept default, hit enter
6. The server.config.yaml and client.config.yaml files should now be in the user's home directory. We need to edit the server config file:
```bash
nano server.config.yaml

## Find all instances of 127.0.0.1 and localhost. Replace these with <YOUR SERVER IP> and save the file.
sudo mv ~/server.config.yaml /etc/
```
7. Next, we need to create a system service for Velociraptor:
```bash
sudo nano /lib/systemd/system/velociraptor.service

## Add the following lines to the file:
[Unit]
Description=Velociraptor linux amd64
After=syslog.target network.target

[Service]
Type=simple
Restart=always
RestartSec=120
LimitNOFILE=20000
Environment=LANG=en_US.UTF-8
ExecStart=/usr/local/bin/velociraptor --config /etc/server.config.yaml frontend -v

[Install]
WantedBy=multi-user.target
```
8. Reload the systemd daemon:
```bash
sudo systemctl daemon-reload
```
9. Next, start the Velociraptor service and enable it to start at system reboot:
```bash
sudo systemctl enable --now velociraptor
```
10. Verify the velociraptor service is running. If so, you should be able to reach the web gui at `https://<SERVER IP>:8889`
```bash
sudo systemctl status velociraptor

## Output should look something like this:
velociraptor.service - Velociraptor linux amd64 
	Loaded: loaded (/lib/systemd/system/velociraptor.service; enabled; vendor preset: enabled) 
	Active: active (running) since Sun 2021-06-20 07:15:36 UTC; 5s ago Main PID: 1074 (velociraptor) 
	Tasks: 6 (limit: 2353) 
	Memory: 32.5M 
	CGroup: /system.slice/velociraptor.service 
		└─1074 /usr/local/bin/velociraptor --config /etc/velociraptor.config.yaml frontend -v
```

---
# Creating a Velociraptor Windows Agent

1. Obtain the latest version of the velociraptor MSI from their [github](https://github.com/Velocidex/velociraptor/releases).
```bash
cd ~
wget https://github.com/Velocidex/velociraptor/releases/<PATH TO LATEST MSI VERSION>
```
2. Repack the msi with the new client config:
```bash
velociraptor config repack --msi velociraptor-v0.72.0-windows-amd64.msi client.config.yaml <YOUR AGENT NAME>.msi
```
3. The newly packed MSI is ready to deploy to target systems. Happy hunting!