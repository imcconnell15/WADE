# Installing Nginx Proxy

## Details
Nginx proxy should be installed on the same VM as mattermost. It allows for the use of self-signed certificates and enable HTTPS for any services that use HTTP by default. The following services need certificates generated and need to be added behind the proxy:
- Nginx Proxy Web GUI (Port 81)
- PiHole Web GUI (Port 80)
- Mattermost Chat (Port 8065)

## Command Line 

1. Ensure that docker and docker-compose are installed on whatever VM this goes on. Change directories to the home directory and create the proxy folder:
```bash
cd ~
mkdir proxy
cd proxy
```
2. Create the docker compose file:
```bash
nano docker-compose.yml

# Insert the following lines into the file
services:
  app:
    image: 'docker.io/jc21/nginx-proxy-manager:latest'
    restart: unless-stopped
    ports:
      - '80:80'
      - '81:81'
      - '443:443'
    volumes:
      - ./data:/data
      - ./letsencrypt:/etc/letsencrypt
```
3. Run the docker compose up command:
```bash
sudo docker-compose up -d
```
4. You should now be able to reach Nginx proxy via `http://<IP ADDRESS>:81` with the following default creds:
```
Email: admin@example.com
Password: changeme
```

## Generating Self-signed Certificates for Proxy

1. You will need to generate self signed certs for each app you want to run behind the proxy. This is done with the following commands:
```bash
openssl genrsa -out <YOUR FQDN>.key 2048
openssl req -new -key <YOUR FQDN>.key -out <YOUR FQDN>.csr
openssl x509 -req -days 365 -in <YOUR FQDN>.csr -signkey <YOUR FQDN>.key -out <YOUR FQDN>.crt
```
2. After the certs are created, transfer all of them to your local machine with either WinSCP or your choice file transfer option.
## Uploading Certs to Nginx Proxy

1. In the Nginx Proxy Manager web GUI, go to 'SSL Certificates' and select 'Add SSL Certificate' in the top right (NOT THE BIG PINK BUTTON IN THE MIDDLE) and a drop down will open. Select 'Custom'
2. Name the cert and upload the corresponding certificates. You only need the .key and .crt files.
3. At the top, go to 'Hosts > Proxy Hosts' then select 'Add Proxy Host'.
4. Enter the domain name, the IP address of mattermost, and 8065 for the port. ENSURE you turn on 'Websockets Support', Then select 'SSL' at the top.
5. Select the certificate you added associated with mattermost and turn on 'Force SSL' and 'HTTP/2 Support' the save and exit.