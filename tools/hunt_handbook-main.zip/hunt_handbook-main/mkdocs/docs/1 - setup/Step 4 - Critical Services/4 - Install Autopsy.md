# MultiUser Autopsy Setup and Installation

This document will cover how to build and configure a multiuser instance of
Autopsy for forensic analysis.
This document was compiled for version 4.19.3 on a Windows Server 2016 VM; version changes may require adjustments. Please update this document as needed.

1. [Windows 2016 Server Configuration](./4%20-%20Install%20Autopsy.md#windows-2016-server-configuration)
2. [Set up Shared Storage](./4%20-%20Install%20Autopsy.md#set-up-shared-storage)
3. [Download and Install Autopsy](./4%20-%20Install%20Autopsy.md#download-and-install-autopsy)
4. [Install and Configure PostgreSQL](./4%20-%20Install%20Autopsy.md#install-and-configure-postgresql)
5. [Install and Configure Solr](./4%20-%20Install%20Autopsy.md#install-and-configure-solr)
6. [Install and Configure ActiveMQ](./4%20-%20Install%20Autopsy.md#install-and-configure-activemq)
7. [Install Autopsy Clients](./4%20-%20Install%20Autopsy.md#install-autopsy-clients)

Components 1-5 above should be configured on a Windows Server 2016 instance on ESXI.  The Autopsy Clients should be installed on the analyst laptops.

## Windows 2016 Server Configuration

***INCOMPLETE: INSERT LINK TO FULL INSTALLATION AND CONFIGURATION***

Brief Procedure:

 1. Create VM in VCSA -
    * RAM:
    * CPU
    * Storage
    * Network
 2. Use VMware workstation to connect to server
 3. Edit Machine settings to point cd rom drive to iso
 4. Ensure that "connect at power on" is checked
 5. Win Server 2016 Standard Eval with Desktop Experience!!!
 6. Custom Install onto Drive 0: 90GB
 7. Change hostname in command prompt: `hostname` `wmic computersystem where name="OLDNAME" call rename name="autopsyserver"` followed by `shutdown /r /t 0`.
 8. add autopsy user: `net user /add autopsy d34d_b0x_z0m613`
 9. Add local dod_admin account?
10. Configure autopsyserver to use LDAP? Or just autopsy.exe?
11. Install VMware tools
12. CIS Benchmarks/STIG
13. Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Microsoft\\Internet Explorer\\Main" -Name "DisableFirstRunCustomize" -Value 2
14. `[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12`
15. Configure Internet Explorer
    * Click Tools in top right corner and then Internet Options.
    * Click on the Security tab.
    * Select the Internet Zone.
    * Click on the Custom Level button and then scroll down to Downloads.
    * Make sure to enable File download.
    * Click Apply and OK.

## Set up Shared Storage

In addition to the C: drive, the Autopsy server requires shared storage that can be accessed from the Autopsy clients and, depending on the configuration, the Solr server.  This shared storage will be used for both data sources and case outputs.  For consistency, this will be implemented as the A:\\ drive.

 1. From Administrator cmd prompt, type "`diskpart`" and press Enter.
 2. "`list volume`" shows all the volumes on PC. The volume may not be listed here.
 3. `list disk` to see all the disks attached.
 4. `select disk x` - where x is the storage disk
 5. `online disk` - this should bring the storage disk online
 6. `list partion` - there might not be any on this disk.
 7. `attributes disk clear readonly` - This ensures you can write to the disk.
 8. `clean` - Not sure what this does, but seems to be recommended here.
 9. `create partition extended` - This will fill the entire disk.
10. `create partition logical` - This will fill the entire extended partition.
11. `list volume` - You should now see the logical partition
12. Type in "`select volume x`"
13. `assign letter=A'
14. `format fs=ntfs label="AutopsyCases"` - ***WARNING*** Ensure you have the correct volume selected before formatting. This will take some time, but there is a counter displaying "`x percent completed`".
15. `list volume` for verification. Check the size, drive letter, and filesystem format.

### Share the Storage Drive

1. Move to the `a:` drive, then `mkdir Cases`.
2. Share the A: drive: `net share "AutopsyCases=A:\Cases"`
3. Use `net share` to list and validate the shares.
4. `set-netconnectionprofile -name Network -networkcategory private`
5. Modify Permisions for full access to autopsy user: `cacls a:\ /e /p autopsy:f`
6. Use another computer to connect to the share. `net use A: \\[ip address]\AutopsyCases`. For credentials, use the `autopsy` user created above.
7. 

**Requirements:**

* All computers will need to access the shared storage at the exact same path, via the A:\\ drive.
* The user accounts that Autopsy and Solr are running as will need permissions to read and write to the shared storage.

## Download and Install Autopsy

Download the Autopsy installer from an official site, such as [https://www.autopsy.com/download/](https://www.autopsy.com/download/) or the sleuthkit github, as shown in the following powershell command:

`Invoke-WebRequest https://github.com/sleuthkit/autopsy/releases/download/autopsy-4.20.0/autopsy-4.20.0-64bit.msi' -outfile autopsy-4.20.0.msi`

Execute the downloaded installer and follow the prompts.

`.\autopsy-4.20.0.msi`

## Install and Configure PostgreSQL

In a multi-user case, a central PostgreSQL database server is used instead of the embedded SQLite databases. A new database will be created for each case and the database will be stored in a location you choose during installation.

> You should ensure that the database folder is backed up.

**Installation:**

1. Download a 64-bit PostgreSQL installer from [here](https://www.enterprisedb.com/downloads/postgres-postgresql-downloads) Choose one under Windows x86-64. Autopsy has been tested with PostgreSQL [version 9.5](https://sbp.enterprisedb.com/getfile.jsp?fileid=1257550). To download from a powershell commandline, you may have to change the Net.SecurityProtocolType or the TLS session handshake will fail.

```
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
```

To bypass the Internet Explorer first-time run checks:

```
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Internet Explorer\Main" -Name "DisableFirstRunCustomize" -Value 2
```

```
invoke-restmethod -uri https://sbp.enterprisedb.com/getfile.jsp?fileid=1257550 -outfile postgresql-9.5.25.exe
```

1. Run the installer.
2. You may accept defaults for all items except for the password and the database storage location as you work through the wizard. The selected directory must be empty.
   * Data Directory: A:\\Cases
   * database superuser password: Follow the Password SOP.  Do not lose the password you enter in. This is the PostgreSQL administrator login password.
3. You do not need to launch the StackBuilder nor acquire any more software from it. Uncheck the option to use StackBuilder and press *Finish*.

**Configuration**

1. Create a regular database user account that Autopsy will use.

* Use the pgAdmin III tool.	This is located at "C:\\Program Files\\PostgreSQL\\9.5\\bin\\pgAdmin3.exe."
* Right-click on the PostgreSQL 9.5 server and select "connect".  Login with the password created above.
* Right click on *"Login Roles"* and select *"New Login Role..."*.
* Enter the user name `autopsydb` in the *"Role name"* field\
* Enter the account password on the "Definition" tab.  This is needed both to log in and also for linking it to Autopsy.
* For *"Role Privileges"*, give the user *"Can Login?"* and *"Can create databases" then click "ok"*

Edit `a:\\cases\\pg_hba.conf` to add an entry to allow external computers to connect via the network.\\

`Host all all 10.69.83.0/24 md5`

1. Modify the postgresql.conf file located at `a:\\cases\\postgresql.conf`.

Uncomment the following entries in the configuration file by removing the leading "#", and change their values to *"off"* as shown below.

```
Fsync = off
Synchronous_commit = off
Full_page_writes = off
```

Increase the max connections to the database to 100 per node. For example, with one primary Autopsy server and 5x Host Analysts with Autopsy Clients, set the max connections to 600:
`max_connections = 600`

1. Restart the service. `restart-service postgresql-x64-9.5`
2. If you want PostgreSQL to run as a different user (you don't need to), then make that change now. When done, click the link that says *Start the service*. ***Need to reconfigure so postgresql is not running as administrator**
3. Add the binary postgres.exe file to the Windows firewall to allow it to receive connections. `New-NetFirewallRule -DisplayName "postgres" -Direction Inbound -Program "c:\\Program Files\\PostgreSQL\\9.5\\bin\\postgres.exe" -Action Allow
4. Powershell management of SQL. As administrator, `install-module sqlserver`.

**Testing**

1. You can verify that PostgreSQL is running by using either the *pgAdmin* tool or the *psql* tool to connect to the database server from another machine on the network.
2. Install the powershell module sqlserver and user the command `Invoke-Sqlcmd -Query "SELECT GETDATE() AS TimeOfQuery" -ServerInstance "10.69.83.161"`

Common problems are typically the result of:

* Firewall blocking the port (default: 5432) on the PostgreSQL server.
* Incorrectly configured database user account or incorrect credentials.
* Incorrectly configured IP address range in pg_hba.conf file.

## Install and Configure Java Runtime Environment

> Autopsy uses Apache Solr to store keyword text indexes. A central server is needed in a multi-user cluster to maintain and search the indexes.
>
> A new text index is created for each case. The index can be stored either on shared storage or on the local drive of the Solr server(s) (large amount of local
> storage is required).
>
> Solr's embedded ZooKeeper is also used as a coordination service for
> Autopsy.

**Prerequisites:**
*** UPDATE THIS SECTION FOR CLARITY ***
You will need a 64-bit version of the Java 8 Runtime Environment (JRE)  
from [[https://github.com/ojdkbuild/ojdkbuild]{.underline}](https://github.com/ojdkbuild/ojdkbuild).
([[Download links]{.underline}](https://github.com/ojdkbuild/ojdkbuild/blob/master/README.md))

`invoke-restmethod -uri https://download.java.net/java/GA/jdk19.0.2/fdb695a9d9064ad6b064dc6df578380c/7/GPL/openjdk-19.0.2_windows-x64_bin.zip -outfile jdk19.zip`

`Expand-Archive -Path jdk19.zip -DestinationPath 'c:\\Program Files'

then use `./jdk19.exe` to install.

Microsoft build of JDK:

```
invoke-restmethod -uri https://aka.ms/download-jdk/microsoft-jdk-17.0.6-windows-x64.msi -outfile jdk17.msi -outfile jdk17.msi
.\jdk17.msi
```

Follow the prompts, enable all options. Restart.
Use `java -version` to verify the install went correctly.

### Install and Configure SOLR

> Pre-packaged Autopsy version of Solr from [[here]{.underline}](https://sourceforge.net/projects/autopsy/files/CollaborativeServices/Solr/SOLR_8.6.3_AutopsyService.zip/download). This contains Solr, [[NSSM]{.underline}](https://nssm.cc/) to make it run as a service, and the needed schema config files.
>
> A network-accessible machine to install Solr on. Note that the Solr process may need to write to a shared storage drive (if that is how you configure it) and will therefore need adequate permissions.

THIS LINK IS PRE-CONFIGURED FOR AUTOPSY: https://sourceforge.net/projects/autopsy/files/CollaborativeServices/Solr/SOLR_8.6.3_AutopsyService.zip/download

invoke-restmethod -uri https://www.apache.org/dyn/closer.lua/solr/solr/9.1.1/solr-9.1.1.tgz?action=download -outfile solr-9.1.1.tgz

* tar.exe -xvzf - only available in windows 10 and 2019

USE 8.11.2 with Autopsy 4.20

https://archive.apache.org/dist/lucene/solr/8.9.0/solr-8.9.0.zip
https://www.apache.org/dyn/closer.lua/lucene/solr/8.11.2/solr-8.11.2.zip?action=download

`expand-archive -path solr-8.11.2.zip -destinationpath "c:\program files\"`

This has more current versions, but only in tgz format: https://archive.apache.org/dist/solr/solr/
**Follow these steps to configure Solr:**

**\*\*Note this is for Solr-8.6.3 your version may vary so wherever  
8\.6.3 is listed you will need to put your version.**

1. Extract the solr-8.6.3.zip archive from the location given in the [**[Prerequisites]{.underline}**](https://sleuthkit.org/autopsy/docs/user-docs/4.19.3/install_solr_page.html#install_solr_prereq) section into a directory of your choice. The rest of this document assumes that the archive is extracted into "C:\\solr-8.6.3" directory.
2. Go to the "C:\\solr-8.6.3\\bin" directory and open the "solr.in.cmd" file in a text editor
3. Search for each "TODO" and specify a valid path for each of the required configuration parameters. These parameters will be described in detail [**[below]{.underline}**](https://sleuthkit.org/autopsy/docs/user-docs/4.19.3/install_solr_page.html#install_solr_params)

> **\*\*Note In the line "=(TODO!...)" everything after the "=" will  
> need to be replaced with the corresponding directories  
> listed below; again your versions or paths may vary**
>
> **JAVA_HOME** -- path to 64-bit JRE installation. For
> example "JAVA_HOME=C:\\Program Files\\Java\\jre1.8.0_151"   
> or "JAVA_HOME=C:\\Program
> Files\\ojdkbuild\\java-1.8.0-openjdk-1.8.0.222-1"
>
> **DEFAULT_CONFDIR** -- path to Autopsy configuration directory. If the
> Solr archive was extracted into "C:\\solr-8.6.3" directory, then
> this path will be   
> "C:\\ solr 8.6.3\\server\\solr\\configsets\\AutopsyConfig\\conf".  
> Do not include quotes around the path.
>
> **SOLR_JAVA_MEM** - Solr JVM heap size should be as large as the Solr
> machine's resources allow, at least half of the total RAM available on
> the machine. A rule of thumb would be use "set SOLR_JAVA_MEM=-Xms2G
> \-Xmx40G" for a machine with 64GB of RAM, "set SOLR_JAVA_MEM=-Xms2G
> \-Xmx20G" for a machine with 32GB of RAM, and "set
> SOLR_JAVA_MEM=-Xms2G -Xmx8G" for a machine with 16GB of RAM. Please
> see the [**[troubleshooting
> section]{.underline}**](https://sleuthkit.org/autopsy/docs/user-docs/4.19.3/install_solr_page.html#install_solr_heap_usage) for
> more info regarding Solr heap usage and troubleshooting information.
>
> **SOLR_DATA_HOME** -- location where Solr indexes will be stored. If
> this is not configured, the indexes will be stored in
> the "C:\\solr-8.6.3\\server\\solr" directory. NOTE: for Autopsy
> cases consisting of large number of data sources, Solr indexes can get
> very large (hundreds of GBs, or TBs) so they should probably be stored
> on a larger network share.
>
> **Solr Text Index File Location**
>
> **Important note:** previous versions of Autopsy (Autopsy 4.17.0 and
> earlier) stored the Solr text indexes in the case output directory. As
> a result, the Solr indexes would get deleted if a user deleted the
> case output directory. Solr 8 (i.e. Autopsy 4.18.0 and later) no
> longer stores the Solr text index files in the case output directory
> but instead stores them in location defined by
> the **SOLR_DATA_HOME** parameter. As a consequence, if a user choses
> to manually delete case output directories (for example, to free up
> disk space), the Solr index directories located
> in **SOLR_DATA_HOME** need to be manually deleted as well.
>
> Text index for an Autopsy case will follow a naming structure
> according to following rules: "\[Autopsy case name\] \[Case creation
> time stamp\] \[Text index creation time stamp\]
> \[shardX_replica_nY\]". For example, the text index for an Autopsy
> case "Test Case" will be located in the following directory
> inside **SOLR_DATA_HOME**:

### Solr Windows Service Installation

> At this point Solr has been configured and ready to use. The last step
> is to configure it as a Windows service so that it starts each time
> the computer starts.

Open

> a command line console as Administrator and navigate to
> the "C:\\solr-8.6.3\\bin" directory. From there, run the following
> command: "nssm install Solr_8.6.3".

An NSSM UI window will appear. Click the

> "Path" navigation button: again your Solr version may differ.
>
> Select the "C:\\solr-8.6.3\\bin\\solr.cmd" file. NOTE: Make sure you
> don't select the "solr.in.cmd" file by accident. In the
> "Arguments" parameter, type in "start --f --c":

Optionally, configure service's display

> name, startup type, and account  
> info:

**Configure Service User**

> In the [**[Pick Your User
> Accounts]{.underline}**](https://sleuthkit.org/autopsy/docs/user-docs/4.19.3/install_multiuseruser_page.html) section,
> you should have decided what user to run Solr as. To configure Solr to
> run as that user, you'll use Windows Service Manager.
>
> Switch to the "Log On" tab to change the logon credentials to the
> chosen user who will have access to the shared storage.

* If you specify a domain account, the account name will be in the form of "DOMAINNAME\\username" as shown in the example below

> Click "Install Service". You should see the following UI window
> appear:
>
> Should it not appear or the service not start on the next step, some
> common issues we have come across are:

* Solr.in.cmd file incorrectly configured
* IP address resetting to default after being manually configured

**Start Solr Service**

At this point the Solr service has been

> configured and installed. You can verify this by opening Windows
> "Services" window:
>
> Start the "Solr_8.6.3" service, and verify that the service status
> changes to "Running". If it was already running stop the service and
> restart it.

> We have observed that Antivirus may detect strings in the Solr indexes
> as being malware. You should add the Solr data directory to the
> exclusion list for your security product. We saw this with Windows
> Defender.

**Testing**

> There are two tests that you should perform to confirm that the Solr
> machine is configured correctly.

**Web Interface:** You should attempt
to access the Solr admin panel in a web browser. On the Solr
machine, navigate
to [[http://localhost:8983/solr/#/]{.underline}](http://localhost:8983/solr/#/) and
verify that the Solr admin console gets displayed. You should also
attempt to access the Solr admin panel in a web browser from another
machine on the network. Replace "localhost" in the previous URL
with the IP address or the host name that the Solr service is
running on.

```{=html}
<!-- -->
```

* If the service is appropriately started but you are unable to see the screenshot above, then it could be that port 8983 for Solr and port 9983 for ZooKeeper are blocked by your firewall. Contact your network administrator to open these ports.
* **Shared Storage:** Log in to the Solr computer as the user you decided to run the Solr service as and attempt to access the shared storage paths. Ensure that you can access the UNC paths (or drive letters if you have hardware NAS). If everything is configured correctly you should be able to access the storage paths without having to provide credentials. If you are prompted for a password to access the shared storage, then either enter the password and choose to save the credentials or reconfigure the setup so that the same passwords are used. See the [**[Storing Credentials]{.underline}**](https://sleuthkit.org/autopsy/docs/user-docs/4.19.3/install_multiuseruser_page.html#multiuser_users_store) section for steps on storing credentials. If you needed to store the credentials, then you should restart the service or reboot the computer (we have observed that a running service does not get the updated credentials).

## Configuring Autopsy Clients:

* Once the rest of the services are configured you will [**configure Autopsy to enable multi-user cases**](https://sleuthkit.org/autopsy/docs/user-docs/4.19.3/install_multiuserclient_page.html). For the Solr 8 server, configure the Solr 8 Service and the ZooKeeper service connection info. ZooKeeper connection info is required. The ZooKeeper port number is 1000 higher than Solr service port number. By default, Solr service port is 8983 making the embedded ZooKeeper port 9983. You may also use a [**standalone ZooKeeper service**](https://sleuthkit.org/autopsy/docs/user-docs/4.19.3/install_solr_page.html#install_solr_standalone_zk). [Autopsy - Collaborative Autopsy: How It Works](https://www.autopsy.com/collaborative-autopsy-how-it-works/#:~:text=To%20use%20multi-user%20cases%2C%20you%20download%20the%20same,source%20platform%20offers%20an%20enterprise-grade%20database%20for%20free.)

## Autopsy's Use of ZooKeeper Service:

* Autopsy uses ZooKeeper service for multi-user coordination purposes. Autopsy uses ZooKeeper to obtain locks on case level resources before modifying them. Most importantly, Autopsy stores some of its internal state data in ZooKeeper -- which cases have been created, their processing state (pending, processing, or completed), as well as other case and job level state data. This is especially important if you are running Autopsy in Auto Ingest Mode, as auto ingest needs to know which jobs have already been processed.
* In the screen shot below, for coordination purposes Autopsy will be using the ZooKeeper server that is running on the Solr 8 server ("Solr1" machine).

**Standalone ZooKeeper Server:**

> In our testing, for Autopsy purposes it is not necessary to have a
> standalone ZooKeeper server. For the regular Autopsy use case it is
> sufficient to use the "embedded" ZooKeeper service that is started
> by Solr service (on port 9983). However, Apache Solr documentation
> recommends that a standalone ZooKeeper service (running on separate a
> machine) is used in production environments.
>
> <https://lucene.apache.org/solr/guide/8_6/solrcloud-configuration-and-parameters.html

## Install and Configure ActiveMQ

### Overview:

> ActiveMQ is a messaging service that allows the Autopsy clients to
> communicate with each other. This allows each client to get real-time
> updates. This service has minimal storage requirements.

### Prerequisites:

You will need:

* 64-bit version of the Java 8 Runtime Environment (JRE) (should have been installed with Solr) from [[https://github.com/ojdkbuild/ojdkbuild]{.underline}](https://github.com/ojdkbuild/ojdkbuild) ([[Link to installer]{.underline}](https://github.com/ojdkbuild/ojdkbuild/releases/download/java-1.8.0-openjdk-1.8.0.242-1.b08/java-1.8.0-openjdk-1.8.0.242-1.b08.ojdkbuild.windows.x86_64.msi))
* Download ActiveMQ from: [[http://activemq.apache.org/download.html]{.underline}](http://activemq.apache.org/download.html) . Autopsy has been tested with ActiveMQ version 5.14.0. Note that newer versions will not work with Java 8.

### **ActiveMQ Installation:**

1. Extract the contents of the ActiveMQ archive to a location of your choice, bearing in mind that the files should be in a location where the running process has write permissions. A typical folder choice would be similar to *C:\\Program Files\\apache-activemq-5.13.3*. The system may ask for administrator permission to move the folder. Allow it if required.
2. Open the *conf\\activemq.xml* file in the extracted folder in a text editor and make the following changes:
   * Add *"schedulePeriodForDestinationPurge="10000""* to the *broker* tag
   * Add *"gcInactiveDestinations="true" inactiveTimoutBeforeGC="30000""* to the *policyEntry* tag.
   * 

### Placeholder

> Add *"&wireFormat.maxInactivityDuration=0"* to the URI for
> the *transportConnector* named *openwire*. This is highlighted in
> yellow below.

1. Install ActiveMQ as a service by navigating to the folder *bin\\win64*, right-clicking *InstallService.bat*, clicking *Run as administrator*, then click *Yes*.
2. Add the bin\\win64\\wrapper.exe and java.exe (from the JRE) to the Windows firewall so that they can accept network communications.
3. Start the ActiveMQ service by pressing *Start*, type *services.msc*, and press *Enter*. Find *ActiveMQ* in the list and press the *Start the service* link.
4. ActiveMQ should now be installed and configured using the default credentials.

**Testing:**

> To test your installation, you can access the admin pages in your web
> browser (on the server) via a URL like
> this: [[http://localhost:8161/admin]{.underline}](http://localhost:8161/admin).
> NOTE that you cannot access this page from other hosts unless you go
> into jetty.xml and change org.apache.activemq.web.WebConsolePort so
> that host is 0.0.0.0 (and ensure that it is properly secured).
>
> The default administrator username is *admin* with a password
> of *admin* and the default regular username is *user* with a default
> password of *password*. You can change these passwords by following
> the instructions below.
>
> If you can see a page that looks like the following, it confirms that
> the ActiveMQ service is running locally but it does not necessarily
> mean that the service is visible to other computers on the network.

> You can also confirm that your ActiveMQ installation is visible to
> other computers on the network by attempting to connect to a URL like
> the following (replacing the host name with that of the ActiveMQ
> computer) in a web
> browser: [[http://activemq-computer:61616]{.underline}](http://activemq-computer:61616/).
> This will not give you a nice web page, but will give you data from
> the server.

If you are unable to connect to this address:

* Double check that the ActiveMQ service is running
* Check that the port (61616) is not being blocked by a firewall.

## Install Autopsy Clients

### Overview

> Once the infrastructure is in place, you can configure Autopsy clients
> to use them.

1. Install Autopsy on each client system. Use the normal installer and pick the defaults.
2. Test that the user has access to the shared storage by opening the shared storage folders using Windows Explorer. If a password prompt is given, then enter the password and store the credentials (see [**Storing Credentials**](https://sleuthkit.org/autopsy/docs/user-docs/4.19.3/install_multiuseruser_page.html#multiuser_users_store)).
3. Start Autopsy and open the multi-user settings panel from "Tools", "Options", "Multi-user". As shown in the screenshot below, you can then enter all of the address and authentication information for the network-based services. Note that in order to create or open Multi-user cases, "Enable Multi-user cases" must be checked and the settings below must be correct.
4. For each setting, press the "Test Connection" button to ensure that Autopsy can communicate with each service. If any fail, then refer to the specific setup page for testing options. Also check that a firewall is not blocking the communications.
   * NOTE: None of these tests are for permissions on the shared storage because Autopsy does not know about the shared storage. It can't test that until you make a case.
5. Make a test case (see [**[Creating Multi-user cases]{.underline}**](https://sleuthkit.org/autopsy/docs/user-docs/4.19.3/multiuser_page.html#creating_multi_user_cases)). You can add a single file in as a logical data source. The key concept is to look for errors.
   1. If you find errors, look for errors in the log file on the Autopsy client.
   2. If you followed all of the previous steps in all of the previous pages, then a common error at this point is that Solr cannot access the shared storage and it is running as a Service account. When this happens, you'll see an error message about Solr not being able to create or access a "core". If this happens, review what user Solr should be running as (see the [**[Solr Service]{.underline}**](https://sleuthkit.org/autopsy/docs/user-docs/4.19.3/install_multiuseruser_page.html#multiuser_users_solr) section) and change the shared storage configuration or ensure that credentials are stored.