# Aggregator shell Configuration

## Overview

### Inital login

- Login with `admin`/`admin123A!` - default credentials
- Hit `N` to abort out of inital setup wizard.
- Set new admin password to kit password scheme


### Command to Display Information

- `show port`: Each of the interfaces is called a port in GigavueOS - show the status of the current ports - including type ie tool or network
- `show port-pair`: Port pairs are needed to group the tap's ports to signify that both ports contain the send and receive of the conversation
- `show map`: Display information about the map between groups and ports

### Steps to be completed

- Install license
- Enable the ports
- Set required ports to tools ports
- Create the port pairs
- Create the port group
- Create the map
- Add the rules to pass traffic

!!! success "Enable mode"
    All the commands below need to be completed in the enabled mode.
        ```shell
        enable
        config terminal
        ```

## Install License

!!! note "License should be installed"
    The license should be installed with the kit refresh.  Without a license port configuration will not be saved.

```shell
chassis box-id <1>
card slot <number 1-64>
license install box-id 1 key <license-key>
```

## Enable the Ports

!!! tip "Enable ports"
    By default the ports will be disable.  Ensure that the ports are enabled before completing the following steps.

```shell
port 1/1/x1..x12 params admin enable
port 1/1/c1..c3 params admin enable
```

## Configure tool port

A tool port sends the tap data out to the sensor, configure tool ports as needed.

```shell
port 1/1/c1 type tool
```

## Create Port-pair

Port pairs are used when a taps TX/RX are sent to the aggregator, these two ports should then be put into a port pair informing the aggregator that they are coming from a single link.

```shell
chassis box-id <1>
card slot <number 1-6>
show port
port-pair alias <name> between  <1/1/x1> and <1/1/x2> comment "<comment>"
show port-pair
```

## Create Port-group

Create a port group to aggregator multiple ports to send out one tool port.  Once you create the port-group alias the command should switch to the alias name.  After configuring the port-group exit back to the standard configuration prompt.

```shell
port-group alias <Port Group Alias>
(port-group) port-list <1/1/x1..x12>
exit
show port-group
```

!!! tip "Exit port-group"
    Exit from `port-group` configuration, ensure the prompt is (config)

## Create Map

The map defines the network port, port pair, or port group to send to a tool port.  The steps below create the map, by alias name, and send **from** the port or group **to** the port, which must be a configured tool port.  After the ports are specified the rules must be added to allow the traffic to pass. Once you create the map alias the command should switch to the alias name.  After configuring the map exit back to the standard configuration prompt.

!!! tip "Tool port"
    Be sure to configure a port to a tool port before entering the map alias configuration.

```shell
map-passall alias <map alias>
(map) from <port-group>
(map) to <output port>
exit
show map
write mem
```

!!! success "WRITE MEM"
    **BE SURE** to `write-mem` to save the configuration.

### If using passing rules

!!!note "Pass All"
    Rules are not needed with a pass all map, but if you want to use rules to pass traffic, the following commands can be used to add rules to the map.

```shell
(map) rule add pass ipver 4
(map) rule add pass ipver 6
```

## Delete/Remove commands  

Additional commands that can be used to remove/change items.

- Remove map: `no map alias <alias_name>`  

