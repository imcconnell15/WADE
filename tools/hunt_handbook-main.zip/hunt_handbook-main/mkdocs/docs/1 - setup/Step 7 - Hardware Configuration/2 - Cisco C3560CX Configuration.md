# Cisco WS-C3560CX

Reset the Cisco switch to the factory default configuration, this sets the switch to a known configuration.

## Reset

!!! tip "Choose the console cable"
    The grey miniUSB cable will work to connect to the switch, however it may have problems staying connected throughout the reboot.  The black console cable is more reliable.

1. Connect to the cisco switch using the console port choose one of the following:
    1. Either the USB to mini USB cable in the case (also the Crash Cart cable works)
    2. Or console cable that is USB to RJ45
2. Determine the COM port by opening device manager and looking under Ports (COM & LPT) for the USB Serial Port
3. Open a terminal program such as PuTTY or TeraTerm
4. Configure the terminal program to use the COM port (found in device manager) and set the baud rate to 9600
5. Power on the switch
6. Press and hold the mode button on the front of the switch
7. Wait for the switch to boot and release the mode button
8. The switch will boot into the 'switch:' prompt
9. Enter the following commands:

    ```shell
    flash_init
    rename flash:config.txt flash:config.old
    boot
    ```

10. Reconnect to the switch and login with the default credentials: `cisco` and `cisco`

## Portfast

1. Set the spanning tree to portfast (allows quicker connects when plugging and unplugging cables)

    ```shell
    enable
    configure terminal
    interface range GigabitEthernet 1/0/1-16
    switchport mode access
    spanning-tree portfast
    exit
    exit
    write mem
    ```
