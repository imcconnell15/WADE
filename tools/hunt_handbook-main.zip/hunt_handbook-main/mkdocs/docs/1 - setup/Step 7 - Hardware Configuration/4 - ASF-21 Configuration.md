# Gigamon ASF-21

The Gigamon ASF-21 comes configured correctly with the ports ready to tap.  However the `jump-start` can be used to configure options such as management port IP address, domain name, etc.  If the `jump-start` is ran the port are disabled and need to be enabled.

!!! tip "Management Interface"
    Even with the management interface assigned an IP address the ASF-21 can ONLY be configured via the command-line.  The web interface doesn't provide any configuration options or status.

## Connection

Connection information using the console port.

| hardware | username | password | baud rate |
| --- | --- | --- | --- |
| Gigamon AF21 | admin | admin123A! | 115200 |

## Jump-Start

Run the `jump-start` configuration wizard with the following commands.

```shell
enable
configure terminal
config jump-start
write mem
```

## Enable interfaces

The "interfaces" can only be addressed as a port X1, X2, X3, X4 (This is denoted in small text under the port between the Net and Tool labels).  After the `jump-start` be sure to enable the ports with the following commands.

```shell
enable
configure terminal
port X1..x4 params admin enable
port X1..x4 params autoneg enable
write mem
```
