# SW-2000 Configuration

## Device Driver

Connect the USB-Serial cable USB end to the laptop and the ethernet end to the SW-2000 console (bottom of the two management ports). Use the local driver for the USB-Serial comm cable.

- Open Device Manager
- Find unknown device under "Other Devices"
- Right-click choose "Update driver"
- "Browse my computer for drivers"
- "Let me pick from a list of available drivers on my computer"
- Scroll down the "Common Hardware types:" list and select "Ports (COM & LPT)"
- Click "Next"
- Scroll down "Manufacturer" list and select "Microsoft"
- From "Model" list choose "USB Serial Device"
- Ignore the warning and click "Yes"

## Configuration

1. Determine the COM port by opening device manager and looking under Ports (COM & LPT) for the USB Serial Port
2. Open a terminal program such as PuTTY or TeraTerm
3. Configure the terminal program to use the COM port (found in device manager) and set the baud rate to 115200
4. Login to the console ( admin / admin )
5. Choose "N" to use the initial configuration wizard.
6. Choose "N" for password hardening.
7. Change "admin" password
8. Change "monitor" password
9. From the switch prompt ("[standalone: master]"), enter the following commands to configure the management interface - replace the IP address with the desired address for the switch:

```shell
enable
configure terminal
interface mgmt0
no shutdown
ip address 10.10.10.254 255.255.255.0
exit
interface ethernet 1/1-1/22
shutdown
speed auto
no shutdown
exit
write memory
```

## Management Access

To connect to the switch without plugging in the MGMT port, use the following steps:

1. Login to the switch via the website address (default mgmt0 interface is set to DHCP)
    - use `show interface mgmt0` to find the IP address
2. Select "IP Interface" from the left side under "IP Route"
3. Under "Create IP L3 Interface" fill the settings to these
    - Interface: **VLAN**
    - Interface Number: **1** (default VLAN for all the interfaces)
    - VRF: **mgmt0** (this should be available in the drop down)
4. Once the settings are filled in click **"Apply"**
5. After applying the settings the interface will show up under "IP L3 Interfaces" and "VLAN 1" will be clickable to edit - click to edit the interface
6. This will take you "VLAN 1 Interface Configuration" make sure the settings are as follows
    - Enabled: Checked
    - Autostate: Checked
    - ICMP Redirect: Checked
    - IPv4 Address: **set to the IP address you want to use**
    - IP Address mask: **should match the network netmask**
    - ARP Timeout: **1500**
    - VRF: **mgmt**
    - MTU: **9216**
7. Click **Apply**
8. Click the Floppy Disk icon in upper right to save configuration