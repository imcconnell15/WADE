## Disclaimer
These are the SUGGESTED minimum resources for the CPTs use-case. This is by no means the gospel and these numbers can be shifted if needed.

!!! warning "Thin Provisioning"
    Ensure that you always thin provision your storage. This keeps resources free and clear if/when not in use.
## Service Resource Recommendations

| Service                                 | CPU      | RAM    | Storage |
| --------------------------------------- | -------- | ------ | ------- |
| Splunk Search Head                      | 32 Cores | 32 GB  | 1 TB    |
| Splunk Indexer                          | 48 Cores | 64 GB  | 20 TB   |
| Splunk Deployment Server                | 8 Cores  | 16 GB  | 2 TB    |
| Internal Splunk                         | 16 Cores | 32 GB  | 5 TB    |
| Iris                                    | 8 Cores  | 32 GB  | 2 TB    |
| PiHole                                  | 4 Cores  | 4 GB   | 100 GB  |
| Mattermost                              | 8 Cores  | 8 GB   | 500 GB  |
| Nextcloud                               | 8 Cores  | 16 GB  | 5 TB    |
| Velociraptor                            | 8 Cores  | 16 GB  | 5 TB    |
| MIN                                     | 8 Cores  | 16 GB  | 200 GB  |
| Security Onion Manager (w/ Search node) | 16 Cores | 64 GB  | 5 TB    |
| Security Onion Manager (ManagerSearch)  | 32 Cores | 128 GB | 20 TB   |
| Security Onion Search Node              | 32 Cores | 128 GB | 20 TB   |
| Carbon Black                            | 16 Cores | 32 GB  | 5 TB    |
