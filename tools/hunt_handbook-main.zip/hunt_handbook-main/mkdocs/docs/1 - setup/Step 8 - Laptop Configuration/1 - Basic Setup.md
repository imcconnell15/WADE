# Basic Laptop

## Changing Hostname

1. Hit the windows button, then select Settings > System > About
2. Select Rename this PC, choose the name for the laptop scheme, and update the IP cut sheet on Nextcloud.
3. Select Next. The PC will need to be restarted for the change to take effect

## Sysmon Setup

Ensure you have the latest version of sysmon on a removable device. Open the sysmon folder and place **sysmon64.exe** & **sysmonconfig.xml** into the **C:\Windows\system32** directory, then open a powershell command as administrator and run the following commands:

```shell
cd C:\Windows\system32
sysmon64.exe -accepteula -i sysmonconfig.xml
sysmon64.exe -c sysmonconfig.xml
```

## Splunk Forwarder Deployment

1. Download the latest Splunk Forwarder x64 msi (should be available on Nextcloud, if not upload it to the shared software)
2. Check the box to accept the license agreement and select next
3. Make the username **admin** and uncheck the box to set a password then select next
4. For deployment server, enter the IP of your internal splunk instance then select next
5. Skip setting the indexer (this will be controlled by the deployed apps) Select next, then Install

## Change Admin Password

1. Search for “Add, edit, or remove other users”
2. On the left, select “Sign-in Options”
3. Once this loads, select “Password” and then “Add”

## Creating User Accounts

1. In the search bar, search for "mmc".
2. Go to File > Add/Remove Snap-in...
3. Scroll to "Local Users and Groups" and add it.
4. Click Finish on the pop-up window, then click OK.
5. Click on Local Users and Groups > Users.
6. Right click and select "New User...".
7. Enter the user information and select "Create".
8. Select File > Save and save the console.
