# Bitlocker

## Turn on Bit locker

1. `gpedit.msc`
2. To configure the enhanced PIN (password)
    1. Navigate to *Computer Configuration* **>** *Administrative Templates* **>** *Windows Components* **>** *Bitlocker Drive Encryption* **>** *Operating System Drives* **>** *Allowed Enhanced PINS for Startup*
    2. Click enabled for **Allow Enhanced PINS** <-- Change to allow the use of passwords
3. Navigate to *Computer Configuration* **>** *Administrative Templates* **>** *Windows Components* **>** *Bitlocker Drive Encryption* **>** *Operating System Drives* **>** *Require Additional Authentication at Startup*
    1. Choose **Enabled** for Require Additional Authentication at Startup
    2. Leave all the other settings for this item the default
4. From Windows Start menu search and choose "Manage Bit Locker"
5. Select "Turn On Bitlocker"
6. Enter Password (PIN)
7. Encrypt used space only
8. Use new encryption method
9. Save recovery key to external USB
10. Reboot
11. Copy recovery key to KeePass Database on Nextcloud

## Shut Lid Power off

It is useful to enable the laptop to shutdown when the lid is closed to enforce bitlocker.

1. `gpedit.msc`
2. Navigate to *Computer Configuration* **>** *Administrative Templates* **>** *System* **>** *Power Management* **>** *Button Settingss*
3. **Select lid switch action (plugged in)** - Enabled - Lid switch action dropdown is **Shutdown**
4. **Select lid switch action (on battery)** - Enabled - Lid switch action dropdown is **Shutdown**

### Use command line to set Bitlocker PIN

```cmd
manage-bde -protectors -add c: -TPMAndPIN
manage-bde -status
```

## Troubleshooting

### Delete a PIN

Delete a PIN in order to change the PIN to something else

```cmd
manage-bde -protectors -delete c: -Type TPMAndPIN
```
