# VM NTP Configuration

## Network Time Protocol Configuration (NTP)

1. Login to vSphere and on the left-pane there are four graphical buttons. Click on the far-left button (shaped like a PC tower)
2. Click on the desired host within the Cluster tree
3. Click on the Configure Tab then Navigate to and Click Time Configuration
4. Click on the Add Service drop-down menu and Select Network Time Protocol
5. Check the “Enable monitoring events” Box
6. NTP Servers: Type in server names, IP Addresses that you’d like to assign (separate by commas)
