1. Sign into the ESXi web interface
2. On the left menu, select 'Host' if not already in this menu
3. In the middle, select 'Actions>Services>Enable Secure Shell'
4. Open a command prompt and SSH to the ESXi server
```bash
ssh root@<ESXi IP address>
```
5. Go to [this website](https://esxi-patches.v-front.de/ESXi-7.0.0.html) and scroll to the most recent update. Click on the link next to Imageprofile. The link should be attached to something that looks like this:  **ESXi-7.0U3r-24411414-standard**
6. When you click on this link, a pop-up should open with the commands that need to be run. Return to the ESXi SSH shell and run the commands, one at a time. As of writing this (13 Dec 2024), these are the current commands:
!!! info inline end
    The second command takes roughly 10min to run. Take a break and come back, then run the third command.
```bash
esxcli network firewall ruleset set -e true -r httpClient
esxcli software profile update -p ESXi-7.0U3r-24411414-standard -d https://hostupdate.vmware.com/software/VUM/PRODUCTION/main/vmw-depot-index.xml
esxcli network firewall ruleset set -e false -r httpClient
```
7. Return the the ESXi web GUI and log in. 
8. There should be two warnings, one saying the host needs to be rebooted and another saying SSH is enabled on this host. Lets turn off SSH by going to 'Actions>Services>Disable Secure Shell'
9. Go back to 'Actions' again and select 'Reboot'. This completes the update of ESXi