# VM Auto Start

Virtual Machine auto-start can be configured in multiple locations, either on the ESXi server or the VCSA UI.  Either configuration will enable the VM to auto-start with power on of the ESXi server.  

!!! warning "Enable Auto Start for the ESXi Server"
    Autostart must be **enabled** for the ESXi server as a whole before the VM auto-start settings for the individual VM will occur.

## VM Auto Start Configuration

1. Login to vSphere ensure the view is currently *Hosts and Clusters* - Select the *Menu* dropdown chose *Hosts and Clusters* (`ctrl + alt + 2`)
2. Ensure the navigation is expanded - the *VCSA Server* (represented by the VCSA icon and the IP should match) is the root
      1. Expand *VCSA Server*
      2. Expand the *Datacenter* - datacenter was named during VCSA installation - listed directly under VCSA server in navigation
      3. Expand the *Cluster* - created and named during VCSA installation - immediately under the datacenter
      4. Navigation will be expanded to show all the ESXi hosts directly under the cluster
3. Select one of the ESXi Hosts underneath the cluster in the navigtation tree
4. With the host highlighted, to the right of the navigation pane, Click on the **Configure** Tab
5. The *Configure* tab will provided a vertical scroll bar of options - scroll to *Virtual Machines* and click to highlitgh *VM Startup/Shutdown*
6. Click Edit
    1. Check the “Automatically start and stop the VMs with the system” Box
    2. Startup Delay: 5 (example)
    3. Shutdown Delay: 20 (example)
    4. Shutdown action: Power Off
    5. Select a VM under the "Manual Startup" option in the list
    6. Click the “Move Up” (option is above the VM list)
    7. VM can either be in *Automatic* or *Automatic Ordered* - *Automatic Ordered* hosts start before *Automatic*

!!! tip "Ordered Start"
    Use the *Automatic Order* option for the important services that are dependencies for other services, ie Router/Firewall should start first before anything else.

## ESXi Host Configuration

### Enable auto-start for the ESXi Server

1. From the Navigator (bar on the left) under *Host* click *Manage* - this will display the manager options on the right
2. From *System Tab* select *Autostart* click *Edit Settings*
3. Ensure that auto-start *Enabled* radio button is set to **YES**

## Enable auto-start for a VM from ESXi

1. From the Navigator (bar on the left) under *Host* click *Manage* - this will display the manager options on the right
2. From *System Tab* select  *Autostart*
3. Select the host from the Virtual Machine list
4. Click *Enable* right above the virtual machine list
5. Verify the host has a number in the **Autostart order** column
      1. To show the **Autostart order** column - if not shown
      2. Right-click header of any column in the *Virtual Machine* table
      3. Choose *Select Colmuns* by hovering over
      4. Ensure *Autostart Order* has a check in the box next to the option
