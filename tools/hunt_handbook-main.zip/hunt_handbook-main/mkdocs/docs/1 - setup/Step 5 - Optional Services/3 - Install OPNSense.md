# OPNSense installation

Configure the network interfaces and install opnsense to a SN7000 with ESXi already configured.

## SN-7000 NIC Configuration

1. On the back of the SN-7000, there are two ethernet NICs towards the bottom. Looking at the back, the lower left port is where the LAN cable should be plugged in, and the lower right port is where the WAN cable should be plugged in.
2. Login to ESXi on the SN-7000 by entering the IP address in the web browser
3. Plug ISO hard drive into the analyst laptop (provide opnsense ISO either through ISO from analyst laptop, it is also possible to add the ISO to the datastore)
4. Select the "Networking" tab on the left in ESXi
5. At the top of the page, select "Virtual Switches"
6. Click on "vSwitch0" and select "Edit Settings"
7. Remove the uplink associated with "vmnic1" (NOTE: Do not remove vmnic0), then save and return to the virtual switches menu
8. Select "Add standard virtual switch". Name this switch "WAN" and change uplink 1 to "vmnic1" then select "Add"
9. At the top of the page, select "Port groups"
10. Select "Add port group". Name this port group "WAN" and associate it with the WAN virtual switch then select "Add"
11. Going forward, "vSwitch0" will be associated with the LAN and "WAN" will be associated with the WAN

## WAN Port group

On the ESXi host that will be acting as a router, create a new port group for the WAN interface.  This will be used to connect the opnsense VM to the WAN.

1. Choose "Networking" on left navigation bar
2. Go to "Virtual switches" tab
3. "Add standard virtual switch"
4. Name it "WAN" for vSwitch name
5. Select "Add"
6. Go to "Port groups" tab
7. "Add port group"
8. Name it "WAN" for Port group name
9. Select "WAN" for vSwitch

## Creating opnsense VM using FreeBSD OS

1. Click on the "Virtual Machines" tab on the left and select "Create/Register VM"
2. Select "Create a new virtual machine"
3. Name the VM along the lines of "opnsense", and select the "Other" for the "guest OS"
4. Change "Guest OS version" to "FreeBSD Version 13 or later (64-bit)"
5. Select storage (choose the NVMe datastore to allow opnsense to run if the RAID array fails)
6. Set the hardware to:
    1. CPU: 4 Cores
    2. Memory: 4 GB
    3. Storage: 40 GBs
       1. Set this to "thin-provisioned" under the storage drop down.
7. Change SCSI Controller 0 to "LSI Logic SAS"
8. This VM needs two NICs
     1. First NIC needs to be assigned LAN/VMnetwork port group
     2. Second NIC needs to be assigned WAN port group
9. Select "Next" to confirm the details and then hit "Finish" to create the VM
10. Select the newly created VM and power on

!!! note "Two methods to load the CD drive"  
    In general there two main methods to load the CD drive, either from an ISO on the datastore or from an ISO through the remote console.  Ideally the remote console is preferred to avoid extra ISOs cluttering up the datastore.  The following steps will load an ISO from the datastore.  The preferred method with the remote console requires either VM Workstation or VM Player to be installed on a laptop.  
    1. Add the CD/DVD Drive 1 as file from the datastore and browse to the location of the upload ISOs and select the file.
    2. Ensure the CD/DVD Drive is set to connected and connect at power on.  
    3. Continue with steps below skipping all the steps to attach the ISO, start with step 7 after turning the VM on.

### Installing opnsense on FreeBSD

1. Click "Console" at the top and then select "Launch remote console"
2. Ensure the opnsense VM is highlighted in the left side navigation bar, at the top select "VM" and click on "settings"
3. Select "CD/DVD 1" in the left column and then go to "device status" and ensure "connected" and "connected at power on" are both selected.
4. Under "Connection," change location to "local client"
5. Under "Image," select "Browse" and open the opnsense ISO
6. Hit "OK" on the bottom of the windows to apply changes, (make **sure** that the CD drive box for connected and connect at power on are checked) then restart the VM
7. During the boot-up there is **QUICK** countdown (5 seconds) - press any key to manually configure interfaces.
8. Answer "No" to configure LAGGs now.
9. Answer "No" to configure VLANs now.
10. Validate MAC address correspond to the correct WAN/LAN interfaces.
11. Chose WAN interface, should be **vmx1**, the mac address for vmx1 in previous step will match the mac address to the virtual adapter in ESXi.
12. Chose LAN interface, should be **vmx0**, the mac address for vmx0 in previous step will match the mac address to the virtual adapter in ESXi.

    !!! warning "DHCP Server"
        DHCP will be configured later.  Ensure that the LAN interface, the one that DHCP will be configured for, is not connected to another network with DHCP

13. Answer "Y" for do you want to proceed.
14. After the settings apply, the login prompt will be presented, login with **installer** / **opnsense**.
15. Continue with default keymap.
16. Chose "Install (UFS)" click **ok** to continue.
17. On select disk option ensure the hard disk is selected (it defaults to the CD drive), the hard drive option should be **da0**, click ok to continue.
18. Click YES to continue with a recommended swap partition of size.
19. Last Chance! - click YES to continue with the installation to hard drive **da0**.
20. After the installation to the hard drive is complete - chose "Root Password" to set the root password for the system. This should be one of your own choosing.
21. After setting root password the menu will come back and this time choose "Complete Install"
22. After reboot from the terminal/cli login to the console. (username **root** - password set above)
23. Choose "2) Set interface IP address".
24. Select the LAN (should be option 1).
25. Select no for "DHCP"
26. Enter the LAN IP address - this will be in the kit IP scope and the gateway IP for most hosts
27. Enter the LAN IP subnet mask as CIDR (for example /24)
28. Enter for none on the upstream gateway address
29. For all IPv6 options select "N" or leave blank for none
30. Enable DHCP for the LAN interface - choose Y
31. Choose the DHCP range (for example 100 - 150)
32. Choose "N" for the remaining options - change the GUI protocol, generate a new signed certificate, and restore the GUI access to defaults.

### Configuring General Settings and DNS

1. The opnsense web interface should be accessible at this point. Default username is **root**, password was set during installation.
2. The General Setup Wizard will launch upon first login, close it by clicking the Opnsense logo in top left.
3. Under **System** > **Settings** > **General** -
    1. Set hostname
    2. Domain (ie example.local)
    3. DNS servers
    4. DNS search domain (ie example.local)
    5. Uncheck "Allow DNS server to be overridden by DHCP/PPP on WAN"
    6. Click **Save**
4. Under **Interfaces** > **WAN**
    1. Under Generic configuration
    2. Uncheck "Block private networks"
    3. Uncheck "Block bogon networks"
    4. Click **Save**
5. Under **Services** > **Unbound DNS** > **Overrides**
    1. Add a **Host Override** for each of the following items:
    2. MIN
        1. Host: min
        2. Domain: \<base domain\>.local (i.e. domain.local)
        3. IP Address: \<IP Address for MIN\> - either current IP address or planned IP
    3. LDAP
        1. Host: ldap
        2. Domain: \<base domain\>.local (i.e. domain.local)
        3. IP Address: \<IP Address for MIN\> - either current IP address or planned IP - same as MIN above
    4. Nextcloud
        1. Host: nextcloud
        2. Domain: \<base domain\>.local (i.e. domain.local)
        3. IP Address: \<IP Address for MIN\> - either current IP address or planned IP
    5. ESXi
        1. Host: \<chosen esxi hostname\> - should either be `esxi` or the chosen theme name
        2. Domain: \<base domain\>.local (i.e. domain.local)
        3. IP Address: \<IP Address for MIN\> - this should already be configured during esxi installation
    6. Click **Apply** at the bottom

    !!! success "Apply"
        Don't forget to click apply for the Host Overrides to take effect.
