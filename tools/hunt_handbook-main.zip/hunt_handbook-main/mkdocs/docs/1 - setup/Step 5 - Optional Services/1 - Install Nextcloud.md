## Nextcloud Install

1. A basic Ubuntu VM on the ESXi server is required before starting to install Nextcloud. Ensure the [setting up an Ubuntu VM](../Step%201%20-%20Zero%20to%20MIN/6%20-%20Installing%20Ubuntu%20Server.md)is completed prior to starting. Reference the [Resource Requirements](./Resource%20Requirements.md) to see what resources you need to assign this VM.
2. Install Nextcloud utilizing the snap tool (Internet is required) & enable a self-signed certificate:  

    ```bash
    sudo snap install nextcloud
    sudo nextcloud.enable-https self-signed
    ```

3. On the host machine, go to Nextcloud web interface using a browser (IP for nextcloud is the IP of the VM)  
4. **Complete before proceeding**: Browse to Nextcloud web interface and **create** the admin account.
5. Select "Skip" and **DO NOT** Install the recommended apps  

    !!! warning "Login first"
        The `nextcloud.occ` commands will fail until you login initially.

6. Go back to the VM, and run the following commands:  

    ```bash
    sudo nextcloud.occ config:system:set trusted_domains 1 --value=nextcloud.<base domain>.local
    sudo nextcloud.occ config:system:get trusted_domains
    sudo nextcloud.occ config:system:set skeletondirectory –-value=""
    ```

!!! info "Skeleton Directory"
    Skeletondirectory is the default files presented to all users.  Setting the value to "" makes nextcloud not load all the default template documents whenever a new user logs in.

## Nextcloud Apps

Add remove the following nextcloud applications:

!!!note "Build script"
    The following script can be used to install an remove the applications required. The script is located at https://code.levelup.cce.af.mil/n-cpt83/build_resources/nextcloud_setup.sh.

1. Login to the nextcloud webpage.
2. Select the admin profile picture to open a drop down
3. In the drop down, select "Apps" and disable the following:

### Disable Applications

  1. first run wizard
  2. weather status
  3. Nextcloud office
  
!!! note "Office Applications"
    The default Nextcloud Office application must be removed and the applications Community Document Server and ONLYOFFICE installed.  This setup will allow OnlyOffice documents to be edit in the web browser from Nextcloud

### Install and Enable Applications

- Activity
- Auditing / Logging
- Breeze Dark
- Circles
- Collaborative tags
- Comments
- Community Document Server
- Contacts
- Contacts Interaction
- Custom menu
- Dashboard
- Deck
- Deleted Files
- Draw.io
- End-to-End Encryption
- Federation
- File Sharing
- Group folders
- Keeweb
- LDAP user and group backend
- Log Reader
- Monitoring
- Nextcloud announcements
- Notifications
- ONLYOFFICE
- Password Policy
- PDF viewer
- Photos
- Privacy
- Recommendations
- Related Resources
- Right Click
- Text
- Usage survey
- User Status
- Versions

## Group Folder Configuration

!!! warning "LDAP Group"
    LDAP must be configured and working with Nextcloud to enable a Group folder and grant access to an LDAP group.  Complete the [LDAP setup](../Step%206%20-%20Setting%20Up%20LDAP/4%20-%20Nextcloud%20LDAP.md) first.

1. Select the Admin profile again, and click "users"
2. On this page, select to add group on the left - **OR** verify that the LDAP group is available in the group selection
3. Create a group that all users can be added to (Example: analysts)
4. Select the admin profile again and click **"settings"**
5. Scroll down on the left column and select **"group folders"**
6. Create a group folder (Example: Software)
7. Add the previously created group (analysts) to the group folder
8. Select the "Files" tab across the top bar, and verify the folder that was created has a "people" icon to symbolize that it is a "shared folder"

## OnlyOffice Configuration

1. Go to "Administration Settings"
2. Scroll down on the left bar and choose ONLYOFFICE under Administration
3. With the "Community Document Server" installed from above ensure the "ONLYOFFICE Docs address" is the url for the Nextcloud Server

    !!! note "ONLYOFFICE Docs address"
        The ONLYOFFICE Docs address is the url for the Nextcloud server.  The default port is 443.  The url should be `https://nextcloud.<base domain>.local`. Sometimes you need to add the specific address ie. `https://nextcloud.<base domain>.local/index.php/apps/documentserver_community/` to get it to work.

	 If it is still not working disable and then remove both ONLYOFFICE and Community Document Server.  Wait a few minutes and then reinstall ONLYOFFICE.  Then navigate away from apps installation and back to the apps installation page.  Then install Community Document Server.  This should fix the issue.

4. Check Disable certificate verification (insecure)
5. Click SAVE