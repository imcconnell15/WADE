# Virtual pfSense Installation
## SN-7000 Network Configuration

1. On the back of the SN-7000, there are two ethernet NICs towards the bottom. Looking at the back, the lower left port is where the LAN cable should be plugged in, and the lower right port is where the WAN cable should be plugged in.
2. Login to ESXi on the SN-7000 by entering the IP address in the web browser
3. Plug ISO hard drive into the analyst laptop (provide pfSense ISO either through ISO from analyst laptop, it is also possible to add the ISO to the datastore)
4. Select the "Networking" tab on the left in ESXi
5. At the top of the page, select "Virtual Switches"
6. Select "Add standard virtual switch". Name this switch "WAN" and change uplink 1 to "vmnic1" then select "Add"
7. At the top of the page, select "Port groups"
8. Select "Add port group". Name this port group "WAN" and associate it with the WAN virtual switch then select "Add"
9. Create another port group and name it "LAN". Use the "vSwitch0" as the virtual switch for this port group.

## Creating pfSense VM using FreeBSD OS

1. Click on the "Virtual Machines" tab on the left and select "Create/Register VM"
2. Select "Create a new virtual machine"
3. Name the VM along the lines of "pfSense", and select the "Other" for the "guest OS"
4. Change "Guest OS version" to "FreeBSD Version 13 or later (64-bit)"
5. Select storage (choose the NVMe datastore to allow pfSense to run if the RAID array fails)
6. Set the hardware to:
    1. CPU: 4 Cores
    2. Memory: 8 GB
    3. Storage: 100 GBs
       1. Set this to "thin-provisioned" under the storage drop down.
7. This VM needs two NICs
     1. First NIC needs to be assigned LAN port group
     2. Second NIC needs to be assigned WAN port group
8. Change the CD/DVD drive to "Datastore ISO file"
	1. Either upload the PfSense ISO to the datastore in this step, or locate a previously uploaded ISO and select it.
9. Select "Next" to confirm the details and then hit "Finish" to create the VM
10. Select the newly created VM and power it on
### Installing pfSense on FreeBSD

1. Click 'console' in the top left and select your favorite console option.
2. Accept the agreement that pops up
3. Select "Install pfSense"
4. Select the wan interface. This can be verified by checking the MAC address of the WAN NIC on Esxi
	1. If you are using a static WAN IP, change the interface mode to static. If DHCP is available for the WAN, select "Proceed with the installation"
5. Select the remaining interface for the LAN
	1. Set the interface mode to static and set your IP address with CIDR and DHCP range (if desired)
6. Confirm the interface assignment and select "Continue"
7. Since we do not have a pfSense license, select "Install CE"
8. Proceed with the default file system and partition scheme, and the default ZFS config on the next page
9. Select the da0 disk for installation and continue and confirm on the next page
10. Select the current stable version and continue
11. Wait patiently for it to install all packages and then select reboot
12. Because pfSense is stupid, we have to configure the LAN and WAN again. Select the same interfaces as before
13. Type '2' to select 'Set interface IP address'
14. Type '2' for LAN
	1. Configure IPv4 via DHCP? Type 'n'
	2. Type your IP address for the LAN
	3. Type '24' or whatever CIDR you're using for the network
	4. You dont need an upstream gateway for the LAN
	5. DHCP6? Type 'n'
	6. You dont need to set an IPv6 address
	7. Set up a DHCP server if desired
	8. Revert to HTTP as the webConfigurator? Type 'n'
!!! success
	You should now be able to reach the web GUI.
### Configuring DHCP

1. pfSense web interface should be accessible at this point. Default username is admin, default password is pfsense
2. Change default password
3. Select the "System" drop down tab at the top and choose general setup
4. Under the "DNS Server Settings" section, Enter "9.9.9.9" in the "DNS Servers" field and scroll to the bottom and select "Save"
5. Select the "Services" drop down tab at the top and choose "DHCP Server"
6. Under the "Servers" section, Enter the IP address of your future PiHole service in the "DNS Servers" field and scroll to the bottom and select "Save"
7. pfSense should be configured to allow internet access at this point. Proceed to the [PiHole Installation](../Step%201%20-%20Zero%20to%20MIN/4%20-%20Installing%20PiHole.md)