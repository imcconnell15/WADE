# Zeek Workbench Configuration

Both Zeek Workbench and Zeek Workbench Forwarder need to be configured to reflect the correct IP addresses of the kit services.  These applications should be configured prior to deploying the applications.

## IPtoASN Configuration

The [Zeek Workbench README](https://code.levelup.cce.af.mil/n-cpt83/zeek_workbench/-/blob/master/README.md) has instructions on how to configure the application and this information may be updated more frequently than this handbook.  Please refer to the README for the most up to date information.

1. After the application as been extracted to `deployment_apps` on the deployment server.  
2. Navigate to the `/opt/splunk/etc/deployment_apps/zeek_workbench/bin/` directory.  
3. Edit `as_check.py`  
4. Change the following line (line #15) to reflect the correct IP addresses of **MIN**.  

    ```python
    OFFLINE = "http://10.10.10.10:53661/v1/as/ip/" # local iptoasn server
    ```

5. After changing the configuration files, ensure **splunk** owns all the files, and reload the deployment server to push the changes to the clients.

    ```bash
    sudo chown -R splunk:splunk /opt/splunk
    sudo -u splunk /opt/splunk/bin/splunk reload deploy-server
    ```

## Zeek Workbench Forwarder Configuration

1. After the application as been extracted to `deployment_apps` on the deployment server.  
2. Navigate to the `/opt/splunk/etc/deployment_apps/zeek_workbench_forwarder/defaults` directory.  
3. Edit `outputs.conf`  
4. In a standard kit build the `server=10.10.10.7:9997, 10.10.10.8:9997` should be changed to the IP addresses of the indexers.  If there is more than 2 indexers, add them to the list separated by a comma.  

    ```conf
    #[tcpout]
    #defaultGroup=group1

    #[tcpout:group1]
    #server=10.10.10.45:9997

    [tcpout:default-autolb-group]
    server=10.10.10.7:9997, 10.10.10.8:9997
    autoLBVolume=10485760
    ```

5. After changing the configuration files, ensure **splunk** owns all the files, and reload the deployment server to push the changes to the clients.  

    ```bash
    sudo chown -R splunk:splunk /opt/splunk
    sudo -u splunk /opt/splunk/bin/splunk reload deploy-server
    ```

## Single Indexer

!!! info "Single Indexer"
    The following information is for a non-distributed Splunk setup, for example standalone internal monitoring Splunk Server.  In a distributed Splunk environment the load balancer outputs should be used.

- If the splunk forwarder is going to send data to only one forwarder change the `outputs.conf`` to the following:

  ```conf
  [tcpout]
  defaultGroup=group1

  [tcpout:group1]
  server=10.10.10.45:9997

  #[tcpout:default-autolb-group]
  #server=10.10.10.7:9997, 10.10.10.8:9997
  #autoLBVolume=10485760
  ```
  
- Comment out the load balancer outputs, and uncomment the single indexer outputs.
- Change the IP address to the IP address of the indexer.
