# Internal Splunk Installation

## Install Ubuntu and Splunk

- A basic Ubuntu VM on the ESXi server is required before starting to install Internal Splunk. Ensure the [setting up an Ubuntu VM](../Step%201%20-%20Zero%20to%20MIN/6%20-%20Installing%20Ubuntu%20Server.md) is completed prior to starting. Reference the [Resource Requirements](./Resource%20Requirements.md) to see what resources you need to assign this VM.
- Follow [Splunk Installation](./1%20-%20Splunk%20Installation.md) steps

## Internal Splunk

This server is a standalone Splunk server that can point to the **license server** but should be its own deployment server, search heard, and indexer.  All of the applications deployed by the internal monitoring Splunk server will have different configurations than the kit Splunk servers.  This server is used to monitor the kit laptops and infrastructure.

1. Follow the steps above to create a new Splunk server
2. Set the license server to the license server created in the previous steps
3. Follow the [app deployment](./4%20-%20Install%20Splunk%20Apps.md) to add the required apps to the internal monitoring Splunk server - however utilize the table below to add some apps to the server and others to deployment apps.

### Table of Splunk Applications and their location for internal monitoring server

| Application Name | `/opt/splunk/etc/apps` | `/opt/splunk/etc/deployment-apps` |
| ---------------- | ----------- | ------- |
| [Splunk Add-on for Microsoft Windows](https://splunkbase.splunk.com/app/742) | X | |
| [Splunk Add-on for Microsoft Sysmon](https://splunkbase.splunk.com/app/5709) | X | |
| [Splunk Add-on for Unix and Linux](https://splunkbase.splunk.com/app/833) | X | |
| [Splunk Common Information Model (CIM)](https://splunkbase.splunk.com/app/1621) | X | |
| [Splunk-machine-learning-toolkit](https://splunkbase.splunk.com/app/2890) | X |  |
| [Splunk App for Lookup File Editing](https://splunkbase.splunk.com/app/1724) | X |  |
| [Splunk-sankey-diagram-custom-visualization](https://splunkbase.splunk.com/app/3112) | X |  |
| [url-toolbox](https://splunkbase.splunk.com/app/2734) | X |  |
| [Punchcard Visualization](https://splunkbase.splunk.com/app/3129) | X |  |
| [Force Directed Visualization](https://splunkbase.splunk.com/app/3767) | X |  |
| [ThreatHunting](https://splunkbase.splunk.com/app/4305) | X | |
| [Zeek Workbench](https://code.levelup.cce.af.mil/n-cpt83/zeek_workbench) | X |  |
| [Host Workbench](https://code.levelup.cce.af.mil/n-cpt83/host_workbench) | X | |
| [Zeek Workbench Forwarder](https://code.levelup.cce.af.mil/n-cpt83/zeek_workbench_forwarder) |  | X |
| [Host Workbench Forwarder](https://code.levelup.cce.af.mil/n-cpt83/host_workbench_forwarder) |  | X |
