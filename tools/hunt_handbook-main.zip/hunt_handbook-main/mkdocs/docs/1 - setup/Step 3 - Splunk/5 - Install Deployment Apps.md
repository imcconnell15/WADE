# Splunk Deployment Applications

## Background

Configuring a Splunk deployment server is beneficial to reduce the amount of configuration required when maintaining multiple Splunk endpoints (Enterprise Servers and Forwarders).  It also helps to reduce configuration mistakes because the number of configurations are also reduced.  A Splunk deployment server allows the Splunk configuration files to be configured at one source, the deployment server, and replicated to all the clients.

## Configuring Deployment applications

Configuring Deployment applications follows a series of steps:

1. Create the Server Class
2. Add Clients to the Server Class
3. Add Applications to the Server Class

### Creating a Server Class

A server class is a grouping of Splunk endpoints, they can be grouped by Operating System, function or a combination of either.

1. Select **Settings** from the Splunk menu bar, then select **Forwarder Management** under the *Distributed Environment* heading
2. Choose the **Server Class** "tab", then **New Server Class**
3. Give the server class a name (something meaningful)

### Add Clients to the Server Class

1. While editing the server class, select **Add Clients**
2. **Required**: The **Include** should be something about the clients to add:
      1. This could be a single IP or multiple IPs using a wildcard (*) in the respective octet
      2. A host name or host name pattern with wildcard (splunk_server, splunk_*)
3. **Optional**: The **Exclude** can be used to remove a computer that might be matched using a pattern
      1. Example: if the Include is 10.10.10.* adding 10.10.10.1 to the exclude would remove this client from the server class

!!! tip "Operating System"
    Before clients can be added by operating system at least one of that type of client for that operating system should be registered with the deployment server.

### Add Applications to the Server Class

1. Go to Settings>Forwarder Management
2. Select **Apps**
3. Find the app you want to add and select **Edit**
4. Under Server Classes, add the desired server class to want to apply this app to
5. ENSURE that both "Enable App" and "Restart Splunkd" are checked, and then select **Save**

## Standard Configuration for Zeekworkbench Forwarders

1. [Be sure that Zeekworkbench Forwarder](./6%20-%20Zeek%20Workbench%20Configuration.md#zeek-workbench-forwarder-configuration) `outputs.conf` is configured first
2. Create the server class and name it something that indicates the clients are sources of Zeek data.
3. Add the clients to the server class - its recommended to group forwarders by IP address, for example `10.10.10.2*`
4. Add Zeekworkbench Forwarder to the server class.
5. **SAVE**

## Set Zeekworkbench applications to restart Splunk

!!! danger "Restart for the forwarder is VERY important"
    Be sure to configure the Zeek Workbench Forwarder to restart before deploying to the Security Onion sensors.

1. Select **Settings** from the Splunk Deployment Server menu bar, then select **Forwarder Management** under the *Distributed Environment* heading
2. Ensure the **Apps** "tab" is selected and all the applications are already added to the deployment server
3. In the Actions column click edit next to "zeek_workbench_forwarder" select **edit**
4. From the the *Edit App* webpage that opens check the box next **Restart splunkd** under *After installation*
5. Repeat the steps for "zeek_workbench"
