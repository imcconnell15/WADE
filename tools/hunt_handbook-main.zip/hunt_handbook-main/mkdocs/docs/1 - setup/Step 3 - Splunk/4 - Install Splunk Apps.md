# Install Splunk Apps

## Background

### App Location matters

Applications that define **indexes** and **inputs** need to be present on the Splunk Indexers.  If an index doesn't exist when the Splunk forwarders send data to the indexer, the data will be dropped.  If an input doesn't exist when the Splunk forwarders send data to the indexer, the data will be dropped.  If the application is not present on the indexer, the index and inputs will not be created.

Dashboards and other search objects need to be present on the Search Heads but not the Indexers.  If the dashboards are present on the Indexers, the dashboards will not be visible on the Search Heads.

For ease of use Zeek Workbench defines both indexes and dashboards.  The Zeek Workbench application needs to be present on both the Indexers and the Search Heads.

### Methods for Application Installation

Splunk applications can be installed either through the web interface or through the command line.  If the Splunk server is a standalone, installation of applications through the web ui is acceptable.  Application which are to be deployed on clients should be in the default deployment applications directory: `/opt/splunk/etc/apps/deployment_apps/` and this requires the applications to be added through the command line.

## Add Applications to the Deployment Server

Ensure that all the following applications are present in the deployment applications directory: `/opt/splunk/etc/apps/deployment_apps/`.  Download the latest applications from the Splunkbase website (this requires an account).

!!! warning "Deployment Server"
    In the distributed splunk environment the applications only need to be present on one server, the Deployment Server.  Install the following applications only on the Deployment Server.

### Table of Splunk Applications and their location

| Application Name | Search Head | Indexer | Forwarders |
| ---------------- | ----------- | ------- | ---------- |
| [Splunk Add-on for Microsoft Windows](https://splunkbase.splunk.com/app/742) | X | X | |
| [Splunk Add-on for Microsoft Sysmon](https://splunkbase.splunk.com/app/5709) | X | X | |
| [Splunk Add-on for Unix and Linux](https://splunkbase.splunk.com/app/833) | X | X | |
| [Splunk Common Information Model (CIM)](https://splunkbase.splunk.com/app/1621) | X | X | |
| [Splunk-machine-learning-toolkit](https://splunkbase.splunk.com/app/2890) | X |  | |
| [Splunk App for Lookup File Editing](https://splunkbase.splunk.com/app/1724) | X |  | |
| [Splunk-sankey-diagram-custom-visualization](https://splunkbase.splunk.com/app/3112) | X |  | |
| [url-toolbox](https://splunkbase.splunk.com/app/2734) | X |  | |
| [Punchcard Visualization](https://splunkbase.splunk.com/app/3129) | X |  | |
| [Force Directed Visualization](https://splunkbase.splunk.com/app/3767) | X |  | |
| [ThreatHunting](https://splunkbase.splunk.com/app/4305) | X | | |
| [Zeek Workbench](https://code.levelup.cce.af.mil/n-cpt83/zeek_workbench) | X | X |  |
| [Host Workbench](https://code.levelup.cce.af.mil/n-cpt83/host_workbench) | X | X | |
| [Zeek Workbench Forwarder](https://code.levelup.cce.af.mil/n-cpt83/zeek_workbench_forwarder) | |  | X |
| [Host Workbench Forwarder](https://code.levelup.cce.af.mil/n-cpt83/host_workbench_forwarder) | |  | X |

## Application Installation Steps

1. Download the required applications from the table above.

    !!! warning "Folder names"
        If you use Gitlab web ui to download the zeek_workbench project the uncompressed folder structure will contain the branch name, ie `zeek_workbench-master`.  The application will not work with this extra branch names.  Ensure that once `zeek_workbench`, `zeek_workbench_forwarder`, `host_workbench`, & `host_workbench_forwarder` are extracted in the deployment folder they **DO NOT** contain the branch names in the folder name.

2. SCP each application to the Splunk server with the following command.  Repeat for all the applications.

    ```bash
    scp <application>.tgz <username>@<splunk deployment server IP>:~/
    ```

3. SSH into the Splunk deployment server

    ```bash
    ssh <username>@<splunk deployment server IP>
    ```

4. Elevate to root, navigate to the deployment applications folder, and extract each application.  

    ```bash
    sudo su -
    cd /opt/splunk/etc/deployment-apps/
    tar -xzvf /home/<username>/<application>.tgz
    ```

5. Configure [Zeek Workbench and Zeek Workbench Forwarder](./6%20-%20Zeek%20Workbench%20Configuration.md)

    !!! note "Configure deployment applications"
        Prior to reloading the deployment server configurations the deployment application should be configured to match the required settings.  If changes to the deployment applications are made after the deployment server is reloaded, the changes will not be pushed to the clients until the deployment server is reloaded again.  Repeat the following two steps every time an application is added or changed.

6. Once all the applications have been extracted, switch back to standard user, and ensure the splunk user owns all of the file in `/opt/splunk`.
  
    ```bash
    exit
    sudo chown -R splunk:splunk /opt/splunk
    ```

7. Restart splunk to reload the Deployment Server applications and local applications.

    ```bash
    sudo -u splunk /opt/splunk/bin/splunk stop
    sudo -u splunk /opt/splunk/bin/splunk start
    ```

## Application Installation through the Web UI

1. Log in to the Splunk web interface
2. Click the **Apps** drop down in the top left corner of Splunk and select **Manage Apps**
3. Click **Install app from file** in the top right corner
4. Select the application file and click **Upload**
5. Repeat for all applications

!!! tip "Application File Format"
    Valid Splunk applications are a **tar** compressed folder with a single folder inside.  The folder inside the tar file should be the name of the application.  The file can either be **.tgz** or **.tar**.
