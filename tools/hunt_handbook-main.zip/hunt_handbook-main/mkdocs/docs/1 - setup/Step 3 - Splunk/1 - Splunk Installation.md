# Splunk Installation

## General Information

A basic Ubuntu VM on the ESXi server is required before starting to install Splunk. Ensure the [setting up an Ubuntu VM](../Step%201%20-%20Zero%20to%20MIN/6%20-%20Installing%20Ubuntu%20Server.md) is completed prior to starting. Reference the [Resource Requirements](../Resource%20Requirements.md) to see what resources you need to assign this VM.

### Installation types and considerations

There are different types of Splunk servers roles that can be configured.  The following are the different types of Splunk servers that can be configured:

- **Deployment Server:** This server is used to configure and deploy apps to other Splunk servers
- **License Server:** This server is used to manage the Splunk licenses
- **Search Head:** This server is used to search and view data from the Splunk Indexers
- **Indexer:** This server is used to store data from the Splunk Forwarders

A standard kit build generally consists of a Deployment Server and License server combined into one server, a Search Head server, and three Indexers.  In this configuration there needs to be 4 Ubuntu VMs created on the ESXi server.

### Gather the necessary files

It is recommended that the the latest version of Splunk Enterprise deb package for Ubuntu be downloaded for each setup.  There are vulnerabilities within in Splunk and using old version could contain serious vulnerabilities.  The steps below reference a version for example, but the version should be replaced with the latest version downloaded.  [Download Link for latest version](https://www.splunk.com/en_us/download/splunk-enterprise.html?locale=en_us) - account required.

## Installation of Splunk

Complete this process for each Splunk server that will be configured.  The roles can be configured after the installation of Splunk.

1. Log in to the Ubuntu VM that will be used for splunk  
2. From a command prompt on the host system, scp the "splunk-..." to the Ubuntu VM that was created for Splunk, the version will be different, example command below:

    ```bash
    scp "splunk-9.0.1-82c987350fde-linux-2.6-amd64.deb" <splunk user>@<splunk IP>:/home/<splunk user>
    ```

3. From the Splunk VM, run the .deb file

    ```bash
    sudo apt install -f "/home/<splunk user>/splunk-9.0.1-82c987350fde-linux-2.6-amd64.deb"
    ```

4. From a terminal in the Splunk VM, change directory to `cd /opt/splunk/bin` and run the following commands:

    ```bash
    sudo -Hu splunk ./splunk start --accept-license
    sudo ./splunk stop
    sudo ./splunk enable boot-start -user splunk
    ### Only run the 'set deploy-poll' command on the search head and indexers
    sudo ./splunk set deploy-poll <deployment srv IP>:8089
    sudo ./splunk start
    sudo ./splunk status
    ```

    !!! note "Splunk user vs Operating System User"
        The command to enable the service above is referencing the **splunk** account that is a user on the Operating System.  The user is created during splunk install is only used within Splunk and is not available to the operating system.

    !!! warning "Splunk Admin"
        During the installation of Splunk an admin account is created.  The default admin account and password should be the same for each Splunk server.  If the default admin is not named **admin** this can cause conflicts with different splunk applications.  If an app, for example Enterprise Security, has a lot of objects they are typically owned by the **admin** user by name.  If this account doesn't exist these objects will be orphaned and not usable, most noticeably the saved searches.  Either make sure the default admin account is named **admin**, if an app with many objects is planned to be used, or remember to change the owner of the objects to the new admin account.

5. Once each Splunk installation is complete [configure LDAPS](../Step%206%20-%20Setting%20Up%20LDAP/2%20-%20Splunk%20LDAP.md) for login to each server.

After all of the kit services installation is complete don't forget to configure Splunk [applications](./4%20-%20Install%20Splunk%20Apps.md).
