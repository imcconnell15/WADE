# Splunk Forwarder Installation

## Gather the necessary files

It is recommended that the the latest version of Splunk Forwarder for each operating system type (Windows, Debian, etc) be downloaded for each setup. The steps below reference a version for example, but the version should be replaced with the latest version downloaded.  [Download Link for latest version](https://www.splunk.com/en_us/download/splunk-enterprise.html?locale=en_us) - account required.

!!! tip "Security Onion"
    Security Onion is Centos based, so download the **RPM** package.  The commands below are the steps for installing an **RPM** package.

## Installation for Security Onion

1. SCP the splunk forwarder to the SN-3000 sensor

     ```bash
     scp <splunkforwarder>.rpm <USERNAME>@<SENSOR_IP>:~/
     ```

2. On the sensor, run the following commands

     ```bash
     # Installs Splunk and then starts Splunk to create an admin user
     sudo rpm -i <splunk forwarder>.rpm
     cd /opt/splunkforwarder/bin
     sudo -Hu splunkfwd ./splunk start --accept-license
     ```

3. When splunk forwarder service starts initially it will ask you to create an admin account for splunk.  This admin account is only used within the splunk application, and the username should be `admin`. Set a password of your choice.

    !!! note inline end ""
        "Useradd : cannot create directory `/opt/splunkforwarder`" error can be ignored, just verify the `/opt/splunkforwarder` path is created.

     ```bash
     # Stop Splunk and enable it to run on startup as the user 'splunkfwd'
     sudo ./splunk stop
     sudo ./splunk enable boot-start -user splunkfwd
     # Configure the forwarder to check in with the deployment server
     sudo -Hu splunkfwd /opt/splunkforwarder/bin/splunk set deploy-poll <Deployment Srv IP>:8089
     sudo ./splunk start
     ```

!!! success "Restart Splunk"
    Wait for the sensor to check in to the Splunk Server. It may be required to restart the splunk_forwarder services on the sensor for it to register with the deployment server.

## Installation for Ubuntu

1. SCP the splunk forwarder to the Ubuntu server

     ```bash
     scp <splunkforwarder>.deb admin@<server IP>:~/
     ```

2. On the server, run the following commands

     ```bash
     sudo dpkg -i <splunk forwarder>.deb
     sudo -Hu splunkfwd ./splunk start –-accept-license
     sudo ./splunk stop
     sudo -Hu splunkfwd ./splunk enable boot-start -user splunkfwd
     sudo ./splunk start
     sudo -Hu splunk /opt/splunkforwarder/bin/splunk set deploy-poll <splunk server IP>:8089
     sudo reboot
     ```
