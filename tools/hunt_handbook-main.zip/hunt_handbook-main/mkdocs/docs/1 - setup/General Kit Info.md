# General overview

Background information for getting setup.

## Power Requirements

| Component                  | Typical Power Consumption | Maximum Power Consumption |
| -------------------------- | ------------------------- | ------------------------- |
| SN-3000 Sensor Node        | 133 W                     | 200 W                     |
| PA-440 Firewall            | 29 W                      | 34 W                      |
| SN-7000 Analytic Node      | 400 W                     | 600 W                     |
| Dell Mobile Precision 7560 | 120 W                     | 180 W                     |
| SW-2000 Switch             | 60 W                      | 192 W                     |
| Dell S4112F-ON             | 120 W                     | 180 W                     |
| Cisco C3560X               | 193 W                     | 290 W                     |
| Gigamon G-TAP ASF-21       | 220 W                     | 330 W                     |
| Gigamon G-TAP ASF-01       | 67 W                      | 100 W                     |
| Supermicro IPMI            | 10 W                      | 15 W                      |

## Default Credentials

The following is a list of all the default credentials and baud rates for hardware that is typically used.

| hardware | username | password | baud rate |
| --- | --- | --- | --- |
| Supermicro IPMI | ADMIN | ADMIN | - |
| Gigamon AF21 | admin | admin123A! | 115200 |
| Cisco WS-C3560CX | cisco | cisco | 9600 |
| Dell Tap Aggregator | admin | admin123A! | 115200 |
| Palo Alto | - | - | 9600 |
| Nvidia SW-2000 | admin | admin | 115200 |

## Utilizing Crash Cart for All Devices

1. Install Crash cart software from the provided USB drive
    - Choose the "Previous Driver Version" folder
    - Install "setup-1200514-startech.exe"
2. Plug in VGA and USB into corresponding ports on hardware.
3. Plug in grey cable into laptop
4. Press window key, type in "USB Crash Cart Adapter" and start the application (Note: if crash cart software is not found install the necessary software and drivers)
5. In the top left corner click "Keyboard" then click "more special keys..."
6. Power on the device and wait for the graphical user interface (GUI) to populate

## Extra Information

### Reset Gigamon ASF-21 Tap

- Connect to console port (baud 115200 - admin/admin123A!)
- `enable` - `conf t` - `config jump-start`

### 100gb card in SN7000 -- QSFP modes

This is only need if the drivers are not included with ESXi.  ESXi version 7 update 3c or newer includes the drivers.

- Download the Intel EPCT tool
- [Intel EPCT](https://www.intel.com/content/www/us/en/download/19435/ethernet-port-configuration-tool-all-supported-oss.html)
- Extract tool
- scp ESXi version to ESXi
- ssh esxi -- run tool `./ecptn64e -h`
- QSFP Options

![QSPF Matrix](../assets/images/qspf_image.png)
