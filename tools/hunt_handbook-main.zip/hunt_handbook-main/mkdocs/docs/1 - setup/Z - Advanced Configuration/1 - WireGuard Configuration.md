# Setting Up WireGuard Server/Clients

## WireGuard Server Configuration (pfSense)

1. Log into pfSense and go to **System > Package Manager > Available Packages**
2. Search for WireGuard and select **“+ Install”**
    1. You may need to update pfSense to install WireGuard. This can be done from **System > Update**. Complete the update, then come back and install WireGuard
3. Go to **VPN > WireGuard** and select **“+ Add Tunnel”**
    1. Make sure **“Enable Tunnel”** is checked
    2. Enter a description
    3. Enter a port for the tunnel communications (Default is 51820)
    4. Select **“Generate New Keys”** and copy the public key. Save this to a text file on an external drive.
    5. Enter the tunnel address. For ease, it's best to make this a /24
    6. Select **“Save Tunnel”**
4. **STOP!** Before continuing, you will need the client's public key to complete the setup. Refer to client setup below and then return.
5. Click on **VPN > WireGuard > Peers** and select **“+ Add New Peer”**
    1. Make sure **“Enable Peer”** is checked
    2. Select the tunnel you just created
    3. Name the peer in the description
    4. Enter the client's public key that was previously stored on an external hard drive
    5. Under allowed IPs, enter the client's IP address as a /32
    6. Select **“Save Peer”**
6. Go to **Interfaces > Assignments**
    1. Next to the tunnel created, select **“+ Add”**
7. Go to **Interfaces > OPT1**
    1. Change the description to **“WG”** or whatever you want to name the interface (Note: Don’t name it “WireGuard”. This will make it confusing when editing firewall rules because there will be two WireGuards listed in rules.)
    2. Change IPv4 Configuration Type to **“Static”**
    3. Scroll to IPv4 Address and enter the tunnel address (e.g. 10.83.100.1/24)
    4. Select **“Save”**
8. Go to **Firewall > Rules > WAN** and select **“Add”**
    1. Change Protocol to **UDP**
    2. Change Destination Port Range to whatever port was selected for the tunnel (Step 3.3)
    3. Leave the rest of the settings default and select **“Save”**
9. Go to **Firewall > Rules > Wireguard** and select **“Add”**
    1. Change protocol to **Any**
    2. Leave the rest of the settings default and select **“Save”**
10. The tunnel should now be established and good to go

## WireGuard Client Configuration (pfSense)

1. The client configuration for pfSense is the exact same as the server setup, the only difference is you'll be entering the server as a peer and putting in the respective public keys.

## WireGuard Client Configuration (Windows)

1. Go to [Wireguard Download](https://www.wireguard.com/install/) and download the Windows installer
2. Once installed, open the WireGuard application and select **“Add Empty Tunnel”**
3. Name the tunnel anything you want, then save the public key to a text file on an external drive
4. Enter the information from the image below:
5. **Address:** This is the IP address you want to assign to the client you are currently on. It must be within the IP range of the tunnel already established on the server
6. **DNS:** This is the DNS server you want to use once the tunnel is established. Generally, this should be the internal IP address of pfSense.
7. **PublicKey:** This is the public key of the server. Copy and paste this from the text file saved on the external drive.
8. **AllowedIPs:** The configuration in the image below is wrong. This should be 0.0.0.0/0 to route all traffic through the tunnel.
9. **Endpoint:** This is the public facing IP of pfSense. This can be found on the pfSense VM within ESXi/vSphere. It is the IP address assigned to the WAN interface. If your configuration is being routed through the internet, this will be the public facing IP of the network your server is in. The IP address is followed by the port the tunnel was configured to use on the server.
10. Select **“Save”** and then complete the setup for the peer on the server (Step 5 on the configuration above)
11. Once the server and peer configuration is complete on the server, activate the VPN and you should have connection to the network.

![Edit Tunnel](./edit_tunnel.jpeg)

## WireGuard Client Configuration (Ubuntu)

- Run the following commands:

  ```bash
  sudo apt install wireguard
  sudo apt install openresolv
  cd /etc/wireguard
  sudo wg genkey | tee privatekey | wg pubkey > publickey
  ```

- This command will create two files, publickey and privatekey. Copy the public key to an external hard drive.
- **STOP!** You need to configure this peer on the server at this point. Do that and return.
- Create a configuration file in **/etc/wireguard** with the following command:

  ```bash
  nano <configName>.conf
  ```

- Once you are editing the config file, enter the information from the image below:

![wireguard.conf](./wireguard_conf.jpeg)

- **PrivateKey:** Copy and paste this from the "privatekey" file generated previously.
- **Address:** This is the IP address you want to assign to the client you are currently on. It must be within the IP range of the tunnel already established on the server.
- **DNS:** This is the DNS server you want to use once the tunnel is established. Generally, this should be the internal IP address of pfSense.
- **PublicKey:** This is the public key of the server. Copy and paste this from the text file saved on the external drive.
- **Endpoint:** This is the public facing IP of pfSense. You can find it on the pfSense VM within ESXi/vSphere. It is the IP address assigned to the WAN interface. If your configuration is being routed through the internet, this will be the public facing IP of the network your server is in. The IP address is followed by the port the tunnel was configured to use on the server.
- **Allowed IPs:** This should be set to 0.0.0.0/0 to route all traffic through the tunnel.
- Once the conf file is created, save it and run the following command:

  ```bash
  wg-quick up <confFileName>
  ```

- **NOTE:** When running the command above, leave off the ".conf" from the filename.
- The configuration should be good, and you should now be able to reach pfSense.