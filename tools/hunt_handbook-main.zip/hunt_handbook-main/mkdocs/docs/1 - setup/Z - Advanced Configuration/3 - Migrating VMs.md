# VM Migrating VMs

1. Login to vSphere and on the left-pane there are four graphical buttons. Click on the second  button from the left (shaped like a piece of paper)
2. In the left-pane expand the tree down to “VMware vCenter Server” and right-click. Navigate to and click “Migrate...”
    1. Select a migration type: Enable the Radio Button “Change both compute resource and storage”
    2. Select a compute resource: Navigate to desired host (Select a cluster, host, or resource pool to run the VMs)
    3. Skip Select Storage
    4. Select Networks: Source and Destination Network (Change destination from VM Network  LAN)
    5. Select vMotion Priority: Enable Radio Button “Schedule vMotion with high priority”
    6. Ready to Complete: Review and Click Finish (will take several minutes)
