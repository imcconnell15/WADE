# VM Content Libraries

## Creating Content Libraries

1. Login to vSphere and Click on the hamburger menu in the top left next to “vSphere Client” Navigate to and Select “Content Libraries”
2. This will open the Content Libraries Menu Click “Create”
    1. Name and Location: Assign a Name, Notes, and vCenter Server
    2. Configure Content Library: Enable the Local Content Library Radio Button
    3. Apply Security Policy: OVF Default Policy
    4. Add Storage: Select a Storage Location for the library Contents
    5. Ready to Complete: Review and Click Finish
