# VM Setting Up VDS

## Setting up a VDS

!!! warning "LAN Network"
    This procedure depends on there being a LAN network already configured.  If the LAN connection for the servers (pfsense LAN interface) is on the VMNetwork then migrating the VMs to the LAN VDS will cause the servers to lose connectivity.

1. Login to vSphere and on the left-pane there are four graphical buttons. Click on the far right Networking button (shaped like a circle of connecting lines)
2. Right click the top level IP Address and Navigate down to Distributed Switch. Select New Distributed Switch
    1. Name and Location: Provide a Name for your Distributed Switch, Location Datacenter
    2. Select Version 7.0.3 – ESXi 7.0.3 and later (or whichever version is necessary to select)
    3. Configure Settings:
        1. Network Offloads Compatibility : **None**
        2. Number of uplinks 3 (provide minimum of 1, default is 4)
        3. Network I/O Control: **Enabled**
        4. Default Port Group: **Checked**
        5. Port Group Name: Assign a Port Group Name (ie LAN)
    4. Review and Click Finish
3. Returning to the main Network Menu, in the left-pane right-click the name of your Distributed Switch and Select “Add and Manage Hosts”
    1. Select Task: Enable Radio Button “Add Hosts”
    2. Select Hosts: Check the box for Select All or Select desired Hosts to add
    3. Manage Physical Adapters: Under the “Adapters on all hosts” - select **auto-assign** for the uplink

        !!! warning "LAN separate from WAN"
            It is preferred to use different distributed switches for LAN and WAN.  If the LAN traffic is on the same distributed switch as the WAN traffic, the LAN traffic will be routed through the WAN interface, bypassing the firewall.

        !!! warning "VMNetwork"
            Don't create a distributed switch for the VMNetwork!  You can lock yourself out of the the management.

        !!! note "Keep Uplinks Similar"
            It is preferred to use the same vmnic on different hosts assigned to the same uplink - ie vmnic0 to LAN vswitch equals uplink 1, vmnic0 to LAN vswitch on another host equals uplink 1

    4. Click next on Manage VMkernal Adapters (no changes necessary) - vmk0 is the management interface
    5. Migrate VM networking - check the "Migrate virtual machine networking" box
        1. Configure per virtual machine
        2. Click the filter next to source port group
        3. Search for desired port group (ie LAN)
        4. Select the VMs to migrate and click **"Assign Port Group"**
    6. Ready to Complete: Review number of managed hosts to add and number of network adapters to update. Click Finish
    7. You will return to the Distributed Switch Menu and see the Hosts that are now assigned
4. Right-click the Distributed Switch in the left-pane again Navigate to Distributed Port Group and Select New Distributed Port Group
    1. Name and location: Name: LAN (or whatever is desired), Location: Whatever you named your Distributed Switch
    2. Configure Settings
        1. **Port Binding:** Static Binding
        2. **Port Allocation:** Elastic
        3. **Number of Ports:** 8 (Or whatever is needed)
        4. **Network Resource Pool:** (Default)
        5. **VLAN Type:** VLAN
        6. **VLAN ID:** 10 (Or whatever is needed)
    3. Ready To Complete: Review and Click Finish
