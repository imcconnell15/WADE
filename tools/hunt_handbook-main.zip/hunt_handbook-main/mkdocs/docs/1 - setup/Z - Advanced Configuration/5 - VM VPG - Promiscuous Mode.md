# VM VPG – Promiscuous Mode

## Setting a Virtual Protected Group to Promiscuous Mode

!!! note "Note:"
    Repeat the [VDS SOP](4%20-%20Setting%20Up%20VDS.md) steps to create a switch for tapping, assign uplinks a tap/aggregator will be connected to, and create a port group for the VM

1. Login to vSphere and on the left-pane there are four graphical buttons. Click on the far-right Networking button (shaped like a circle of connecting lines)
2. Click on the desired uplink within the Switch you’d like to set
3. In the right-pane Select the Configure Tab, then Policies, Navigate to Promiscuous Mode and Click Edit
4. Select the Security Tab and under the Promiscuous Mode dropdown menu Select Accept
5. Click OK
