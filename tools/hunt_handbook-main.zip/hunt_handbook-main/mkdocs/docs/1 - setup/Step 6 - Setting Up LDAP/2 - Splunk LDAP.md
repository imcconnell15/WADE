# LDAP for Splunk

1. Server settings...  
2. Authentication methods...  
3. LDAP Bind host: **ldap.&lt;your.domain&gt;**  
    1. port: **636**  
    2. Check box next to **SSL Enabled**  
    3. Bind DN: ex. **cn=readonly**,dc=&lt;your&gt;,dc=&lt;domain&gt;  

!!! warning "Use READONLY"
    For security sake use the readonly account and not the admin account.

4. User Settings  
    1. User base DN: ex. **ou=users,dc=&lt;your&gt;,dc=&lt;domain&gt;**  
    2. User name attribute: **uid**  
    3. Real name attribute: **cn**  
    4. Email attribute: **mail**  
    5. Group mapping: **uid**  
5. Group Settings  
    1. Group base DN: ex. **ou=groups,dc=&lt;your&gt;,dc=&lt;domain&gt;**  
    2. Group name attribute: **cn**  
    3. Static member attribute: **memberuid**  

!!!note "User and Group filter"
    This depends on where the users/groups are created in AD.  The example above assume that all the users reside under an organizational unit called "Users" which is a child object of the top level and groups are in an organizational unit called "Group" which is a child object of the top level.

!!!note "Nested Groups"
    Nested groups can be used, ie Splunk Groups as an organizational unit under groups and all the groups which contain user there.  If used the nested groups should be selected.

!!!tip "Nested Groups"
    It's easier to keep the organizational layout simplified and flatter without a bunch of nested groups.
