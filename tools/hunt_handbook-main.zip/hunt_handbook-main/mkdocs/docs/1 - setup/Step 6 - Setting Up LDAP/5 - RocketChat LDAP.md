# LDAP for Rocket Chat

## First Admin
Once Rocketchat is install the first user created is the default Admin. Be sure to make this a generic account and not a team member's account.

!!!note "First Admin"
    The first user to login is the default RocketChat Admin.  Make a dedicated admin account, don't use a normal user as the Admin.

## Rocketchat LDAP

1. goto Administration > **LDAP**
2. Connection Settings:
    1. Enable
    2. server type: **active directory**
    3. host: ex. **ldap.&lt;your.domain&gt;**
    4. port: **636**
    5. reconnect: **on**
    6. authentication
        1. enable
        2. user DN: ex. cn=readonly,dc=&lt;your&gt;,dc=&lt;domain&gt;

            !!! warning "Use read only account"
                For security's sake use the readonly account not the admin.

        3. password: ldap **readonly** password
    7. encryption
        1. **SSL/LDAPS**
        2. CA Cert:
            1. navigate to https://min.your.domain/go
            2. click on ca.crt
            3. highlight and copy the ca certificate information
            4. paste into CA Cert box
3. User Search:
    1. find user after login: **enable**
    2. search filter:
        1. based DN: ex. **ou=users,dc=&lt;your&gt;,dc=&lt;domain&gt;**
        2. search field: **uid**
4. Disable 2FA:
    1. Accounts (scroll down alot) > Two Factor Authentication
    2. Turn Off

!!!note "Search filter"
    This depends on where the users are created in AD.  The example above assume that all the users reside under an organizational unit called "Users" which is a child object of the top level.
