# LDAP for VCSA

1. From the VCSA main screen choose the hamburger menu in the top left corner and select "Administration"
2. Select "Configuration" under "Single Sign-On"
3. From the "Identity Provider" select "Identity Sources and hit **"ADD"**
4. On the screen that opens change the "Identity Source Type" to "OpenLDAP"
5. Give the "Identity source a name"
6. Enter the "Base DN for users" ie "ou=users,dc=example,dc=com"
7. Enter the "Base DN for groups" ie "ou=groups,dc=example,dc=com"
8. Enter the "Domain name" ie "example.com" - Skip Domain Alias
9. Enter the readonly account name for the Username ie "cn=readonly,dc=example,dc=com"
10. Enter the password for the readonly account
11. Enter the "Primary Server URL" ie "ldaps://ldap.example.com:636"
12. A Certificate **MUST** be provided - download the **ca.crt** from GoStatic, browse to it and upload it

## Add user to permissions to VCSA

Add a user to the server permissions to test the LDAP connection

1. From the VCSA main screen choose the hamburger menu in the top left corner and select "Administration"
2. Select "Users and Groups" under "Single Sign-On"
3. Select "Groups" and then click on the "Administrators" group
4. From the group screen select "ADD MEMBERS"
5. Change the domain from "vsphere.local" to the domain you created ie "example.com"
6. Search for the user you want to add, the search results will show the user's name, click on the name to "ADD"
7. Click "Save" to add the user to the group
