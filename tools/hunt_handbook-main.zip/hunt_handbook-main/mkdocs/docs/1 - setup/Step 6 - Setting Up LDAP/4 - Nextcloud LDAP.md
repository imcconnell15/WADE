# LDAP for Nextcloud

## Enable LDAP Application

1. Log in as the admin user
2. **Click** the user's profile, either a letter or image, at the top right of the webpage.
3. click on **Apps**
4. Under "**Your apps**" locate "**LDAP user and group backend**" in the pane to the right.
5. Click **Enable** for the app.

## Complete the LDAP Configuration

!!!warning LDAP
    Nextcloud's LDAP configuration is **Janky**.  The steps below are the correct informaiton, but sometimes a few tries are required to get it to save a parse correctly.

!!!warning Refresh
    If you're certain all the settings are correct sometimes Nextcloud won't show the appropriate groups in the dropdown.  Navigate away from the LDAP setting, refresh the browser and try again.

!!!note "Try LDAP to verify settings - but LDAPS must be the final configuration"
    If this does not work switch to LDAP in the server settings by changing `ldaps://` to `ldap://` and switch to port "389". if you are able to connect switch back to LDAPS and using port 636

!!!note "Enumerate groups"
    Test the LDAP connection by enumeration user or groups.  Sometimes the LDAP with give an error but the user and groups will enumerate.  If the users and groups enumerate the configuration is successful.

1. Once enabled **click** on the user profile again in the top right corner.
2. click **Administration settings**
3. On the left hand side of the webpage under the "**Administration**" section click  " **LDAP/AD integration**"
4. Fill Out the following information:
    1. Server
        - host: ldaps://ldap.&lt;your.domain&gt;
        - port: 636
    2. User DN: &lt;LDAP admin or readonly account&gt;
        - EX **cn=readonly**,dc=test,dc=internal
    3. Password: &lt;Password for account&gt;
    4. Click **Save Credentials**
    5. Base DN:
        1. dc=test,dc=internal
    6. Advanced:
        1. In the upper right hand corner of the LDAP window click **Advanced**
            1. Under the Connection Settings **Check**
                1. **Configuration Active**
                2. **Turn off SSL certificate validation**
            2. Under **Directory Settings**
                1. Locate **Group-Member association**
                2. Select **memberUid** from the dropdown menu
                3. Check the box for **Nested Groups**
    7. Click the **Group** menu in the LDAP pane:
        1. ensure that **posixGroup** is selected in "**Only these object classes**"
        2. select appropriate groups from "**Only from these groups**", ie Nextcloud
