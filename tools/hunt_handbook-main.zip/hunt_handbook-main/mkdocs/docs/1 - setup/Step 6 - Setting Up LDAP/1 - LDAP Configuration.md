# LDAP Configuration

 This is a walk-through of how to do a basic configuration of OpenLDAP

 !!!note "Note"
    Names with special characters will not work in LDAP. Leave these characters out

1. Go to your **links** page.
   1. EX: `https://min.example.com/links`
2. Under the Network Tab click on **phpLDAPAdmin**. This will open the web interface in a new tab.

## Create Basic Directory Structure

   1. Click **Login**
   2. Enter the appropriate information
      1. Login DN: **cn=admin,dc=example,dc=com**
      2. Password: Password that was entered during min setup.
   3. On the left hand side of the web page click on the top level domain (TLD)
      1. EX: dc=example,dc=com
   4. Click on the ⭐ **Create a child entry**
   5. Click  👨‍👧‍👦**Generic: Organizational Unit** (OU)
      1. Give it a name for the group of users that will be placed in to
      2. EX: Users
   6. Click **Create Object** -> **Commit**
   7. Click on the TLD
   8. Create another OU for groups
   9. Optionally create OUs under your existing OUs for groups of users or different groups you will have.

```conf
Example Layout:

- Users
  - Analysts
  - Admin
- Groups
  - Nextcloud_Groups
  - Splunk_Groups
```

***

## Create a Default Group

 1. Click your preferred group's OU you want to create the default group in on the left hand side of the webpage
 2. Click on the ⭐ **Create a child entry**
 3. Click **:family: Generic: Posix Group**
 4. Give the group a name
    1. EX: Default, Analysts ...

***

## Creating User Accounts

!!! note "Organizational Units"
   It is helpful to keep groups and users in different organizational units.  Select the base domain and **Create a child entry** and choose **Generic: Organizational Unit** (OU) to create a new OU, ie users, groups, etc.

1. Click your preferred groups OU you want to create the user
2. Click on the ⭐ **Create a child entry**
3. Click 🙍‍♂️**Generic: User Account**
4. Fill out the appropriate Fields
     1. **First Name**
     2. **Last Name**
     3. Enter a temporary Password for the account

        !!! note inline end ""
            The users uid is be first inital lastname
            EX: fbaggins

     4. Under **GID Number** Drop Down select a group everyone should be a member of ie **analysts** or **nextcloud**
     5. Click **Create Object** -> **Commit**

!!! tip "Self Service Password"
    Users should change their password using the Self-Service-Password application which is conveniently located on the links page

***

## Add User email address

1. Under the users at the top of the right hand side of the web page click **Add new attribute**
2. In the **Add Attribute** box, select **Email** from the drop-down

    !!! note inline end ""
        When adding the email attribute from the dropdown menu pressing the "E" key 3 times will take you to "Email"

3. In the Text Box enter the newly created Users Username (FLast) followed by @example.com
   1. EX: fbaggins@example.com
4. Click **Update Object** x2



!!! note "Email login"
    An email address is required to be used when authenticating to TheHive and Cortex.

***

## Creating groups

1. On the left side of the web page click on the desired OU to create the group in
2. Click on the ⭐ **Create a child entry**
3. Click **:family: Generic: Posix Group**
4. Enter the groups name
5. Click **Create Object** -> **Commit**

!!!note
    When creating a group it is recommended to add at least one user to the group. other wise the memberUid attribute will not exist
    and will have to be created like the Email attribute for the users.

!!!note
    Users can be added during the creation of the group, but i find it easier to do after the group is created.

***

## Adding Users to Groups

1. Click on the Group you wish to add a user(s) to
2. Under **memberUid**, click **modify group members**
3. Select the members you wish to add to the group
4. click **add selected**
5. click **Save Changes** -> **Update Object**
