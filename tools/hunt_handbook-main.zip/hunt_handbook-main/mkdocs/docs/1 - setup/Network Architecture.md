## Summary

This document is meant to serve as an example or guide as to how a standard kit build network should look. This framework can and should be modified to fit the needs of the mission.

## Network Architecture

### VLANs

| VLAN ID | Purpose   | Subnet/<br>Netmask                 | Gateway      | Usable IPs  |
| ------- | --------- | ---------------------------------- | ------------ | ----------- |
| 10      | Services  | 10.83.69.0/26<br>255.255.255.192   | 10.83.69.1   | .2 - .62    |
| 20      | Users     | 10.83.69.64/27<br>255.255.255.224  | 10.83.69.65  | .66 - .94   |
| 50      | Managment | 10.83.69.192/26<br>255.255.255.192 | 10.83.69.193 | .194 - .254 |

### DMZ (10.69.83.0/30)
!!! note
	If you are running a physical Palo Alto to a Virtual Palo Alto on ESXi, you will need a DMZ network. This is an example of a DMZ network

| Service            | IP Address |
| ------------------ | ---------- |
| Palo Alto Physical | 10.69.83.1 |
| Palo Alto Virtual  | 10.69.83.2 |

### Services

| Service                  | IP Address       |
| ------------------------ | ---------------- |
| Gateway                  | 10.83.69.1       |
| VCSA                     | 10.83.69.10      |
| Autopsy                  | 10.83.69.10      |
| Timesketch               | 10.83.69.11      |
| Velociraptor             | 10.83.69.12      |
| Assembly Line            | 10.83.69.13      |
| Carbon Black             | 10.83.69.14      |
| UNASSIGNED               | 10.83.69.15 - 19 |
| Security Onion Manager   | 10.83.69.20      |
| Sec Onion Sensor 1       | 10.83.69.21      |
| Sec Onion Sensor 2       | 10.83.69.22      |
| Sec Onion Sensor 3       | 10.83.69.23      |
| Sec Onion Sensor 4       | 10.83.69.24      |
| Sec Onion Sensor 5       | 10.83.69.25      |
| Sec Onion Sensor 6       | 10.83.69.26      |
| Sec Onion Search Node 1  | 10.83.69.27      |
| Sec Onion Search Node 2  | 10.83.69.28      |
| UNASSIGNED               | 10.83.69.29      |
| Splunk Search Head       | 10.83.69.30      |
| Splunk Indexer 1         | 10.83.69.31      |
| Splunk Indexer 2         | 10.83.69.32      |
| Splunk Indexer 3         | 10.83.69.33      |
| Splunk Deployment Server | 10.83.69.34      |
| UNASSIGNED               | 10.83.69.35 - 39 |
| Internal Sec Onion       | 10.83.69.40      |
| Internal Splunk          | 10.83.69.41      |
| Internal Velociraptor    | 10.83.69.42      |
| UNASSIGNED               | 10.83.69.43 - 49 |
| MIN                      | 10.83.69.50      |
| Iris                     | 10.83.69.51      |
| Mattermost               | 10.83.69.52      |
| PiHole                   | 10.83.69.53      |
| Nextcloud                | 10.83.69.54      |


### Users (10.83.69.64/27)
This subnet should be entirely kit laptops, and any host workstation VMs (SIFT/Kali). The IPs in this range will likely be assigned with a DHCP lease. 

### Management (10.83.69.192/26)

| Service                   | IP Address         |
| ------------------------- | ------------------ |
| Gateway                   | 10.83.69.193       |
| Physical Firewall Web GUI | 10.83.69.194       |
| Virtual Firewall Web GUI  | 10.83.69.195       |
| VCSA                      | 10.83.69.196       |
| UNASSIGNED                | 10.83.69.197 - 200 |
| ESXi Stack 1              | 10.83.69.201       |
| ESXi Stack 2              | 10.83.69.202       |
| ESXi Stack 3              | 10.83.69.203       |
| IPMI SN-7000 1            | 10.83.69.204       |
| IPMI SN-7000 2            | 10.83.69.205       |
| IPMI SN-7000 3            | 10.83.69.206       |
| UNASSIGNED                | 10.83.69.207 - 210 |
| IPMI SN-3100 1            | 10.83.69.211       |
| IPMI SN-3100 2            | 10.83.69.212       |
| IPMI SN-3100 3            | 10.83.69.213       |
| IPMI SN-3100 4            | 10.83.69.214       |
| IPMI SN-3100 5            | 10.83.69.215       |
| IPMI SN-3100 6            | 10.83.69.216       |
| UNASSIGNED                | 10.83.69.217 - 220 |
| SW-2000 MGMT 1            | 10.83.69.221       |
| SW-2000 MGMT 2            | 10.83.69.222       |
| SW-2000 MGMT 3            | 10.83.69.223       |
| UNASSIGNED                | 10.83.69.224 - 230 |
| ASF-01 MGMT 1             | 10.83.69.231       |
| ASF-01 MGMT 2             | 10.83.69.232       |
| ASF-01 MGMT 3             | 10.83.69.233       |
| ASF-21 MGMT 1             | 10.83.69.234       |
| ASF-21 MGMT 2             | 10.83.69.235       |
| ASF-21 MGMT 3             | 10.83.69.236       |
| Aggregator MGMT           | 10.83.69.237       |
| UNASSIGNED                | 10.83.69.238 - 250 |
| Admin Laptop 1            | 10.83.69.251       |
| Admin Laptop 2            | 10.83.69.252       |
| Admin Laptop 3            | 10.83.69.253       |
| Admin Laptop 4            | 10.83.69.254       |
