# Import SSH Keys

## Windows to Linux

1. Open CMD and run the command `ssh-keygen`
2. This command generates an SSH key in the C:\Users\<USERNAME>/.ssh directory
3. Go to this directory and look for “id_rsa.pub”
4. Use WinSCP (or your desired method) to get this file to the device you’d like to SSH into without a password
5. SSH to the desired device and run the following commands:
    1. `cat ~/id_rsa.pub >> ~/.ssh/authorized_keys`
6. You should now be able to ssh to this device without needing to enter a password

## Linux to Linux

1. Run the following commands:
    1. `ssh-keygen`
    2. `ssh-copy-id <USERNAME>@10.83.100.XXX`
    3. Enter the password to login and the setup is complete
2. You should now be able to ssh to this device without needing to enter a password
