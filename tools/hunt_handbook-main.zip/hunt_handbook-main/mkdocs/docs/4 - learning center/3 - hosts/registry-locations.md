# Registry Locations

A short list of registry locations to check, which should contain additional information about why.

- `HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Paths` - What files are excluded from Windows Defender scanning
- `HKLM\SOFTWARE\Policies\Microsoft\Windows Defender\Exclusions\Processes` - What files are excluded from Windows Defender scanning
