# Operation Tainted Love

A blog post about APT activity highlights some concepts that could be used by many of malicious cyber actors as a generic tactic. [Original Blog Post: Operation Tainted Love](https://www.sentinelone.com/labs/operation-tainted-love-chinese-apts-target-telcos-in-new-attacks/). Malicious cyber actors frequently place files in new folders in the root drive of the operating system.  Examine the hosts filesystem and catalog the folders in the root of the operating system drive.  Pay special attention to any folders that are not created by default, ie `C:\WINDOWS`.

Also a tactic to evade file scanners is to split a file into multiple chunks and reassemble on the host using built-in/available commands.  Logs should be examine for this activity, ie using the `type` command (as pictured below).  Network traffic should look for files being transfered that have been chunked using the linux split command default naming, for example `xaa`, `xab`, `xac`, ....

![Combination using type command](../../assets/images/combine-with-type.png)
