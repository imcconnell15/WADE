# jq

`jq` is not a native command with most default installations of various linux.  Be sure to add it: `apt install jq`

- Once added `jq` is the best way to parse zeek logs (which must be in the JSON format) from the command line.
- Fields with a `.` in the name must be surrounded by quotes, for example `"id.orig_h"`

## Notes

- JQ select is SLOW - `zgrep` is faster:
- `zcat dns.*.gz | jq -c 'select(."id.orig_h" == "172.16.7.11")' | wc -l` -- 45 seconds
- `zgrep -h '"id.orig_h":"172.16.7.11"' */dns.*.Gz | jq -c '.' | wc -l` -- 8 seconds
- use `todate` with jq for epoch time conversion: `zcat 2019-12-09/dns.17\:00\:00-18\:00\:00.log.gz | head -n 1 | jq -cr '.ts |= todate | .ts'`

## Examples of JQ with Zeek logs

- Use zcat to profile DNS response codes

```bash
zcat dns.*.gz | jq -r '.rcode_name' | sort | uniq -c | sort -nr
```

- Select the "NOERROR" response code and sort those

```bash
zcat dns.*.gz | jq -r 'select(.rcode_name == "NOERROR") | .qtype_name' | sort | uniq -c | sort -nr
```

- Exclude the "NOERROR" queries and return the Query Type and Response code of the errors.

```bash
zcat 2023-02-*/dns.*.gz | jq -cr 'select(.rcode_name != "NOERROR") | { qtype_name, rcode_name }'  | sort | uniq -c | sort -nr
```

- Top 20 DNS queries in the logs for "NOERROR" and exclude "NOERROR"

```bash
zcat dns.*.gz | jq -r 'select(.rcode_name == "NOERROR") | .query' | sort | uniq -c | sort -nr | head -n 20
zcat dns.*.gz | jq -r 'select(.rcode_name != "NOERROR") | .query' | sort | uniq -c | sort -nr | head -n 20
```

- Combine the ERROR responses query with the answers -- **THE -cr needs to be added to jq**

```bash
zcat dns.*.gz | jq -cr 'select(.rcode_name != "NOERROR") | {query, answers}'
 | sort | uniq -c | sort -nr | head -n 20
```

- List of hosts that queried for a given host

```bash
zcat dns.*.gz | jq -cr 'select(.query == "ipwho.is") | ."id.orig_h"' | sort | uniq -c | sort -nr
```
