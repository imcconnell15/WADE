# Overview

## Clone Ansible-Roles-for-Splunk

```bash
git clone https://github.com/splunk/ansible-role-for-splunk
```

DO NOT get this confused with `splunk-ansible` which is a completely different project from Splunk that builds the Splunk services on Docker.  This project will install Splunk as an application on a host os.

## Simple start up

There are many settings that can be modified in the files that come with Ansible Roles for Splunk.  In a basic setup (ie a standalone splunk server) the following two files MUST have a few settings defined for the setup.  The files are `inventory.yml` and `main.yml` in the locations below.

```text
├── environments
│   ├── development
│   └── production
│       └── inventory.yml
├── LICENSE
├── passwd.yaml
└── roles
    └── splunk
        └── defaults
            └── main.yml

```

## Ansible basics

- Install ansible-playbooks: `sudo apt install ansible-playbooks`
- Make sure the account you are currently logged into has an ssh key: `ssh-keygen`
- Ensure this ssh key is trusted be all the hosts that ansible will run against:

```bash
ssh-copy-id ubuntu@10.10.10.17
```

## Create an ansible vault to contain passwords as variables

```
ansible-vault create ./passwd.yaml
```

This will create a file `passwd.yaml` in the current directory that is a text file but the text is encrypted and gets decrypted using the `--ask-vault-pass --extra-vars '@passwd.yaml'` option when the playbooks run.

An example of an entry in `passwd.yaml` file (in the decrypted state) is:

```text
sa_password: password
```

This is a key value pair, the key is `sa_password` and the value is `password`.  This key can be refrenced in the ansible playbooks as a variable.  In a basic setup it is suggested to add a variable to represent the `sudo` password for the remote hosts (the server that splunk will run on) and the password for the splunk admin (to login to the web page).

Edit the `ansible-vault` file, it is a basic text file when editing and the editor opens into `vi` for editing

```bash
ansible-vault edit ./passwd.yaml
```

## Edit the `inventory.yaml` to reference the hosts

`inventory.yaml` tells ansible what the hosts are during the playbook run.  By default Ansible Roles for Splunk has them all uncommented but no hosts defined.  This will cause the playbook to fail unless each child item has a defined hosts.  For a basic setup comment out all the of the `inventory.yml` file and only leave the following.

```yaml
all:
  children:

    full:
      children:
        standalone:
          hosts:
            test-s1:
              ansible_ssh_host: 10.10.10.17
              ansible_ssh_user: ubuntu
              ansible_sudo_pass: "{{ my_sudo_pwd }}"
```

The example above tells Ansible Roles for Splunk to only install an instance of standalone splunk on the host at IP Address `10.10.10.17`.  Ansible will connect to the host will the user account `ubuntu`, this should be changed to match the actual username.  The `sudo` password is a varible that must exist in the `ansible-vault` as `my_sudo_pwd`.  When using the variable be sure to enclose it in quotes.

## Edit `main.yml`

The `main.yml` under meta contains ALOT of options that can be used throughout Ansible Roles for Splunk, but the most important for a simple setup is setting the `admin` password to enable login to the webpage.  It is also important to set the version of Splunk to install (the ansible roles will get Splunk from the internet during setup).

Set the password to a varible that is in the `ansible-vault` in this example the value in the `ansible-vault` is `sa_password`.  It is important that this is in quotes.

```yaml
splunk_admin_password: "{{ sa_password }}"
```

Also change the version of splunk and the matching hash for the ansible playbooks to download.  This can be obtained by downloading the latest Splunk Enterprise and verifying the version number and hash in the file downloaded (or the wget url)

```yaml
splunk_package_version: 9.0.4
build_id: de405f4a7979
```

## Go Time

From the root (of `ansible-role-for-splnk`) run the following `ansible-playbook` command which opens the `ansible-vault` file and uses the `splunk_install_or_upgrade.yml` role.  The role references many of the sub tasks and with the settings above should succeed.

```bash
ansible-playbook -i ./environments/production/inventory.yml ./playbooks/splunk_install_or_upgrade.yml --ask-vault-pass --extra-vars '@passwd.yaml'
```

## Deploymentclient.conf configuration

Variables can be defined in `main.yml` which will create a `deploymentclient.conf` on each host.  The following example defines all three that are REQUIRED to create a `deploymentclient.conf` file.  The `clientName` should be different for each host (since its the name of the client) defining this as `inventory_hostname` is the simplist method.  If more complex `clientName` convention is needed the reccommended method is to use `host_vars` and `group_vars`.  If any of the following three variables are set to undefined the playbooks won't execute.

```yaml
splunk_uri_ds: https://10.10.10.17:8089 
clientName: "{{ inventory_hostname }}" 
phoneHomeIntervalInSecs: 120 
```

## Universal forwarder configuration

The host file defines the role as either `full` (shown above) or `uf` for universal forwarder.  So that the `ansible-playbook` will detect `uf` it needs to be at the same level as `full` in the host yaml.  An example is show below.

```yaml
all:
  hosts:
    splunk1:
      ansible_ssh_host: 10.10.10.17
      ansible_ssh_user: ubuntu
      ansible_sudo_pass: "{{ my_sudo_pwd }}"
    so-standalone:
      ansible_ssh_host: 10.10.10.18
      ansible_ssh_user: so-admin
      ansible_sudo_pass: "{{ my_sudo_pwd }}"
 full:
   hosts:
     splunk1:
 uf:
   hosts:
     so-standalone:
```

## Add license

To automatically configure the license copy the license xml to cp `./roles/splunk/files/`.
Change the `main.yml` values:

```yaml
splunk_uri_lm: https://10.10.10.17:8089
splunk_license_file: [ license_file.xml ]
```

Due to ansible precedence `group_vars` or `host_vars` will supersede the `main.yml` settings.  The `ansible-roles-for-splunk` ships with example `group_vars` & `host_vars`.  So the license manager uri in `main.yml` is not as important as setting it in `.environments/production/group_vars/all.yml` add the license manager uri there or run the playbooks from a different folder so that it doesn't attempt to use the `group_vars`

## Authentication

AD authentication can be inluded in the ansible playbook set up.  The AD bind password should be saved to the `ansible-vault` and referenced as a variable in the playbook setup.
In `main.yml` set the following options:

```yaml
splunk_configure_authentication: true
ad_bind_password: "{{ ad_password }}"
splunk_authenticationconf: authentication.conf.j2
```

The `ad_bind_password` is the variable set in the `ansible-vault` in the example above is it `{{ ad_password }}`.

Once authentication has been enabled and the `ad_bind_password` set, the `authentication.conf.j2` must be modified to include the AD bind coniguration and group mappings.  The configuration from and existing AD confgured Splunk can be pasted in this file and the only change is to change the `ad_bind_password`

```yaml
# Place your authentication.conf here
# Suggest using a variable for this line:
# bindDNpassword = {{ ad_bind_password }}
# and encrypting ad_bind_password using ansible-vault encrypt_string, e.g. ansible-vault encrypt_string --ask-vault-pass 'var_value_to_encrypt' --name 'var_name'

[example.local]
SSLEnabled = 1
anonymous_referrals = 1
bindDN = cn=readonly,dc=example,dc=local
bindDNpassword = {{ ad_bind_password }}
charset = utf8
emailAttribute = mail
enableRangeRetrieval = 0
groupBaseDN = ou=splunk_groups,ou=groups,dc=example,dc=local
groupMappingAttribute = uid
groupMemberAttribute = memberuid
groupNameAttribute = cn
host = ldap.example.local
nestedGroups = 0
network_timeout = 20
pagelimit = -1
port = 636
realNameAttribute = cn
sizelimit = 1000
timelimit = 15
userBaseDN = ou=analysts,dc=example,dc=local
userNameAttribute = uid

[authentication]
authSettings = example.local
authType = LDAP

[roleMap_example.local]
admin = splunk_admin
user = splunk_user
```
