# Some Command Reference

## Easyrsa

Create a server certificate with `easyrsa`

```bash
./easyrsa build-server-full hostname.domain.local nopass
```

## Fastest extend with an extra disk

Ensure any remnant LVM signatures are removed first.

```bash
wipefs -a /dev/sdb /dev/sdc
```

[Source](https://www.cyberciti.biz/faq/howto-add-disk-to-lvm-volume-on-linux-to-increase-size-of-pool/)

```shell
sudo lvm
>pvcreate /dev/sdb
>lvmdiskscan -l
>vgdisplay
>vgextend ubuntu-vg /dev/sdb
>lvdisplay
>lvextend -l +100%FREE /dev/ubuntu-vg/ubuntu-lv
sudo resize2fs -p /dev/mapper/ubuntu--vg-ubuntu--lv
```

!!!note "Filesystem Types"
    `resize2fs -p` is for ext2/3/4 filesystem types.  If the filesystem type is **XFS** (Security Onion default) use `xfs_growfs`

## Show disks by ID / LABEL / PATH / UUID

```bash
ls -la /dev/disk/by-id /dev/disk/by-label /dev/disk/by-path /dev/disk/by-uuid
blkid
lsblk
```

## Test ping using salt

```bash
salt \* test.ping
```
