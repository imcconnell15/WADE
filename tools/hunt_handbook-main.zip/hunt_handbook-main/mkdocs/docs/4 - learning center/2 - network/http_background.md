# HTTP Background

General HTTP protocol information for background information.  Consult the [Mozilla Developers Guide](https://developer.mozilla.org/en-US/docs/Web/HTTP) for additional information.

## General HTTP Protocol

- Cookies two types: persistent and session
  - Persistent cookies remain after browser is closed
  - Session cookies are removed when the browser is closed (or private session ended )
- Authorization Header - generally used for prompt for user to enter credentials
  - Authorization Header can be used with APIs username/passwords - will seem weird since username/password are random hex strings.
  - Authorization Header is username/password in an easily reversible form.
- "X-Forwarded-For" - May indicate the client IP address that made the request before the proxy.  Privacy risk if this information is sent to internet servers - can be used to recon private IP space.
- "X-Served-By" - may contain the hostname of the CDN edge network that handled the request. Typically in US is the closest airport code.
- "X-Cache" - whether content was able to be served by the X-Served-By CDN

## Cookies - Google Analytics

Can be used to identify the time between visits to a site (if the older `utm` cookies are in use)

| Cookie | Meaning |
| --- | --- |
| `__utma` | Primary tracking cookie: Domain hash value, unique ID number, start time of first session, start time of previous session, start time of current session |
| `__utmb` | Used for visit duration calculation: Domain hash value, page view counter, outbound link countdown, start time of current session |
| `__utmz` | Entry tracking: Domain hash value, timestamp, visit counter, source counter, source/campaign/medium/search term data |
| `__utmv` | Custom site-defined variables |

| Cookie |  Value (Transmitted) | Value (Decoded) |
| --- | --- | --- |
| `__utma` | 10246176 | Domain hash value |
| | 2051716360 | Unique ID |
| | 1346693040 | Start of first visit (2012-09-03 17:24:00 UTC) |
| | 1346693040 | Start of previous session (2012-09-03 17:24:00 UTC) |
| | 1346693040 | Start of current session (2012-09-03 17:24:00 UTC) |
| | 1 | Number of sessions on this site |
| `__utmb` | 10246176 | Domain hash value |
| | 1 |  Pages viewed during session |
| | 10 | Outbound link countdown |
| | 1346693040 | Start of current session (2012-09-03 17:24:00 UTC) |
| `__utmz` |  10246176 | Domain hash value |
| | 1346693040 | Start of current session (2012-09-03 17:24:00 UTC) |
| | 1 | Number of visits with this cookie |
| | 1 | Number of unique sources with this cookie |
| | utmcsr=(direct) | Traffic source |
| | utmccn=(direct) | Campaign identifier |
| | utmcmd=(none) | Medium |
| | utmctr | Search terms used |
