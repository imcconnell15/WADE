# Lead Generation Prompts

## HTTP

- Do an analysis of the types of HTTP methods per day and compare across days.  An abnormal deviation in methods should indicate something different is occurring on the network.
- Examine HTTP response phrases.  Browsers only use the respond code, the phrase can be used to send arbitrary information.
- Look for excessive POST commands via HTTP to a host (exclusive of web servers - for web servers verify destination of POST).  Many RATS interact with client via POST commands.

## DNS

- Excessive spikes for `NXDOMAIN` DNS answers.
- DNS Answers change, ie from 0.0.0.0 to an IP Address.
- DNS queries to external DNS server that provides an Internal IP Address as the answer (DNS Rebinding).
- List DNS queries with punycode. Convert to unicode and look possible typo squatting.
