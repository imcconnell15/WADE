# Random ideas that might be combined into official section

## Explanation of Zeek Connections

What does a connection blocked/denied by the firewall look like? - sends a message to the requestor
ICMP RFC for blocked connections.
What does a connection rejected by the firewall look like? - silently no message

## taps

- what do you get from the taps.
  - should dat be filtered
  - should taps be moved
  - if you're constantly ignoring the traffic why is the tap there?

## RDP

- Is there RDP traffic?
  - allowed?
- RDP with screen resolution is definitely successful
  - ignore the scanners
- check the language

## information about dns traffic

typically UDP 53. can be other the other ports
IPv6 is AAAA records and can be lengthy and require TCP connection to hold the whole record.
what is too big to fit in a UDP connection?

## Things to compare over time

- ssh
- certificates
- smb

## SSH

What are the external IPs ssh into (private IPs)? allowed or not?
What are the internal IPs ssh connection to externally?
Is there SSH over non-standard ports?

What are the versions of SSH?
What segments can SSH allowed - ie user to server good or not? server farm ssh to external?
SSH long connections - can you trust zeek - implausible scenarios (lot of data short period of time)

Profile SSH connections allowed internal IPs destination compare time period over time period

## SMB

- run the bzar queries search for unallowed connections
- profile smb compare time period to time period
- find file servers based on the ton of traffic going to few hosts
- ADs have a ton of GP related SMB
  - login scripts? compile/compare/count

## http

-critical infrastructure allowed to browse the web?
-should admin boxes be surfing the internet with admin account?
-passwords in the clear - its 2023 come on
-all the porn.... really the questionable website people go to... shouldn't be filtered
-user agents - hard to profile - so many - but things like NMAP my stick out to help classify traffic
-use http traffic to find proxied by to identify proxies on the network

-in http traffic search for common exploit things - /etc/passwd, whoami, etc ...
    - sometimes these are seen but the pcap shows an error message sent back - get the pcap investigate if successful or not

## certs

- Self-signed certificates .. who why how
- already expired certs bu in use.
- splunk query for when the cert should be used by and when they expired
- new certs.
