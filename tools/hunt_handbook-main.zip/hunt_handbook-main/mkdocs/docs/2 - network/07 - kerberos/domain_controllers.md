# Identify the Domain Controllers

## Background

The Zeek Kerberos log can be used to help determine the Active Directory domain controllers based on the kerberos traffic.  An active directory domain controller should be issuing tickets for authentication, based on this information the Ticket-Granting-Ticket service (krbtgt) can be observed in the kerberos services.

### Identify Kerberos ticket-granting-ticket service

```spl
index=zeek_kerberos service=krbtgt* 
| stats values(service)  values(cipher) by id.resp_h
```
!!! warning "RC4-HMAC"
    If the cipher returns results that includes RC4-HMAC this is a very insecure protocol and has been depreciated.

!!! tip "NMAP Kerberos scan"
    The NMAP module to scan the kerberos service will attempt to get a ticket with `krbtgt/NM`.  If this is observed this an attempted NMAP scan against kerberos service.

## Expected outcomes

Log the servers which are granting ticket generating request as probable Active Directory domain controllers.  Try to confirm this information with the customer.  Once Active Directory domain controllers are identified they should be noted and examined for other services being utilized.

!!! note "AD Integrated DNS"
    The preferred implementation for Active Directory is Active Directory integrated DNS.  This means that members of the domain will go to the Active Directory domain controllers for DNS by default.  Large amounts of DNS queries to the AD servers further support that they are AD Domain Controllers.
