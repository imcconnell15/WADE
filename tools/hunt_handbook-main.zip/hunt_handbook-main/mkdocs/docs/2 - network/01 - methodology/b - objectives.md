# Objectives - Questions per phase

The following are some example actions and questions to help during each phase.

## Phase 1

- What are the DNS servers on the network?
- In an active directory domain the main DNS servers should be the domain controllers if DNS is active directory integrated.
- If the active directory domain does not have DNS integrated than there should be additional servers that are the DNS servers on the network.
- External DNS servers that are in use by clients.
- What are the Active Directory controllers on the domain?
- What are the file servers on the network?
- Find services on the network based on ports in use.
- What are the security device on the network?
- What internal host are open to the internet that external known scanners are able to access?
- Tune Suricata Alerts to remove noise
    - For example Window Update Delivery Optimization (WUDO) if this is known to be enabled.
- SMTP Traffic where?
- FTP Servers?
    - FTP – in the clear
- Telnet – clear text
- SSH to destinations - workstations or servers?
    - SSH over non-standard ports?
- SSL over non-standard ports?

- Consider TAP placement as network orientation proceeds.  If a network tap is not providing beneficial information or consistently has to be excluded in search - consider moving or removing the tap.

## Phase 2

- Use the MITRE BZAR queries or the zeek package to highlight DCE-RPC activity that maps to the MITRE framework for privilege escalation, remote service manipulation, and lateral movement.
- HTTP User Agents
    - Weird or non-existent HTTP USER Agent
- HTTP traffic going to servers with host header that is an IP address not a server
- Examine the referrer
- RDP from hosts to which endpoints
    - Language for the RDP connections
- File Mime type
- Suricata alerts for specific hosts
- Certificate Analysis
    - self-signed
    - expired
    - newly issued
- Software used by hosts
    - Common
    - Uncommon
- Unusual Protocols
- RFB
- IRC
- Tunnel
- [Outside of business hours](../../03%20-%20%20connections/after_working_hours/) – any interesting traffic stand out?
- SMB connections to IPC$ share
- NXDomain DNS queries
- DNS queries that return 0.0.0.0
- UT Toolbox to examine domain names for DGAs
- RC4 Cipher
- JA3-JA3S statistical analysis
- Single letter filename
- Unusual Mime Types

## Phase 3

- Provided Intel
- Station Keeping – revisit
- Compare the IP address involved in SSH connection week to week to determine new connection source or destination
- Compare RDP week to week
- In-depth protocol analysis
- Insecure protocol usage
- Passwords – clear text
- Keywords in HTTP URIs that are suspicious
    - Ping, cmd, shell, etc…
- Suspicious known valid websites that adversaries host programs or delivery malware from.
    - RAW GitHub
    - GitHub
    - Discord
    - Dropbox – API usage
