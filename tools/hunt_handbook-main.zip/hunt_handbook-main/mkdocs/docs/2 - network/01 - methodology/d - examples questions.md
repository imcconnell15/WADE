# Objectives - Questions per phase

## Phase 1

Example Actions and Questions:

- 1-Q1-DNS01: What are the DNS servers on the network?
- 1-Q1-DNS02: In an active directory domain the main DNS servers should be the domain controllers if DNS is active directory integrated.
- 1-Q1-DNS03: If the active directory domain does not have DNS integrated than there should be additional servers that are the DNS servers on the network.
- 1-Q1-DNS04: External DNS server that are in use by clients.
- 1-Q2-KER01: What are the Active Directory controllers on the domain?
- 1-Q3-SMB01: What are the file servers on the network?
- 1-Q4-: Find services on the network based on ports in use.
- 1-Q5: What are the security device on the network?
- 1-Q6: What internal host are open to the internet that external known scanner are able to access?
- Tune Suricata Alerts to remove noise
- For example Window Update Delivery Optimization (WUDO) if this is known to be enabled.
-
- SMTP Traffic where?
- FTP Servers?
- SSH to servers?

## Phase 2

- Use the MITRE BZAR queries or the zeek package to highlight activity that maps to the MITRE framework for privilege escalation, remote service manipulation, and lateral movement.
- HTTP User Agents
- Weird or non-existent HTTP USER Agent
- HTTP traffic going to servers with host header that is an IP address not a server
- Examine the referrer
- RDP from hosts to which endpoints
- Language for the RDP connections
- File Mime type
- Suricata alerts for specific hosts
- Certificate Analysis
- self-signed
- expired
- newly issued
- Software used by hosts
- Common
- Uncommon
- Unusual Protocols
- RFB
- IRC
- Tunnel
- Outside of business hours – any interesting traffic stand out?
- SMB connections to IPC$ share
- NXDomain DNS queries
- DNS queries that return 0.0.0.0
- UT Toolbox to examine domain names for DGAs
- RC4 Cipher
- JA3-JA3S statistical analysis
- Single letter filename
- Unusual Mime Types

## Phase 3

- Provided Intel
- Station Keeping – revisit
- Compare the IP address involved in SSH connection week to week to determine new connection source or destination
- Compare RDP week to week
- In-depth protocol analysis
- SSL over non-standard ports?
- SSH over non-standard ports?
- Insecure protocol usage
- FTP – in the clear
- Telnet – clear text
- Passwords – clear text
- Keywords in HTTP URIs that are suspicious
- Ping, cmd, shell, etc…
- Suspicious known valid websites that adversaries host programs or delivery malware from.
- RAW GitHub
- GitHub
- Discord
- Dropbox – API usage
