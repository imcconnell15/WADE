# Example Queries aligned to phases

## Phase 1

### DNS

```spl title="What are the DNS servers on the network?"
Index=zeek_dns id.resp_h=10.0.0.0/8 id.resp_h=172.16.0.0/12 id.resp_h=192.168.0.0/16
| stats count by id.resp_h
```

???note "AD Integrated DNS"
 In an active directory domain the main DNS servers should be the domain controllers if DNS is active directory integrated.
 Use a sub search to find the top sources of Kerberos traffic and then query zeek dns to see if the top Kerberos servers provide DNS to hosts

```spl title="Identify Active Directory servers providing DNS"
Index=zeek_dns
[  search index=zeek_kerberos
| stats count by id.resp_h
| head limit=10
| fields – count ]
```

```spl title="External DNS server that are in use by clients."
Index=zeek_dns id.resp_h!=10.0.0.0/8 id.resp_h!=172.16.0.0/12 id.resp_h!=192.168.0.0/16
| stats count by id.resp_h
```

```spl title="Additionally with encrypted DNS the zeek conn log should be used"
Index=zeek_conn proto=tcp id.resp_h!=10.0.0.0/8 id.resp_h!=172.16.0.0/12 id.resp_h!=192.168.0.0/16 id.resp_p IN (53, 853)
| stats count by id.resp_h
```

```spl title="DNS over HTTPS the traffic will go to known DNS servers over port 443 (change destination IPs to other external DNS servers)."
Index=zeek_conn id.resp_p=443 id.resp_h IN (8.8.8.8, 8.8.4.4, 1.1.1.1, 9.9.9.9)
| stats count by id.resp_h
```

### Kerberos

```spl title="Identify Active Directory controllers on the network"
index=zeek_kerberos request_type=*
| stats count by id.resp_h
```
