
# Hunt Methodology

Focus on **lead generation**. The purpose is not to find 100% evil 100% of the time. Its to identify a sufficient number of anomalies that you can track down in a sufficient amount of time, which may lead to evil.

## Overview

The general network hunt should proceed in phases first orientation with the network and determination of the services running.  Next proceed examining hosts and trying to create a picture of hosts conducting administrative actions or remote connections.  Phase 2 also start examining in depth the external traffic coming into the network.  Phase 3 should really focus on intelligence such as open source intelligence for known indicators.  Each phase provide additional information for further enhance the other phases.  For example hosts characterization can add additional information for network orientation and focusing on IOCs can be refined to prioritize the services discovered in phase 1.
The three phase approach is meant to give a framework to a network hunt that is not an incident response or intelligence driven.  If the engagement is based on an incident response or intelligence driven this should be prioritized over general network hunting.  The general network hunting should proceed when there is time in-between incident response and intelligence driven hunts.

![Phases Interrelation](../../assets/images/phases.JPG)

### Conventions

Each phase is described briefly. The objectives section outlines broad objective/goals per phase with a few question that may assist meeting the objectives.  Examples contain rudimentary searches which may meet some of the objectives.

## Phase 1

The hunt should begin by orientation within the network.  This includes confirming or discovering the IP ranges used in the network, identifying key network services and choke points.  The network orientation should also highlight the services being used on the network and the major servers hosting these services.
Cyber Key Terrain:
What has the customer outlined as critical infrastructure?  Focus the network orientation starting from the given key terrain.  Does the key terrain provide include all the service necessary for the key terrain to function?
RITA:
If RITA is being used during phase 1 RITA should be tuned to whitelist items that are known good, for example Microsoft or Chrome updates.  RITA can assist identifying services on the network since this activity is often picked up as beaconing like activity.  

## Phase 2

Network orientation and service discovery should be considered completed to a satisfactory degree when there is enough information to identify most known services and aggregation points for the network. Through continued network hunting, it is possible to identify new services and none of the phases are ever truly complete, but phase 2 can begin when there is enough information to deconflict known service from good networking hunt leads.  In phase 2 the focus can start to shift to examining hosts, such HTTP User agents, host software, and any other network examination outside of the central services.

## Phase 3

A hard examination of advanced indicators cannot truly begin until sufficient information about the network is known.  Once more information about the network has been determine it is then easier to start sorting indicators with a lower false positive rate.
