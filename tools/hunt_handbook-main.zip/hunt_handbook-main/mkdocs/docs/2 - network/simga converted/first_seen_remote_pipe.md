# First Time Seen Remote Named Pipe - Zeek

This detection excludes known namped pipes accessible remotely and notify on newly observed ones, may help to detect lateral movement and remote exec using named pipes

```spl
index=zeek_dce_rpc OR index=zeek_kerberos path="\\\\\*\\IPC$" NOT ("samr" OR "lsarpc" OR "winreg" OR "netlogon" OR "srvsvc" OR "protected_storage" OR "wkssvc" OR "browser" OR "netdfs" OR "svcctl" OR "spoolss" OR "ntsvcs" OR "LSM_API_service" OR "HydraLsPipe" OR "TermSrv_API_service" OR "MsFteWds")
```
