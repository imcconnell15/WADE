# Remote Task Creation via ATSVC Named Pipe - Zeek

Detects remote task creation via at.exe or API interacting with ATSVC namedpipe

```spl
index=zeek_dce_rpc OR index-zeek_kerberos path="\\\*\\IPC$" name="atsvc"
```
