# Suspicious Access to Sensitive File Extensions - Zeek

Detects known sensitive file extensions via Zeek

```spl
name IN ("*.pst", "*.ost", "*.msg", "*.nst", "*.oab", "*.edb", "*.nsf", "*.bak", "*.dmp", "*.kirbi", "*\\groups.xml", "*.rdp") | table ComputerName,SubjectDomainName,SubjectUserName,RelativeTargetName
```
