# Transferring Files with Credential Data via Network Shares - Zeek

Transferring files with well-known filenames (sensitive files with credential data) using network shares.

```spl
index=zeek_files name IN ("\\mimidrv", "\\lsass", "\\windows\\minidump\\", "\\hiberfil", "\\sqldmpr", "\\sam", "\\ntds.dit", "\\security")
```
