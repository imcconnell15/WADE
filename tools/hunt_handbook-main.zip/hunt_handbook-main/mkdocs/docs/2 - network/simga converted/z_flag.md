# Suspicious DNS Z Flag Bit Set

The DNS Z flag is bit within the DNS protocol header that is, per the IETF design, meant to be used reserved (unused). Although recently it has been used in DNSSec, the value being set to anything other than 0 should be rare. Otherwise if it is set to non 0 and DNSSec is being used, then excluding the legitimate domains is low effort and high reward. Determine if multiple of these files were accessed in a short period of time to further enhance the possibility of seeing if this was a one off or the possibility of larger sensitive file gathering. This Sigma query is designed to accompany the Corelight Threat Hunting Guide, which can be found here: [Corelight refrence](https://www3.corelight.com/corelights-introductory-guide-to-threat-hunting-with-zeek-bro-logs)

```spl
index=zeek_dns NOT Z=0 query="*.*" NOT (query IN ("*.arpa", "*.local", "*.ultradns.net", "*.twtrdns.net", "*.azuredns-prd.info", "*.azure-dns.com", "*.azuredns-ff.info", "*.azuredns-ff.org", "*.azuregov-dns.org") OR qtype_name IN ("ns", "mx") OR answers="*\\x00" OR id.resp_p IN (137, 138, 139)) | table ts,id.orig_h,id.orig_p,id.resp_h,id.resp_p,proto,qtype_name,qtype,query,answers,rcode,rcode_name,trans_id,qtype,ttl,AA,uid
```
