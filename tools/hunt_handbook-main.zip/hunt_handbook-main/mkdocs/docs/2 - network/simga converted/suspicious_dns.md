# Suspicious DNS Related

## DNS Query Tor Onion Address

Detects DNS queries to an ".onion" address related to Tor routing networks. [References]("https://www.logpoint.com/en/blog/detecting-tor-use-with-logpoint/")

```spl
index=zeek_dns query="*.onion*"
```

## DNS Query for Anonfiles.com Domain

Detects DNS queries for "anonfiles.com", which is an anonymous file upload platform often used for malicious purposes. [References]("https://www.trendmicro.com/vinfo/us/security/news/ransomware-spotlight/ransomware-spotlight-blackbyte")

```spl
index=zeek_dns query="*.anonfiles.com*"
```

## Suspicious TeamViewer Domain Access

Detects DNS queries to a TeamViewer domain only resolved by a TeamViewer client by an image that isn't named TeamViewer (sometimes used by threat actors for obfuscation) [References]("https://www.teamviewer.com/en-us/")

```spl
index=zeek_dns query IN ("taf.teamviewer.com", "udp.ping.teamviewer.com") NOT Image="*TeamViewer*"
```

## DNS Events Related To Mining Pools

Identifies clients that may be performing DNS lookups associated with common currency mining pools. [References]("https://github.com/Azure/Azure-Sentinel/blob/fa0411f9424b6c47b4d5a20165e4f1b168c1f103/Detections/ASimDNS/imDNS_Miners.yaml")

```spl
index=zeek_dns query IN ("*monerohash.com", "*do-dear.com", "*xmrminerpro.com", "*secumine.net", "*xmrpool.com", "*minexmr.org", "*hashanywhere.com", "*xmrget.com", "*mininglottery.eu", "*minergate.com", "*moriaxmr.com", "*multipooler.com", "*moneropools.com", "*xmrpool.eu", "*coolmining.club", "*supportxmr.com", "*minexmr.com", "*hashvault.pro", "*xmrpool.net", "*crypto-pool.fr", "*xmr.pt", "*miner.rocks", "*walpool.com", "*herominers.com", "*gntl.co.uk", "*semipool.com", "*coinfoundry.org", "*cryptoknight.cc", "*fairhash.org", "*baikalmine.com", "*tubepool.xyz", "*fairpool.xyz", "*asiapool.io", "*coinpoolit.webhop.me", "*nanopool.org", "*moneropool.com", "*miner.center", "*prohash.net", "*poolto.be", "*cryptoescrow.eu", "*monerominers.net", "*cryptonotepool.org", "*extrmepool.org", "*webcoin.me", "*kippo.eu", "*hashinvest.ws", "*monero.farm", "*linux-repository-updates.com", "*1gh.com", "*dwarfpool.com", "*hash-to-coins.com", "*pool-proxy.com", "*hashfor.cash", "*fairpool.cloud", "*litecoinpool.org", "*mineshaft.ml", "*abcxyz.stream", "*moneropool.ru", "*cryptonotepool.org.uk", "*extremepool.org", "*extremehash.com", "*hashinvest.net", "*unipool.pro", "*crypto-pools.org", "*monero.net", "*backup-pool.com", "*mooo.com", "*freeyy.me", "*cryptonight.net", "*shscrypto.net") NOT (answers IN ("127.0.0.1", "0.0.0.0") OR rejected="true") | table id.orig_h,id.resp_h,query,answers,qtype_name,rcode_name
```

## Monero Crypto Coin Mining Pool Lookup

Detects suspicious DNS queries to Monero mining pools. [Reference]("https://www.nextron-systems.com/2021/10/24/monero-mining-pool-fqdns/")

```spl
query IN ("*pool.minexmr.com*", "*fr.minexmr.com*", "*de.minexmr.com*", "*sg.minexmr.com*", "*ca.minexmr.com*", "*us-west.minexmr.com*", "*pool.supportxmr.com*", "*mine.c3pool.com*", "*xmr-eu1.nanopool.org*", "*xmr-eu2.nanopool.org*", "*xmr-us-east1.nanopool.org*", "*xmr-us-west1.nanopool.org*", "*xmr-asia1.nanopool.org*", "*xmr-jp1.nanopool.org*", "*xmr-au1.nanopool.org*", "*xmr.2miners.com*", "*xmr.hashcity.org*", "*xmr.f2pool.com*", "*xmrpool.eu*", "*pool.hashvault.pro*")
```

## DNS Query for Ufile.io Upload Domain

Detects DNS queries to "ufile.io". Which is often abused by malware for upload and exfiltration. [References]("https://thedfirreport.com/2021/12/13/diavol-ransomware/")

```spl
index=zeek_dns query="*ufile.io*"
```

## DNS Query for MEGA.io Upload Domain

Detects DNS queries for subdomains used for upload to MEGA.io. [References]("https://research.nccgroup.com/2021/05/27/detecting-rclone-an-effective-tool-for-exfiltration/")

```spl
index=zeek_dns query="*userstorage.mega.co.nz*"
```

## DNS Query To Remote Access Software Domain

An adversary may use legitimate desktop support and remote access software, such as Team Viewer, Go2Assist, LogMein, AmmyyAdmin, etc, to establish an interactive command and control channel to target systems within networks. These services are commonly used as legitimate technical support software, and may be allowed by application control within a target environment. Remote access tools like VNC, Ammyy, and Teamviewer are used frequently when compared with other legitimate software commonly used by adversaries. (Citation: Symantec Living off the Land)

**References:**

- [RedCanary1]("https://github.com/redcanaryco/atomic-red-team/blob/f339e7da7d05f6057fdfcdd3742bfcf365fee2a9/atomics/T1219/T1219.md#atomic-test-4---gotoassist-files-detected-test-on-windows")
- [RedCanary2]("https://github.com/redcanaryco/atomic-red-team/blob/f339e7da7d05f6057fdfcdd3742bfcf365fee2a9/atomics/T1219/T1219.md#atomic-test-3---logmein-files-detected-test-on-windows")
- [RedCanary3]("https://github.com/redcanaryco/atomic-red-team/blob/f339e7da7d05f6057fdfcdd3742bfcf365fee2a9/atomics/T1219/T1219.md#atomic-test-6---ammyy-admin-software-execution")
- [RedCanary4]("https://redcanary.com/blog/misbehaving-rats/")

```spl
index=zeek_dns query IN ("*.getgo.com", "*.logmein.com", "*.ammyy.com", "*.netsupportsoftware.com", "*remoteutilities.com", "*.net.anydesk.com", "*api.playanext.com", "*.relay.splashtop.com", "*.api.splashtop.com", "*app.atera.com", "*.agentreporting.atera.com", "*.pubsub.atera.com", "*logmeincdn.http.internapcdn.net", "*logmein-gateway.com", "*client.teamviewer.com", "*integratedchat.teamviewer.com", "*static.remotepc.com", "*.n-able.com", "*comserver.corporate.beanywhere.com", "*.swi-rc.com", "*.swi-tc.com", "*telemetry.servers.qetqo.com", "*relay.screenconnect.com", "*control.connectwise.com", "*express.gotoassist.com", "*authentication.logmeininc.com", "*.services.vnc.com", "*.tmate.io", "*api.parsec.app", "*parsecusercontent.com", "*remotedesktop-pa.googleapis.com", "*.logmein-gateway.com", "*secure.logmeinrescue.com", "*join.zoho.com", "*assist.zoho.com", "*.zohoassist.com", "*downloads.zohocdn.com", "*agent.jumpcloud.com", "*kickstart.jumpcloud.com", "*cdn.kaseya.net", "*relay.kaseya.net", "*license.bomgar.com", "*.beyondtrustcloud.com") NOT (Image IN ("*\\Google\\Chrome\\Application\\chrome.exe", "*\\brave.exe", "*\\chromium.exe", "*\\firefox.exe", "*\\msedge.exe", "*\\opera.exe", "*\\microsoftedge.exe", "*\\iexplorer.exe", "*\\vivaldi.exe", "*\\CCleaner Browser\\Application\\CCleanerBrowser.exe"))
```

## Suspicious Cobalt Strike DNS Beaconing - Sysmon

Detects a program that invoked suspicious DNS queries known from Cobalt Strike beacons.  First query is sysmon related data with the associated commands.  Second query is for `zeek_dns` to detect network events.

**References:**

- [Icebrg]("https://www.icebrg.io/blog/footprints-of-fin7-tracking-actor-patterns")
- [Sekoia]("https://www.sekoia.io/en/hunting-and-detecting-cobalt-strike/")

```spl
QueryName IN ("aaa.stage.*", "post.1*") OR QueryName="*.stage.123456.*" | table Image,CommandLine
```

```spl
index=zeek_dns query IN ("aaa.stage.*", "post.1*") OR query="*.stage.123456.*"
```

## Suspicious DNS Query for IP Lookup Service APIs

Detects DNS queries for ip lookup services such as api.ipify.org not originating from a non browser process.  First query is based on Sysmon information.  Second query is looking for the network queries to help narrow down the hosts.

**References:**

- [BinaryDefense]("https://www.binarydefense.com/analysis-of-hancitor-when-boring-begets-beacon")
- [Twitter]("https://twitter.com/neonprimetime/status/1436376497980428318")

```spl
QueryName IN ("canireachthe.net", "ipv4.icanhazip.com", "ip.anysrc.net", "edns.ip-api.com", "wtfismyip.com", "checkip.dyndns.org", "api.2ip.ua", "icanhazip.com", "api.ipify.org", "ip-api.com", "checkip.amazonaws.com", "ipecho.net", "ipinfo.io", "ipv4bot.whatismyipaddress.com", "freegeoip.app", "ifconfig.me", "ipwho.is") NOT (Image IN ("*\\Google\\Chrome\\Application\\chrome.exe", "*\\iexplore.exe", "*\\firefox.exe", "*\\brave.exe", "*\\opera.exe", "*\\msedge.exe", "*\\vivaldi.exe", "*\\chromium.exe", "*\\microsoftedge.exe", "*\\iexplorer.exe", "*\\CCleaner Browser\\Application\\CCleanerBrowser.exe"))
```

```spl
index=zeek_dns query IN ("canireachthe.net", "ipv4.icanhazip.com", "ip.anysrc.net", "edns.ip-api.com", "wtfismyip.com", "checkip.dyndns.org", "api.2ip.ua", "icanhazip.com", "api.ipify.org", "ip-api.com", "checkip.amazonaws.com", "ipecho.net", "ipinfo.io", "ipv4bot.whatismyipaddress.com", "freegeoip.app", "ifconfig.me", "ipwho.is")
```

## Suspicious DNS Query with B64 Encoded String

Detects suspicious DNS queries using base64 encoding. [References]("https://github.com/krmaxwell/dns-exfiltration")

```spl
query="*==.*"
```
