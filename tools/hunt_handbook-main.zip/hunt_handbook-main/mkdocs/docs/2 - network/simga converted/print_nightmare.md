# Possible PrintNightmare Print Driver Install

Detects the remote installation of a print driver which is possible indication of the exploitation of PrintNightmare (CVE-2021-1675). The occurrence of print drivers being installed remotely via RPC functions should be rare, as print drivers are normally installed locally and or through group policy.

```spl
operation IN ("RpcAsyncInstallPrinterDriverFromPackage", "RpcAsyncAddPrintProcessor", "RpcAddPrintProcessor", "RpcAddPrinterDriverEx", "RpcAddPrinterDriver", "RpcAsyncAddPrinterDriver") | table id.orig_h,id.resp_h,id.resp_p,operation,endpoint,named_pipe,uid
```
