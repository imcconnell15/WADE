# Suspicious PsExec Execution - Zeek

Detects execution of psexec or paexec with renamed service name, this rule helps to filter out the noise if psexec is used for legit purposes or if attacker uses a different psexec client other than sysinternal one

```spl
path="*\\*" path="*\\IPC$*" name IN ("*-stdin", "*-stdout", "*-stderr") NOT name="PSEXESVC*"
```
