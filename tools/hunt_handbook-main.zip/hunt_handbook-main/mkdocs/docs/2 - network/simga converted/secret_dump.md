# Possible Impacket SecretDump Remote Activity - Zeek

Detect AD credential dumping using impacket secretdump HKTL. Based on the SIGMA rules/windows/builtin/win_impacket_secretdump.yml

```spl
path="*\\*" path="*ADMIN$*" name="*SYSTEM32\\*" name="*.tmp"
```
