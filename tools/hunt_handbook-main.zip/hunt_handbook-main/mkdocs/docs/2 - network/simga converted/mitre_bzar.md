# MITRE BZAR

## MITRE BZAR Indicators for Persistence

Windows DCE-RPC functions which indicate a persistence techniques on the remote system. All credit for the Zeek mapping of the suspicious endpoint/operation field goes to MITRE.

```spl
index=zeek_dce_rpc (endpoint="spoolss" operation="RpcAddMonitor") OR (endpoint="spoolss" operation="RpcAddPrintProcessor") OR (endpoint="IRemoteWinspool" operation="RpcAsyncAddMonitor") OR (endpoint="IRemoteWinspool" operation="RpcAsyncAddPrintProcessor") OR (endpoint="ISecLogon" operation="SeclCreateProcessWithLogonW") OR (endpoint="ISecLogon" operation="SeclCreateProcessWithLogonExW")
```

## MITRE BZAR Indicators for Execution

Windows DCE-RPC functions which indicate an execution techniques on the remote system. All credit for the Zeek mapping of the suspicious endpoint/operation field goes to MITRE

```spl
index=zeek_dce_rpc (endpoint="JobAdd" operation="atsvc") OR (endpoint="ITaskSchedulerService" operation="SchRpcEnableTask") OR (endpoint="ITaskSchedulerService" operation="SchRpcRegisterTask") OR (endpoint="ITaskSchedulerService" operation="SchRpcRun") OR (endpoint="IWbemServices" operation="ExecMethod") OR (endpoint="IWbemServices" operation="ExecMethodAsync") OR (endpoint="svcctl" operation="CreateServiceA") OR (endpoint="svcctl" operation="CreateServiceW") OR (endpoint="svcctl" operation="StartServiceA") OR (endpoint="svcctl" operation="StartServiceW")
```
