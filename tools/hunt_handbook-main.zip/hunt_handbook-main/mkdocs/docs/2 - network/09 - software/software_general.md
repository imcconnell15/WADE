# Software General

Zeek collects information from the sensored network about software.  It does its best to parse software name and version from unencrypted traffic.  The software log is not an exhaustive, but helps to provide and understanding of some software present on the network.  The analyst should examine the zeek software logs for a number of items.

- Extremely old software versions.
- Insecure (and old) software such as openSSH versions.
- Software that is not authorized.

If the customer's network doesn't have an approved software list inquiring about all software information can be overwhelming.  The focus should be on examining the software log for a few interesting objectives such as P2P software, cloud based file sharing software, ect.

- Specifically denied software by the customer
- Very rare software - compared week to week
- Known malicious software (ie used in a known compromise at the location previously)

Example query:

```spl
index="zeek_software"| stats count by name |sort count
```

!!! note "Filtering"
    The above query will potentially result in a large number of results. Reducing the search time frame can help reduce the number of results. If the customer has provided a list of authorized software you can further redue the number of results by filtering them out of your spl query (i.e. **NOT name IN (Chrome, Microsoft Office, ... )**).
    Sorting by count allows you to perform some long-tail analysis and view the least observed software on the network.

## Hive Case

### Main page -

**Title:** Software Observed  
**Severity:** Low  
**TLP:**  
**PAP:**  
**Assignee:**  
**Tags:** network  
**Description:** Catalog of software observed over network traffic.  
