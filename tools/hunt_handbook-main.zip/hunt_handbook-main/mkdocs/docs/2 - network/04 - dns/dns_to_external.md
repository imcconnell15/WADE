# DNS to External

## Background

Finding DNS queries going to external sources requires a mix of queries utilizing Zeek DNS and Zeek Conn.  Modern browsers will send DNS query to the default configured DNS server over HTTPS (DOH), if the server is not configured to answer the queries they may than query an external DNS server over HTTPS.  This queries won’t show in Zeek DNS since zeek cannot parse the encrypted data.  Zeek conn log will show HTTPS Traffic going to known open internet DNS servers (TCP or 443).  In addition to DNS over UDP port 53 encrypted DNS can be over TCP 53 or TCP 853 (DNS over TLS (DoT)).

### Active Directory and DNS

In an Active Directory domain the Windows clients *should* have their DNS servers set to the Active Directory Domain Controllers.  This is called Active Directory integrated DNS.  It allows the clients to find domain resources by name from the AD Domain Controllers and keep DNS queries centralized (for logging and caching) for external services.  If the customer's network is AD DNS Integrated zone, a standard external DNS query should go to the Domain Controllers and from there either to another customer owned DNS or to an external service.  Cross-reference internal host as a DNS query destination with kerberos traffic to determine if the DNS service is a Domain Controller or not.

### Possible ports for DNS traffic

- 53
- 80
- 443
- 853
- 5353

Sometimes malicious programs will have their DNS hard coded and examining DNS traffic going to external sources *MAY* help to highlight this.

[Firefox DNS-over-HTTPS](https://support.mozilla.org/en-US/kb/firefox-dns-over-https)

!!!note "Security DNS services"
    Some security appliances and software will direct DNS queries to their hosted DNS services to block known threats via DNS blackholing, consider the owner of external DNS servers to discover this type of behavior.

!!!note "DNS answers with 0.0.0.0"
    Normal DNS should provide an answer for all queries.  If the DNS answer is 0.0.0.0 this is effectively send the traffic for the query no where.  Sometimes service such as Google may send answers with 0.0.0.0 but this traffic is usually very high in occurrence.  If there are only a few queries (and to odd domains) sporadically with the answer being 0.0.0.0 this could be a beacon and when it becomes active the DNS answer will change.

Example queries:

DNS traffic to external IP Addresses

```spl
Index=zeek_dns NOT id.resp_h IN (10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16)
| stats count by id.resp_h
```

Utilizing zeek conn to show traffic on known DNS ports.

```spl
Index=zeek_conn NOT id.resp_h IN (10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16) id.resp_p IN (53, 853)
| stats count by id.resp_h
```

Utilizing zeek conn to find 443 (HTTPS) traffic going to known open internet DNS servers

```spl
Index=zeek_conn id.resp_p=443 id.resp_h IN (8.8.8.8, 8.8.4.4, 1.1.1.1, 9.9.9.9)
| stats count by id.resp_h
```

---

## DNS-over-HTTPS

DNS over HTTPS queries are often times base64 and be decoded to determine the query.  For example the following are different DOH formats:

```yaml
GET /?dns=DUIBAAABAAAAAAAABWJhaWR1A2NvbQAAAQAB HTTP/1.1
GET /dns-query?dns=DUIBAAABAAAAAAAABWJhaWR1A2NvbQAAAQAB HTTP/1.1
GET /doh?dns=DUIBAAABAAAAAAAABWJhaWR1A2NvbQAAAQAB HTTP/1.1
GET /doh/family-filter?dns=DUIBAAABAAAAAAAABWJhaWR1A2NvbQAAAQAB HTTP/1.1
GET /doh/secure-filter?dns=DUIBAAABAAAAAAAABWJhaWR1A2NvbQAAAQAB HTTP/1.1
GET /query?dns=DUIBAAABAAAAAAAABWJhaWR1A2NvbQAAAQAB HTTP/1.1
GET /resolve?dns=DUIBAAABAAAAAAAABWJhaWR1A2NvbQAAAQAB HTTP/1.1
```

Example:
`DUIBAAABAAAAAAAABWJhaWR1A2NvbQAAAQAB` base64 decodes to `B...........baidu.com.....`

## Hive Case

### Main page -

**Title:** DNS to External servers  
**Severity:** Low  
**TLP:**  
**PAP:**  
**Asignee:**  
**Tags:** network  
**Description:** Overview of external DNS servers that are accessible and in use by hosts.  

### Expected outcomes

Catalog the externally accessible DNS servers, vocalization the information with the team so that all members are aware of this behavior.  Compare the externally utilized DNS servers and compare different time periods (ie week over week) and investigate if new external DNS are suddenly utilized.
