# Top Level Domains

## Background -

Find top level domains and do a count to isolate uncommon TLDs.  This should extend to the 2nd level domain of the top level domain.  The customer or hunt may provide a list of TLDs that should be disallowed, it should be verified that traffic to the disallowed TLDs is denied.

---

## Example queries

```spl
index="zeek_dns" NOT record_type="PTR" query=!*.arpa
| rex field=query "(?<TLD>\.\w+?)(?:$|\/)"
| stats count by TLD
| sort count
```

## Hive Case

### Main page -

**Title:** High port to high port communication  
**Severity:** Low  
**TLP:**  
**PAP:**  
**Assignee:**  
**Tags:** network  
**Description:** Catalog hosts that have unusual high port to high port activity.

### Case tasks -
