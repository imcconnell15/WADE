# High Entropy Domains

## Background -

Weird Domains shouldn't be a thing people go to
Cloudflare makes a ton - whats that look like.. exclude those
---

## Hive Case

### Main page -

**Title: High port to high port communication**
**Severity**: Low
**TLP:**
**PAP:**
**Assignee:**
**Tags:** network
**Description:** Catalog hosts that have unusual high port to high port activity.

### Case tasks -
