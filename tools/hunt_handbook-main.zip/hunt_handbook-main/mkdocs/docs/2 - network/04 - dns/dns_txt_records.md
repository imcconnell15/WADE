# DNS Text Records

## What is a DNS TXT record?

The DNS ‘text’ (TXT) record lets a domain administrator enter text into the Domain Name System (DNS). The TXT record was originally intended as a place for human-readable notes. However, now it is also possible to put some machine-readable data into TXT records. One domain can have many TXT records. TXT query requests/responses can be used by botnets and MCAs for C2, and data exfitrartion.  Traffic should be inspected for large TXT records.

[Cloudflare Explanation](https://www.cloudflare.com/learning/dns/dns-records/dns-spf-record/)

## Background

DNS Text records (**TXT**) are used to store text information that generally have no effect on DNS queries.  The TXT records recently have become a useful location to store security associated information, such as SPF records and [domain ownership information](https://support.google.com/a/answer/183895?hl=en).

!!!note "Sender Policy Framework (SPF) Records"
    An SPF record is a TXT record that is part of a domain's DNS (Domain Name Service). An SPF record lists all authorized hostnames / IP addresses that are permitted to send email on behalf of your domain.

Despite this benefical security information being located in DNS TXT records, there is no control over the infromation that can be present in a TXT records.  The lack of control allows actors with malicious intent to also utilize these records.  DNS TXT have been used to exfil data from a network or to pass [malicious commands](https://cybersecuritynews.com/dns-txt-records-to-execute-malware/).

## Hive Case

### Main page -

**Title:** DNS Text Records  
**Severity:** Low  
**TLP:**  
**PAP:**  
**Asignee:**  
**Tags:** network  
**Description:** Overview of DNS text records.  

### Expected outcomes

DNS TXT records are frequently used for security purposes on the internet.  The number or frequency of DNS text records can vary depending on the domains visited and with email server communications.  Items that warrant additional investigation would be DNS TXT records other than SPF and domain ownership verification.  The information in DNS TXT records should be checked versus SPF and domain ownership record formats.  Any record that doesn't match these frameworks should be investigated to determine what information is in the TXT records.
