# High port to High port

## Background

High port to high port communication can indicate an abnormal communication channel.  Typically communication is pinned to known services which are at standards ports below 1024.  However some known services can run on high ports by default - for example elastic at port 9200.  

If there are many hosts talking to one host on the same high port on one side of the conversation this is probably a service and allowed behavior.  Research the port that is being used to determine if it is a default port for a software, ie Elastic.  Note that this service probably runs on the host always using the same high port.  The customer can be asked to verify this information, but if there are a high number of hosts connecting to one host chances are this is a known service to the customer.

Also be aware that some protocols will connect and than negotiate to high-port to high-port.  For example FTP connects on port 21 and negotiates the file transfer over high-port to high-port.  Ensure that the interesting traffic is not a known protocol that negotiated to the high ports.  This can be determined by looking at the communication between the hosts shortly before high-port to high-port traffic begins.

The connection state should have the SYN and FIN (conn_state=SF) flags for the communication to be initiated and terminated properly.  Mid-stream data does not guarantee that a complete transmission occurred between the hosts.

!!!note "Not usually bad"
    High port to high port communication is most likely a configured service.  It should not be immediately assumed that this traffic indicates malicious behavior until it has been investigated in-depth.

Example Splunk query:

```spl
index=zeek_conn id.resp_p>1024 id.orig_p>1024 conn_state=SF
| fillnull value="null" service
| table _time id.orig_h id.orig_p orig_bytes id.resp_h id.resp_p resp_bytes proto service
| rename id.orig_h as "Source Host" id.orig_p as "Source Port" orig_bytes as "Source Bytes" id.resp_h as "Destination Host" id.resp_p as "Destination Port" resp_bytes as "Responder Bytes"
```

---

## Hive Case  

### Main page -  

**Title:** High port to high port communication  
**Severity:** Low  
**TLP:**  
**PAP:**  
**Assignee:**  
**Tags:** network  
**Description:** Catalog hosts that have unusual high port to high port activity.  

### Expected outcomes

All high port to high port activity should not be opened as a case if it is a known service.  Of particular interest is sporadic/intermittent activity and a case for each instance of interesting traffic should be opened.  The case should include the hosts involved, the high port to high port activity, a time frame (a timechart is especially useful in this instance), and any other information (user agent, etc.). That is associated with the activity.
