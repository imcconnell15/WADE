# After Working Hours

## Background

Examining traffic (from any of the log sourcetypes) and comparing normal working hour communication to traffic outside working hours, can help highlight abnormal traffic patterns.  Examining the entire network traffic maybe difficult to highlight abnormal traffic patterns concerning one host, and this should be considered when comparing behavior.  Protocols with fewer occurrences (ie FTP) are easier to spot communications outside of expected hours.

!!!warning "Working with Time Zones"
    Zeek will record the events based on the time settings of the host (sensor).  The Zeek sensors should be set to UTC timezone and the UTC time is stored with the events.  When searching the data the date_hour for non-working hours should be UTC +/- the local time zone.  Example the date_hour offset for EST (also remember daylight savings) to UTC working hours is equal to `date_hour>=21 OR date_hour<13`.  This is equivalent to 0800 to 1800 EST.

### Examine after hour traffic by host (equivalent to sensor)  

```spl
index=zeek_conn date_hour>=21 OR date_hour<13
| timechart span=1h count by host
```

???+ tip "Alternative methods for time"
    More specific time declaration with `earliest=07/04/1979:18:00:00 latest=07/05/1979:08:00:00` or a case search will work with date_hour `date_hour IN(21, 22, 23, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12)`

### Refine to one sensor and find the top source IP

```spl
index=zeek_conn date_hour>=21 OR date_hour<=13
| timechart span=1h count by id.orig_h
```

!!! note "Splunk Displayed time"
    The events should be recorded in UTC time but the Splunk Preferences should should be set to local timezone.  The events must be queried respective to UTC (how they are recorded), but the local time preference will convert the displayed time to the local timezone.

!!! note "Holidays"
    It is expected that during holidays the traffic pattern will be considerably less.  Examining traffic on holidays can highlight abnormal traffic, but also help identify services that run continually without users being present.

## Expected outcomes

After examining traffic outside of expected working hours, catalog network services that run continually.  Knowing the network services that run continuously assists in the network orientation phase.  If user workstations (ie Windows 10/11) are communicating large amounts of data outside of working hours this is a concerning pattern and should be investigated further.
