# Internet Scanners

## Background

Even though the IP addresses are known to be internet scanners this helps to highlight the local hosts that are accessible to the internet.  This could indicate that a firewall is incorrectly configured and allowing scanners to reach local host that possibly shouldn’t be accessible on the internet to scanner.  If the hosts are verified to have ports forwarded and accessible to the internet, then internet scanners are going to continually reach the host on the forwarded ports. The traffic on the forwarded ports should be considered normal activity and only further investigated if there are additional information other than just the scanning activity.

The internet scanners should be the source IP address, indicating that the scanner is going to internal IP addresses.  If the internal hosts are going to an IP address on the known internet scanner list this **COULD** indicate compromise but also more likely the internal host is sending information to the scanner, such as “Page Not Found.”  

A Splunk query that compares both the source and destination IPs to a lookup list which contains a known list of internet scanners.  Splunk query for example:

Get ciarmy list from: [https://cinsscore.com/list/ci-badguys.txt](https://cinsscore.com/list/ci-badguys.txt)

### Example search

```spl
index=zeek_conn 
| lookup ciarmy.csv Indicator as id.orig_h OUTPUT Indicator as match, Description as description
| lookup ciarmy.csv Indicator as id.resp_h OUTPUT Indicator as match, Description as description
| search description=*
| stats count by id.orig_h id.resp_h match description
| table id.orig_h id.resp_h match description count
| rename id.orig_h as "Source Host", id.resp_h as "Destination Host"
| sort - Count
```

---

## Hive Case

### Main page -

**Title:** Known Internet Scanners  
**Severity:** Low  
**TLP:**  
**PAP:**  
**Assignee:**  
**Tags:** network  
**Description:** Utilize a lookup file containing known internet scanners to determine the hosts that are accessible to the known internet scanners.

### Expected outcomes

The results should include the local hosts that the internet scanners are able to reach.  Take the list of local hosts and present to customer, verify that these hosts are supposed to be accessible on the internet.  Frequently some firewall rule get forgotten or are incorrect and hosts are on the internet that are not supposed to be.
