# Suspicious Certificates

## Background -

x509 Certificates are used to secure communications and identify or authenticate entities to each other.  The most common usage is found in Secure Sockets Layer (SSL) and its update Transport Layer Security (TLS) for HTTPS traffic, though the format can also be used for many other protocols and situations: POP, SMTP, IMAP, and LDAP on a standard network; EAP-TLS for wifi authentication; even on smartcards. Encryption is increasingly being used by malicious cyber actors for both C2 as well as lateral movement. Monitoring or hunting for x509 anomalies can identify the activity, as certificates are essentially unique.

### X509 vs SSL

>In the last section we looked at Zeek’s ssl.log, a source which offered details on TLS connections. In this section we will look an associated source, Zeek’s x509.log. The x509.log captures details on certificates exchanged during **certain** TLS negotiations. 
--<cite> https://docs.zeek.org/en/master/logs/x509.html</cite>

### Expired Certificates

Expired certificates are no longer valid and should be investigated. Using the "now()" function only works while actively hunting.  This function can also be replaced with a specific timestamp.

`index="zeek_x509" certificate.not_valid_after < now()`

When reviewing historical data, the zeek_ssl log might be more effective, as it records the status of the certificate when zeek parsed it:

`index="zeek_ssl" validation_status="certificate has expired"`

### Self-Signed Certificates

Self-signed certificates are found when a system signs its own certificate with no CA signing. If no trusted authority has signed the certificate, it should be immediately suspect.  Occasionally a self-signed cert may be used for internal services, but the organization should instead implement its own trusted root certificate for internal use.  The query below will produce results for both "self signed certificate" as well as "self signed certificate in chain".

`index=zeek_ssl validation_status="self signed certificate*"`

### Invalid Certificate Chain

x509 certificates rely on a trust system to a Certificate Authority. Usually a Certificate Authority is trusted by the end user, and a server gets a signed certificate from an intermediate authority or issuer - the whole chain must be trusted.  Some CAs or IAs have become compromised, or revoked certain certificates.  These authorities and certificates should be identified by validation with revocation lists.

This query lists each certificate and its validation status.  Additional filtering is needed to narrow the search:

```
index=zeek_ssl validation_status="*" (id.resp_h=* OR id.orig_h=*) resumed=false
| fillnull value="unknown"
| stats count by id.resp_h server_name id.orig_h validation_status
| sort - count
```

In order to trim down the responses, another option is to use filters or exclusion filters:

`... validation_status="self signed certificate*"`

`... NOT(validation_status="ok" OR validation_status=unable to get local issuer certificate")`

### Protocol Mismatch

TLS is most commonly used for HTTPS, though many other protocols can implement it.  Anomalous protocols or a mismatch between the port/protocol and cert is worthy of investigation.  The following query will provide a counted list of the destination ports used.  This might expose some high-to-high port communications, or unusual ports (e.g. port 80) being used for encrypted communications.

```
index=zeek_ssl validation_status="*" (id.resp_h=* OR id.orig_h=*) NOT id.resp_p="443" resumed=false
| fillnull value="unknown"
| stats count by id.resp_p
```

### New Certificates

New certificates might be benign, such as when a major website renews its expiring certificate. The ability of a malicious actor to generate new certificates should be investigated. This query should search for new certificates, cross-reference against the Cisco top 1 million list, and return the outliers:

`index="zeek_x509" AND certificate.not_valid_before>2023-02-17T00:00:00.000000Z`

### Common Name Mismatch Error

A certificate will contain identifying information for the server it validates. If the hostname or domain name fail to match the name in the certificate, the analyst should investigate further. This is not possible from the network traffic.

* Kali Linux o-saft tool can identify common name mismatch errors, but not automatically. It works by selecting a target server, then analyzing the certificate presented by that server.  o-saft does not analyze the certificates.
* Browsers do this with the default security settings. These errors might be found in host-level browser logs, such as "%LOCALAPPDATA%\\Google\\Chrome\\User Data".  However, these log files (\*.store format) are not human-readable.

Browsing to chrome://net-internals is no longer supported.  The page chrome://net-export allows the user to start future logging.  The exported log files could be viewed on netlog-viewer.appspot.com/#import but that doesn't seem to work with the .store files.

<https://support.happyfox.com/kb/article/882-accessing-the-browser-console-and-network-logs/> has instructions for reviewing browser log file(s) via the developer tools windows.

### Reused Serial Numbers

Certificates should have individualized serial numbers. A single serial number seen multiple times but with different properties should be investigated.  In the example below, additional or different properties can be inserted in place of or in addition to the "certificate.subject".

`index="zeek_x509" | stats count by certificate.serial certificate.subject | stats count by certificate.serial | sort -count`

Malicious certificates can become IOCs to be referenced later in a lookup table, however this is not likely to produce useful results.  An attacker is more likely to produce a new valid certificate than continue using an old one, especially given the trend towards increasingly short certificate expiration periods.

---

## Hive Case

### Main page -

**Title: Anomalous x509 Certificate**
**Severity:** Low
**TLP:**
**PAP:**
**Assignee:**
**Tags:** network
**Description:** Catalog properties of unusual x509 certificates

### Case tasks -

Not all anomalous certificate activity should be opened as a case.  These known or valid use cases must be investigated through collecting additional evidence from the network or host, as well as conversations with the customer.  Some examples of known/valid/benign circumstances:

1. Self-signed certificates used in internal applications.
2. Expired certificates resulting from errors and not malicious activity (Hanlon's Razor).
3. Invalid certificate chain alerts from improperly configured root or intermediate CAs.

Once confirmed to be outside of normal use, a Hive case for each anomalous certificate should be opened.  The case should include the hosts involved, time frame, ports and protocols used, and any other information (user agent, etc.) that is associated with the activity.
