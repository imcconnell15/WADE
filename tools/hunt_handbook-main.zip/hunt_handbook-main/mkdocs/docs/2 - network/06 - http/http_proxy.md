# HTTP Proxy Identification

## Background -

HTTP Traffic can be used to proxy data in and out of the network. This allow ingress/egress of potentially sensitive or malicious data and may be used to circumvent established policies. A machine identified to be in use as a proxy, outside of the customer established baseline, could indicate a compromised system being used to maintain persistence.

### Example of Splunk Query -

```spl
index=zeek_http uri=*http:*
```

!!! note "Note"
    HTTP Proxies almost unilaterally include the end destination in the URI.

## Hive Case

### Main page -

**Title:** HTTP Proxy  
**Severity:** Low  
**TLP:**  
**PAP:**  
**Assignee:**  
**Tags:** network  
**Description:** Catalog instances of HTTP Proxies.

### Case tasks -

If an analyst encounters HTTP Proxies, a ticket should be generated and the local network owners should be consulted to ensure this proxy falls within their policies.
