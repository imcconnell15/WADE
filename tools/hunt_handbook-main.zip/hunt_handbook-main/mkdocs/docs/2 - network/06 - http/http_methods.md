# Profile HTTP traffic by method

## Background -

HTTP traffic possesses a method field describing the type of activity.  Profiling the HTTP traffic over time for a host or group of hosts can help to highlight anomalous traffic when the method type shows an abnormal spike.
User Agents often give away tool use on a network e.g. NMAP. NMAP can be used to identify services and potentially allow attackers to profile these same services to identify vulnerabilities.

### Example of Splunk Query -

```spl
index=zeek_http id.orig_h="10.10.10.10" OR id.resp_h="10.10.10.10"
| timechart span=1d count by method
```

!!! note "Note"
    The specific IP address or subnet you wish to investigate should be used in place of "10.10.10.10".

## Anamolous Traffic

A host client should typically conduct mostly `GET` methods.  If an increase in other http methods is discovered, the traffic should be investigated as possibly anomalous.  Additonally, a high number of `GET` request on one day compared to other days it could be considered anomolous traffic and should be invesitgated.

## Hive Case

### Main page -

**Title:** User Method Profiling  
**Severity:** Low  
**TLP:**  
**PAP:**  
**Assignee:**  
**Tags:** network  
**Description:** Categorize HTTP methods for a host or group or hosts.

### Case tasks -

If an analyst encounters anamolous spike in a method the traffic should be investigated to determine the cause.
