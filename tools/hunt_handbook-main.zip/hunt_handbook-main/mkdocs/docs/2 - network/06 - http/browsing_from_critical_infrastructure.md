# Web Browsing from Critical Infrastructure

## Background -

Critical infrastructure should not be utilized to browse the open internet. Access to the web should be restricted to only end users. Allowing end users to navigate the open internet from critical infrastructure opens up the possibility that the view, click or otherwise interact with malware. This creates an opportunity for malicious actors that would not otherwise be present.

### Example of Splunk Query -

```spl
index=zeek_http id.orig_h=$Critical_Infrastructure method=GET
| eval Time=strftime(_time, "%m/%d/%y %I:%M:%S:%p")
| table Time id.orig_h id.resp_h status_code
```

!!!note "Note"
    $Critical_Infrastructure should be replaced with whatever IP or IP range is identified to be critical infrastructure.

## Hive Case

### Main page -

**Title:** Critical Infrastructure Reaching the Web  
**Severity:** Low  
**TLP:**  
**PAP:**  
**Assignee:**  
**Tags:** network  
**Description:** Catalog instances of critical infrastructure actively browsing the internet.

### Case tasks -

If an analyst encounters critical infrastructure actively browsing the internet, a ticket should be generated and the local network owners should be consulted to ensure this browsing falls within their policies.
