# Passwords In The Clear

## Background -

Passwords in clear text represent a substantial security vulnerability. These passwords can be used by an attacker to login as an authorized user to gain unauthorized access to information, or potentially be used to gain a user shell on a system.

### Example Splunk Queries -

```spl
 index=zeek_http method=POST password 
 | table id.orig_h id.orig_p id.resp_h id.resp_p uri
```

```spl
index=zeek_http method=POST login 
| table id.orig_h id.orig_p id.resp_h id.resp_p uri
```

## Hive Case

### Main page -

**Title:** Cleartext Passwords in Use  
**Severity:** Low  
**TLP:**  
**PAP:**  
**Assignee:**  
**Tags:** network  
**Description:** Catalog instances of observed cleartext passwords.  

### Case tasks -

If an analyst encounters cleartext passwords, a ticket should be generated and the local network owners should be consulted to ensure use of this service falls within their policies.
