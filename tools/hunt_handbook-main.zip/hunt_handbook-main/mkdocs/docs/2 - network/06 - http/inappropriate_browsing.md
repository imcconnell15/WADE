# Inappropriate Browsing

## Background -

Network users navigating to inappropriate websites introduce the opportunity to view, click, or otherwise interact with malware. This may allow malicious actors to steal user tokens for the network, providing access to potentially sensitive information and the means to move laterally, escalate or establish persistence.

### Example of Splunk Query -

```spl
index=zeek_dns | chart count by query
```

!!! note "Erroneous entries"
    The addition of **query!="`SomeDomain`"** to your Splunk query can be used to filter out erroneous entries e.g. google.

!!! note "Going forward"
    When an inappropriate dns query is discovered an analyst may left click the entry  to view relevant events.

## Hive Case

### Main page -

**Title:** Inappropriate Browsing  
**Severity:** Low  
**TLP:**  
**PAP:**  
**Assignee:**  
**Tags:** network  
**Description:** Catalog instances of network users browsing inappropriate websites.

### Case tasks -

If an analyst encounters users browsing questionable websites, a ticket should be generated and the local network owners should be consulted to ensure this browsing falls within their policies.
