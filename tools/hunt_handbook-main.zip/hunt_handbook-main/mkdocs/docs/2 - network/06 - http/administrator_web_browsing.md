# Administration web browsing

## Background -

Administrator accounts should not be browsing the internet. Doing this would allow any malware they view, click, or otherwise interact with to steal tokens with administration privileges, allowing malicious actors unobstructed access to all infrastructure on the network and establish persistence by whichever means they prefer.

### Example of Splunk Query -

```spl
index=zeek_http id.orig_h=$Administration method=GET
| eval Time=strftime(_time, "%m/%d/%y %I:%M:%S:%p")
| table Time id.orig_h id.resp_h status_code
```

!!!note "Note"
    $Administration should be replaced with whatever IP or IP range is identified to be administration boxes.

## Hive Case

### Main page -

**Title:** Administration Accounts Reaching the Web  
**Severity:** Low  
**TLP:**  
**PAP:**  
**Assignee:**  
**Tags:** network  
**Description:** Catalog instances of administration actively browsing the internet.

### Case tasks -

If an analyst encounters administration actively browsing the internet, a ticket should be generated and the local network owners should be consulted to ensure this browsing falls within their policies.
