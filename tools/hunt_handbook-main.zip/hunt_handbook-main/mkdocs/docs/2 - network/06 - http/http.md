# HTTP Additional

## Background

If there is an interesting query in the URI (ie a scanning field), search for other URIs by IP performing the scanning.  Table of source IP to multiple destination IPs with list of URIs.

```spl
index=zeek_http
  [ search index=zeek_http uri="*/?rest_route=/wp/v2/users/*"
  | stats count by id.orig_h
  fields - count ]
| fillnull value=NULL
| stats values(id.resp_h) values(uri) by id.orig_h referrer
| rename values(id.resp_h) as id.resp_h
| lookup asnserver ip as id.orig_h
| table id.orig_h referrer id.resp_h values(uri) as_description as_country_code as_number
| rename id.orig_h as "Source Host" referrer as "Referrer" id.resp_h as "Destination Host" values(uri) as "URI List" as_description as "ASN Description" as_country_code as "ASN Country" as_number as "ASN"
```

Combine the IP Address with the ASN Description so that the list returned has a complete 1-to-1 for source IP and ASN Description

```spl
index=zeek_http
  [ search index=zeek_http uri="*/?rest_route=/wp/v2/users/*"
  | stats count by id.orig_h
  fields - count ]
| lookup asnserver ip as id.orig_h
| search as_description="*DIGITALOCEAN*"
| strcat id.orig_h " - " as_description ip_asn
| stats dc(id.orig_h) values(ip_asn) as ip_asn by uri
```

Table grouping ASN Description and count of IPs from ASN Description

```spl
index=zeek_http
  [ search index=zeek_http uri="*/?rest_route=/wp/v2/users/*"
  | stats count by id.orig_h
  fields - count ]
| lookup asnserver ip as id.orig_h
| stats dc(id.orig_h) values(id.orig_h) as id.orig_h by uri as_description as_country_code as_number
| table id.orig_h as_description as_country_code as_number dc(id.orig_h) uri
| rename id.orig_h as "Source Host" uri as "URI" as_description as "ASN Description" as_country_code as "ASN Country" as_number as "ASN" dc(id.orig_h) as "Count of IPs"
```
