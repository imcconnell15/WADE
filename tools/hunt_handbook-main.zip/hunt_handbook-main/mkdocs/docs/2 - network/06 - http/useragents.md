# User Agent Profiling

## Background -

User Agents often give away tool use on a network e.g. NMAP. NMAP can be used to identify services and potentially allow attackers to profile these same services to identify a vulnerability.

!!! note "User agents"
    User Agents help identify the nature of behavior of web traffic. They can highlight things such as operating systems, browsers, version information, and at times tools. This helps us identify events that could be deemed anomalous. An example of low hanging fruit would be an NMAP user agent string (UAS). Unless a system admin is actively operating and using this tool on the network, we should never see a UAS tied to it. Another example would be seeing a Linux UAS on a Windows user farm performing browsing. This could indicate an unexpected box (physical or virtual) on the network.

### Example of Splunk Query -

```spl
index=zeek_http user_agent=* | dedup user_agent | table user_agent
```

!!! note "Note"
    Use of a User Agent parser may determine anything from which OS is being used on the network to which browser version. However User Agents can be spoofed.

## Hive Case

### Main page -

**Title:** User Agent Cataloging  
**Severity:** Low  
**TLP:**  
**PAP:**  
**Assignee:**  
**Tags:** network  
**Description:** Categorize User Agents on the network.  

### Case tasks -

If an analyst encounters suspicious User Agents e.g. NMAP, a ticket should be generated and the local network owners should be consulted to ensure this browsing falls within their policies.
