# SMB Overview

> It is no easy feat to differentiate among normal, suspicious, and malicious SMB activity.
Reference: [Zeek Docs](https://docs.zeek.org/en/master/logs/smb.html)

## SMB is not only SMB

When investigating SMB its important to understand that SMB traffic is most likely not the complete picture. SMB traffic will also involve authentication via Kerberos or NTLM as well as associated zeek connection logs. For example zeek connection logs will list different services involved with a connection on destination port 445 such as `gssapi,smb,dce_rpc,krb` which are all services related to an SMB connection.  This example contains traffic that represents Generic Security Service Application Programming Interface, Server Message Block, Distributed Computing Environment Remote Procedure Call, and Kerberos.  It is always a viable solution, if the traffic is of interest, to pivot on the **UID** which is a string across multiple zeek logs to identify all the traffic associated with the same connection.

## SMB Traffic leaving the network

A simple network orientation task is to determine if SMB traffic is allowed and/or is leaving the private IP space.

```spl
index=zeek_smb id.resp_h!=10.0.0.0/8 id.resp_h!=172.16.0.0/12 id.resp_h!=192.168.0.0/16
```
