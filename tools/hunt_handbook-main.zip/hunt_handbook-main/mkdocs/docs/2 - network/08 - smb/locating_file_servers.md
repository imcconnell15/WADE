# Finding possible file servers

## Background -

A high volume of traffic from multiple host to a single host with file manipulation could indicate a file server.

Example Splunk query:

```spl
index=zeek_smb id.resp_p IN (445, 139) | top limit=5 "id.resp_h"
```

!!! note "Limit"
    The limit can be adjusted to or omitted to increase or reduce the number of results returned. Large networks my have more than 5 file servers.

---

## Hive Case

### Main page -

**Title:** Potential File Server  
**Severity:** Low  
**TLP:**  
**PAP:**  
**Assignee:**  
**Tags:** network  
**Description:** A high volume of traffic to a single IP on destination port of 445 or 139 has been observed  

### Case tasks -

Locating the file servers on a network can be beneficial in identifying critical infrastructure and possible network targets of interest as well as unauthorized file servers.
