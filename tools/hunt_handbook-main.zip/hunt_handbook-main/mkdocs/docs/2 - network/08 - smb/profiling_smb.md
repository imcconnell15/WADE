# Profiling SMB

## Background -

Profiling SMB can show patterns in the traffic baseline that could indicate a high number of file manipulations such as downloading files, rewriting files, deleteing files, and uploading files. These timeframes would be of interest and require further investigation, like for example a spike in SMB activity during non-business hours.

## Profiling across time

Example Splunk query:

```spl
index=zeek_smb | timechart count

```

!!! tip "Tip"
    Looking at the Visualization results may make identifying spikes or anomalies in SMB traffic easier than looking at Statistics alone.
---

## Hive Case

### Main page -

**Title:** Profiling SMB timeline  
**Severity:** Low  
**TLP:**  
**PAP:**  
**Assignee:**  
**Tags:** network  
**Description:** Profile of SMB activity observed during unusual time period.  

### Case tasks -
