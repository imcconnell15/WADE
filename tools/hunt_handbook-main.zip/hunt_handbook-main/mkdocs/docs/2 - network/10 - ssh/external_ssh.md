# SSH External to Internal Private IPs

## Background - 

SSH traffic from an external IP address to an internal private IP can be indicative of an abnormal connection. Finding SSH connections from external to internal private IPs could indicate data exfiltration or infiltration, as well as C2 connections.

### Example of Splunk Query - 

```spl
index=zeek_ssh (id.resp_h=10.0.0.0/8 OR id.resp_h=172.16.0.0/12 OR id.resp_h=192.168.0.0/16) 
| search NOT (id.orig_h=10.0.0.0/8 OR id.orig_h=172.16.0.0/12 OR id.orig_h=192.168.0.0/16)
| eval time=strftime(_time, "%m/%d/%y %I:%M:%S:%p")
| table time id.orig_h id.orig_p id.resp_h id.resp_p
| rename id.orig_h as "Source IP" id.orig_p as "Source Port" id.resp_h as "Destination IP" id.resp_p as "Destination Port"
```

## Hive Case

### Main page -

**Title: External to Internal SSH Connection Attempt**
**Severity:** Low  
**TLP:**  
**PAP:**  
**Assignee:**  
**Tags:** network  
**Description:** Catalog external hosts that have attempted to connect to an internal host via SSH.  

### Case tasks -
Research the external IP to determine if it is a known bad IP. Find out if the connection was successful and determine what/if any data was transmitted during the connection. If the connection attempt failed, determine if there was more than one failed attempt.
