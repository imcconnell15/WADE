# SSH Internal to External IPs

## Background - 

SSH traffic originating from internal IPs to external IPs could indicate certain types malicious activity such as malware C2, or data exfiltration.

### Example of Splunk Query - 

```spl
index=zeek_ssh (id.orig_h=10.0.0.0/8 OR id.orig_h=172.16.0.0/12 OR id.orig_h=192.168.0.0/16)
| search NOT (id.resp_h=10.0.0.0/8 OR id.resp_h=172.16.0.0/12 OR id.resp_h=192.168.0.0/16)
| eval time=strftime(_time, "%m/%d/%y %I:%M:%S:%p")
| table time id.orig_h id.orig_p id.resp_h id.resp_p
| rename id.orig_h as "Source IP" id.orig_p as "Source Port" id.resp_h as "Destination IP" id.resp_p as "Destination Port"
```

!!! note "Query Syntax"
	This query may change if there are public routed internal IPs

## Hive Case

### Main page -

**Title: Internal to External SSH Connection Attempt**
**Severity:** Low  
**TLP:**  
**PAP:**  
**Assignee:**  
**Tags:** network  
**Description:** Catalog internal hosts that have attempted to connect to an external host via SSH.  

### Case tasks -
Research the destination IP to determine if it is a known bad IP. Find out if the connection was successful and determine what/if any data was transmitted during the connection. If the connection attempt failed, determine if there was more than one failed attempt.
