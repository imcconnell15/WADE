# SSH Over Non-standard Ports

## Background - 

SSH servers almost always run on port 22. That port is, after all, the well known port that is assigned to the service. Using a port other than the standard port may indicate attempts to hide or obfuscate the SSH connection.

### Example of Splunk Query - 

```spl
index=zeek_ssh id.resp_p!=22 auth_success=true
| eval time=strftime(_time, "%m/%d/%y %I:%M:%S:%p")
| table time id.orig_h id.orig_p id.resp_h id.resp_p
| sort -id.resp_p
| rename id.orig_h as "Source IP" id.orig_p as "Source Port" id.resp_h as "Destination IP" id.resp_p as "Destination Port"
```

!!! note "Auth Success"
	Zeek SSH attempts to determine if the SSH login is successful, however it cannot read into an encrypted protocol.  The auth success may say true which could indicate a successful SSH connection, but the login could have failed and zeek won't see the failed login within the encrypted session.

## Hive Case

### Main page -

**Title: SSH Connection on Non-Standard Port**
**Severity:** Low  
**TLP:**  
**PAP:**  
**Assignee:**  
**Tags:** network  
**Description:** Catalog hosts that have unusual SSH connections via ports other than 22.  

### Case tasks -
While its not uncommon to find SSH connections on ports other than 22, finding these connections within the network will require consulting local network owners to determine if it is legitimate traffic or if it is anomalous.
