# Long SSH Connections

## Background - 

Long SSH connections can be normal, but may also signify malicious activity. SSH by default should timeout based on the system TCP timeout. If a connection is abnormally long, it could indicate reconnaissance, infil/exfiltration of data, or attempts to pivot within the network.

### Example of Splunk Query - 

```spl
index=zeek_conn service=ssh
| eval megabytes_in= tostring(round(bytes_in/1024/1024, 2))+ " MB"
| eval megabytes_out= tostring(round(bytes_out/1024/1024, 2))+ " MB"
| eval duration_rounded= round(duration,2)
| eval time=strftime(_time, "%m/%d/%y %I:%M:%S:%p")
| table time id.orig_h id.resp_h duration_rounded megabytes_in megabytes_out
| sort -duration_rounded
| rename id.orig_h as "Source IP" id.resp_h as "Destination IP" duration_rounded as Duration(Secs) megabytes_in as "Data In" megabytes_out as "Data Out"
```

## Hive Case

### Main page -

**Title: Long SSH Connection**
**Severity:** Low  
**TLP:**  
**PAP:**  
**Assignee:**  
**Tags:** network  
**Description:** Catalog SSH connections that are longer than normal that warrant further research.  

### Case tasks -

Long SSH connections should be brought to the local network defenders to determine if the connection was legitimate. Further research should be conducted to discover if pivoting occured from the host to another. The amout of data transfered should be reviewed to help determine what may have happened during the connection.
