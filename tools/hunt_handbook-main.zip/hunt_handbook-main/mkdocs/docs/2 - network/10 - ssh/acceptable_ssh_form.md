
# SSH Connections Across Network Segments

## Background - 

SSH connections from host networks to server networks may be for legitimate administrative purposes. SSH connections from server networks to local or external networks generally should not occur unless authorized by local policy. SSH Connections from anything external is highly unusual. Any SSH connection could be used for malicious activity like reconassence, malicious downloads, and data exfiltration.

### Example of Splunk Query - 

```spl
index=zeek_ssh id.orig_h=$Server_Network id.resp_h=$Host_Network
| eval time=strftime(_time, "%m/%d/%y %I:%M:%S:%p")
|table time id.orig_h id.resp_h auth_attempts
| sort -auth_attempts
| rename id.orig_h as "Source IP" id.resp_h as "Destination IP" auth_attempts as "Connection Attempts"
```
!!! note "Note"
	$Host_Network and $Server_Network will need to be replaced with the IP ranges of the corresponding networks. These can also be replaced with server to external net or any combination desired.

## Hive Case

### Main page -

**Title: Suspicious SSH Connection**
**Severity:** Low  
**TLP:**  
**PAP:**  
**Assignee:**  
**Tags:** network  
**Description:** Catalog SSH connections between endpoints that maybe shouldn't be communicating via SSH.  

### Case tasks -

Upon discovering a suspicious SSH connection, consult with local network owners to determine if the two endpoints should be communicating via SSH. If the local network owners determine the endpoints should not be communicating, run further queries to determine if there is any other anomalous network traffic coming from the suspect hosts. Pass to host analysts for potential host image when warranted.
