# SSH Versions

## Background - 

There are two versions of SSH: v1 and v2. SSH v1 should not be used because it is vulnerable to man-in-the-middle attacks. There are several different SSH clients. OpenSSH is the most common SSH client, and newer versions of the client are secure, but there are older versions with known vulnerabilities. Encountering uncommon SSH clients could be a cause for concern, as many lesser known clients may be unsecure.

### Example Queries - 

```spl
index=zeek_ssh version!=2
| stats count by client
| sort count
```

```spl
index=zeek_ssh
| rare limit=20 client
```

!!! note "Filtering Results"
    rare can be used to limit the number of results to the "x" least occuring results.  This number can be adjusted to whatever helps an analyst to perform long-tail analysis.

## Hive Case

### Main page -

**Title: Insecure SSH Version**  
**Severity:** Low  
**TLP:**  
**PAP:**  
**Assignee:**  
**Tags:** network  
**Description:** Catalog SSH versions or client versions that have known vulnerabilities.  

### Case tasks -

If SSH v1 is discovered within network traffic, local network owners should be notified and advised to update their SSH servers to only support SSH v2. If unusual or outdated SSH client versions are are encountered, research should be conducted to determine any known vulnerabilities. Tickets should be generated for any vulnerable SSH versions discovered.
