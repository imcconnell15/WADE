# Single Character filenames

## Background  

Often times an adversary will exchange files with short meaningless names.  The below search extracts file names with a RegEx (based on Windows \ pathing for the location), looking for characters after the last \ in the path.  Those extracted filenames are then examined with another RegEx that looks for one character with a three character extension.  The files returned from this search should be examined for legitimacy

!!! note "Google"
    It has been my experience that Google uses a file called `f.txt` frequently in its operations and a high number of these files from Google should be legitimate.

!!! note "SMB"
    These files can also be discovered in SMB traffic.  Search the SMB indexes and adjusted file extraction accordingly.

```spl
index=zeek_files
| rex field=filename "(?P<extracted_filename>[^\\\]+)$"
| rex field=extracted_filename "(?P<short_file>^\w{1}\.\w{3})$"
| search short_file=*
| stats count by extracted_filename short_file
```

## Expected outcomes

Once the exchange of single characters filenames have been discovered.  Further research the source and destination to determine where the files came from, such as ASN owner or associated DNS queries.  Expand the time window because the file exchange could be apart of a bigger communication event.  If the file events can not be easily explained create a case and elevate for further review.
