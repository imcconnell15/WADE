# Split/Chunked Files

## Background

Malicious cyber actors will frequently attempt to get data in or exfiltrate data from a network by splitting or chunking the data into multiple parts.  Examining network traffic for filenames that follow consistent incrementing naming schemes can help to highlight this activity.

For example a file could be split into multiple parts using numbers to indicate the different parts:

- `file001.zip`, `file002.zip`, `file003.zip`, ....
- `document.001`, `document.002`, `document.003`, ...

The linux command utility `split`, used for splitting large files into smaller parts, has a standard naming convention that should be of interest if seen in filename:

- `xaa`, `xab`, `xac`, ...

## Splunk search

The following search sorts be filename, incrementally named files should be grouped together for easier visibility.

```spl
index=zeek_files
| rex field=filename "(?P<extracted_filename>[^\\\]+)$"
| search extracted_filename=*
| stats count by extracted_filename
| sort - extracted_filename
```

## Expected outcomes

Once the exchange of files being split into smaller parts is discovered.  Further research the source and destination to determine where the files came from, such as ASN owner or associated DNS queries.  Expand the time window because the file exchange could be part of a bigger communication event.  If the file events can't be easily explained create a case and elevate for further review.

### Possible Related to other activity

[Using `type` command to combine file]("../../3 - hosts/extra information/op-tainted-love.md")
