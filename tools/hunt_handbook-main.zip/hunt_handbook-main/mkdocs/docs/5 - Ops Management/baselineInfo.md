# Baseline Info

Baseline information will be stored in a widely-available folder/document structure so that every analyst can read and update.

An example of this is an Obsidian vault that contains the following folder structure:

`00 Network information` (folder)
	`Subnet IP range or VLAN` (folder)
		`IP address and/or HostName` (file).
		

All enumeration information regarding that specific IP address or hostname will be documented in that file.

Some examples include:

- IP address
- MAC address
- users
- user groups
- purpose
- operating system 
- patch level
- security controls
- software known to be in use
- network connections/patterns

