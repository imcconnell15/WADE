# Task Prioritization

Tasks should be worked in order of priority:

1. Open Cases or Investigations.  These tasks are known and open, escalated from a lower tier.
2. Alerts from automated systems. These tasks start with an observed event that triggers an alert on known bad activity.
3. T-Code hunting. These tasks start with analysis of adversarial TTPs assessed as likely to be on the network.
4. Long-tail analysis. These tasks start with an analyst looking at rare events to see if anything appears suspicious. Long-tail analysis tasks do not have analysis or IOC triggers to focus efforts, and requires a higher level of analytic skill. 