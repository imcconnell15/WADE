# Investigation flow
1. Suspicious activity identified by analyst
2. Verified by senior analyst
3. Confirmed by Crew Lead
4. Open case
5. Collect host image if appropriate
6. Narrow network analysis by timeframe
7. Host image analysis
8. Pass on malicious files to malware analyst