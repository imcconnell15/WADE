# Case Management

Some guidance on writing and managing cases. Some of this may not be applicable if analysts have a common note-taking platform.

Maintain cases at TLP:AMBER **(Why TLP?  Why Amber?)**

Severity:
L - Low impact, informational, best practice 
M - Minor impact, system functional, single system affected 
H - Significant impact, interruption to services, multiple hosts 
C - Critical impact, full network or domain compromised (Always start at L) 


3. Case name - HOST - ISSUE or NETWORK - ISSUE **(Is it useful to define Host or Network in the title of the case?)**

4. Tags - Host, Network, Malware, Intel

Case description - Executive Summary of case for Leads and Leadership

Tasks - Where analysts document their findings and analysis. Network, Host, and Malware add different tasks with their analysis as needed or applicable. Ensure all applicable indicators are documented and relevant artifacts are attached (PCAP, Screenshots, Logs, etc).  

Observables - Add specific indicators like IP addresses, file names, hashes, etc, that are relevant to the case.

Daily Case Management:
- Analysts hunt and work on the cases they created and add any updates.
- Leads manage and track their cases and provide updates to MEL and MC.
- New cases are only created by approval by leads.
- Only leads can close cases. Closing cases requires documentation and determination of finding (Tier 1, Tier 2, Tier 3, false positive, no finding/no action required)  

**What are the Tiers 1-4?  Are they the same as the Severity levels listed above?**