# IRIS-DFIR

IRIS-DFIR can be used for all investigations and cases. 

# Data Flow

All investigations can be opened as a "case" in Iris. Through the investigation process they will either be escalated or closed with specific flags or statuses for additional reporting.

# Summary
The summary will be updated daily or as needed to provide a paragraph or two of an executive summary.

# Notes
All analyst notes should be entered here. Analysts should write their own notes and avoid modifying notes.

# Case Status
- Open: all investigations start in this state
- Closed-Benign: Benign activity that does not need to be reported further.
- Closed-Finding: A security finding that should be reported but needs no additional investigation.
- Case-Escalated: An evaluated case that requires priority analysis from both Host and Network crews.
- Closed-Reportable: An escalated case that has a concluded investigation.

# Case Templates
Case templates are still under construction.

# Tasks
Each case can have tasks assigned to individual analysts.

# Datastore
The datastore holds the evidence, IOC lists, and screenshots/images associated with the case.
## Evidence 
Evidence can either be uploaded to the datastore for the case, or "registered" so that the metadata is stored but the data is not stored in Iris.
## IOCs
The use of this section of the datastore has not been decided.
## Images
Screenshots can be uploaded to the case datastore here. A markdown link is available to copy into the notes or summary to provide context, though this may prevent exporting in the report templates.

# Reports Templates

# References:
[Quick Start - Documentation](https://docs.dfir-iris.org/getting_started/)