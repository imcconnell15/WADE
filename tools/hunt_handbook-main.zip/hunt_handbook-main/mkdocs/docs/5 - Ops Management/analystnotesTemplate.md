# Goal
- T-Code number:
- Alert Name:
- Case Number/Name:
- Capability (infrastructure)

# Hypothesis

"If the adversary is doing xxxxxx, I will see artifacts mmm, nnn, and ooo in locations aaaa, bbbb, and cccc.  

# Steps Taken

Include every query that produces useful results, whether positive or negative.  Negative results are useful so that no one has to go back and run the query again for that time range.

# Conclusion

This activity is categorized as malicious/benign/unknown because of the following: