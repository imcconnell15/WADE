# Cyber Threat Intelligence Analyst

# Pre-Mission
## Establish Communications and Configure Tools
1.	Make contact with Embassy/in country military teams.
2.	SAARs to in-country locations for SIPR/JWICs/NSA Net.
3. Validate accounts to relevant websites for work purposes.
4. Ensure work-related websites are accessible through VPN of choice.
5. Establish method to receive and disseminate CI/HUMINT concerns as needed
6. Set up kit environment for intel. *What does this mean? Why is ASA doing it and not Infrastructure Team?*

## Products and Information for Team
1. Create ASOM (brief General) *Creating the ASOM is not an intel function*
2. Create adversary brief (brief team)
3. Create IOC bank and provide to team. 
4. Build TTP overlay for intrusion sets of interest. 
5. Create hunt plan intel portion and provide to team.  *How is this different from the ASOM?*
6. Provide RFIs to TF2 regarding any needs and Yara/Suricata/Snort rules.  *How is this different than creating the IOC bank?*
7. Provide updated CI/HUMINT threats and posture to team if changes occur.  *Doesn't this fall on the actual CI/HUMINTers?* 



# On Mission 	

## Communicate with Team
1. Validate kit workstation and access to all necessary services.
2. Provide analysis on findings, for example, attribution assessments, C2 nodes, malware analysis (matching malware to activity and activity to malware), matching TTPs to intrusion sets, what activity makes this situation unique and how does this match activity that is unique to intrusion sets. Match kill chains that have already been documented to current activity.
3. Verify with Host Lead if beginning steps of malware killchain occurred. 
## RFI Management
1. Set up RFI tracker. 
2. Establish RFI guidelines for the team. Items of interest include: context for IPs and hashes (what is it doing), location of activity on the network, length of activity, frequency of activity, etc. 5ws. 
3. Intake and process RFIs that you can on site. Push others to the Rear Support Element.
4. Document RFI responses in baseline documentation for future reference.  
## Communicate with Partner
1. Familiarize yourself with reporting lines of effort in country, and notify any individual who needs to be pushing up information you come across. 
2. Refer intrusive questions or partner RFIs to team lead, elevator speech.
## Communicate with Rear Support and Higher Command
1. Establish/validate communications with rear support.
2. Establish SIPR and high side accounts with in country team/Embassy. This is something you’ll want to do ASAP due to processing times. 

## Extra Duties
1. Keep an eye out for suspicious behavior, CI threats, monitoring, unprofessional activity by the partner. Report anything of note, esp harassment, to the TL/MEL. (You can also report CI concerns via in country reporting assets).
2. Take notes on anything for FORMICA. 
3. Write up and summarize any intel findings for the FTR. 
4. Provide AAR for intel. Keep track of any AAR items as you go. 


# Post Mission
1.	Turn in gear. 
2.	Assist with AARs and FTR. 
3.	Extract from the kit all notes, templates, and other documents useful for reporting or use on future missions.
4.	Review and update SOPs and other documentation. 
5.	Arrange FORMICA debrief as needed.