# Battle Rhythm

## Daily tasks

- sync with the customer/partner for RFIs and updates
- sync with forward team crew leads and junior analysts to manage taskings
- updates to open cases and investigations
- generate SITREP in accordance with template
- rollup/chat with Rear Support

## Weekly tasks

- Voice comms with Rear Support (1-3x weekly)
- Rollups with customer/partner