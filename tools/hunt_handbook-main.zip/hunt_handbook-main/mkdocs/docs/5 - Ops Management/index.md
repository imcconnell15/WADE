# Operations Management

This section of the hunt handbook is designed to provide guidance to the MEL and Crew Leads on how to run the operation.