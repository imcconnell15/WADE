Below is a brief overview of the roles and responsibilities of leadership personnel:

# Mission Element Lead (MEL)

The Mission Element Lead is the senior technical person on a mission.  Primary duties are to supervise the crew leads (infrastructure, host, and network), and advise the Mission Commander.  Responsibilities include
- establishing information flows within the team, with rear support, and higher commands
- setting priority of taskings within the scope of the mission requirements
- ensure the crew leads execute in accordance with mission parameters
- developing a hunt plan/ASOM to execute mission requirements based on available intel
- coordinating communication with the customer for RFIs, mission data, and respnose.
- presenting persuasive information to the customer
- provide demonstrations of tools and capabilities when appropriate



# Host Crew Lead / Senior Host analyst

The Host Lead manages the tasks and output of the analysts assigned to the crew. The Host Lead provides technical advice to the MEL, MC, and other analysts. The Host Lead should communicate with the Network Crew Lead for smooth handoff of information.


# Network Crew Lead / Senior Network Analyst
 
The Network Lead manages the tasks and output of the analysts assigned to the crew. The Network Lead provides technical advice to the MEL, MC, and other analysts. The Network Lead should communicate with the Host Crew Lead for smooth handoff of information.

# Infrastructure Lead

The Infrastructure Lead provides expert guidance on connecting the kit to the customer's network and ingesting a wide variety of data for analysis. 


# Intel Lead

