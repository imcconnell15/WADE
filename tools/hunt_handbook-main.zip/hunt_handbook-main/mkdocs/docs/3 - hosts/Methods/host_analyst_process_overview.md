# Host Analyst Process Overview

Selecting a host to analyze is a critical step in the process.  The host should be selected based on the information available to the analyst.  The analyst should consider the following:
    - The importance of the host - is it a critical system?
    - Is the host suspected to be compromised?
    - Is the host a known compromised system?

## Identify Suspicious Host

Identifying a suspicious host can be done in a number of ways.  The analyst should consider the following:

### Known Compromise Reporting

The system owner may have one or more hosts that are known or strongly suspected to be compromised.  These systems may have triggered an antivirus alert or connected to an internal honeypot.

### Network Indicator

Indicators of Compromise found in the network traffic should trigger an investigation of the host.  Examples include beaconing, connection to malicious domains,

### Suspicious Activity Reporting

End users may report suspicious activity that could indicate a compromise.

### Endpoint Monitoring

Endpoint monitoring may trigger an alert that leads to additional investigation. This could include malware alerts, or user behavioral analytic triggers (e.g. ssh outside of business hours).

## Collect Host Data

Host data should be collected from a critical host to review for compromise and/or a suspected compromised host.  The analyst should collect information in the order of volatility and consider the following:

### Order of Volatility

1. CPU, cache and register content
2. Routing table, ARP cache, process table, kernel statistics, memory (capture memory)
3. Temporary file systems
4. Disk
5. Remote logging and monitoring data that is relevant to the system in questions
6. Physical configuration, network topology
7. Any relevant data on archival media

!!!note "Note"
    When possible, ask system owners to install some sort of endpoint monitoring tool on as many systems as is feasible.  If "all" is not acceptable, then focusing on critical systems may be useful to start.
