# Collect Host Data

Respect the [order of volatility](./host_analyst_process_overview.md#order-of-volatility) when collecting host data.

## Asset Location Methods

Physical collection relies on the ability of the analyst and the partner to locate the asset in question. The team should assist the partner in locating their asset by providing as much information as possible. Helpful information includes IPv4, IPv6, default gateway, MAC address, hostname, and serial number:

Based on network data the team can provide IPv4, IPv6, default gateway, and potentially MAC address as a means of assisting the partner with locating the asset depending on the tapping plan.

The target Hostname can be found in collected network traffic such as DHCP request packets and packets such as Session Service session requests.

In the event the team has EDR agents deployed there are a number of methods to collect this data, one example being the following commands in cmd: 

-	ipconfig /all
-	hostname
-	wmic bios get serial number

## Physical Collection Methods

Physical collection methods can be different depending on the operating system of the target host and the tools utilized.  The following are some common methods for collecting data from a host.

-	RAM and Critical files via [Magnet Response](../Tools/MagnetRESPONSE.md)
-	Disk Acquisition and RAM via [FTK Imager](../Tools/FTKImager.md)

### Windows

Physically collecting a potentially compromised machine requires cooperation with the partner and a proper order of operations to ensure efficient collection of a forensically sound image. The following steps are used to minimize risk of the USB as a malware vector:

-	FTK Imager executable is stored on an appropriate removable storage device. The executable should be renamed something inoccuous.
-	The team possesses write blocker and removable hard drive large enough to store the collected image and memory capture (2-4TB per drive). 
-	Verify the correct endpoint has been located.
-   Use [FTK Imager](../Tools/FTKImager.md), to capture target memory followed by target disk image.
-   Connect storage device with host data through a USB write blocker to a designated kit laptop, disconnected from the kit. If capabilities allow, this could be a Linux box for one additional layer of security against USB malware.
-   Scan the USB drive using available antimalware tools (Windows Defender, etc).
-   If no malware is detected, connect the laptop to the kit and transfer the data to the share drive for ingestion and analysis.
-   Remove the write blocker and wipe the disk.
-   If malware is detected ...

### Unix

Similarly to Windows collection, the analyst should verify they are operating on the correct machine before taking that machines image.
dd is a command-line utility for Unix and Unix-like operating systems, the primary purpose of which is to convert and copy files. In order to create a Unix forensic image, use the following commands:

-	sudo lsblk

Identify the drive to be copied.

-	sudo dd if=/dev/sdb1 of=/desired/file/location/image.dd bs=4096 conv=sync, noerror
-	sudo dd if=/dev/sdb1 of=/desired/file/location/image.dd bs=4096 conv=sync, noerror status=progress

Command explanation:

if=/dev/sdb1 is the source in this case is sdb1
of=/evidence/image.dd is where the output file is saved
bs=4096 is the block size (default is 512kb),
conv= sync, noerror conversion will continue even with read errors, if there is an error, null fill the rest of the block.

Once the file has been created it can be safely exported to the team’s equipment for ingestion.

## Virtual Machines

VM: collect .vmdk from partner. Ensure collection of virtual ram files and snapshots as necessary.

### Routers, Switches, Firewalls.

The team should make every effort to collect any and all available logs from networking devices. In the event the customer employs Syslog to aggregate network device logs, efforts should be made to acquire a copy of said data. When possible, coordinate with the partner local network operators to collect logs from these devices using methods such as SSH and SCP.

In many cases networking device operating systems will be Unix-like, utilizing “var/log” to store log files, which can be harvest and analyzed by the team. Procedures for these machines will deviate and should be used with an abundance of caution to ensure there are no partner network distributions.

The team is likely to encounter various layer 2/3 devices and operating systems, often requiring research and testing on a case by case basis. Below is an example on how to collect a forensic image of the most widely used network infrastructure software in the world, Cisco given command line access:

Access the command line of the Cisco IOS device and issue the following command in enable mode:

-	show version | inc image

Note the location and filename of the system image file and then execute the following command:

-	verify location:filename

Note that the embedded hash and computed hash should return the same MD5 value, and the CCO hash should match the MD5 value listed on CCO or in the Bulk Hash File for that particular image file.

Repeat the above procedure for any other system image file located on the file systems. A comprehensive list of all files can be viewed by executing the following command:

-	dir /recursive all-filesystems

If any of the image file hashes show inconsistencies, copy the image file in question to a secure location.

The authenticity and integrity of a system image file can be verified by using the following command:

-	show software authenticity file location:filename

It is also important to verify the authenticity and integrity of the running system image, and this can be accomplished with the following command:

-	show software authenticity running

One less intrusive method for collecting the runtime image and memory of an IOS device is to access the CLI of the IOS device and issue the following commands in enable mode:

-	show region
-	verify /md5 system:memory/text
-	copy system:memory/text [appropriate network location]

CAUTION: This section contains commands that alter device configuration. Ensure that the team has the appropriate authorization from the partner to make temporary changes to the platform in question prior to proceeding with the following steps.

This procedure outlines how to configure an IOS device in order to obtain a dump of platform memory. To configure the appropriate dump parameters, enter the following commands in enable mode:

-	conf t
-	service timestamps debug datetime msec localtime 
-	service timestamps log datetime msec localtime 
-	service internal 
-	exception core-file <filename.bin> compress
-	exception region-size 65536
-	exception dump <destination_ip_address>
-	exception protocol ftp
-	ip ftp username <username>
-	ip ftp password <passwword>
-	end

CAUTION: Initiating a core dump on an IOS device can be CPU intensive and may adversely affect traffic transiting the platform. To initiate the core dump process, execute the following command in enable mode:

-	write core

The core dump may take some time to complete, depending on the amount of physical memory (RAM) installed on the device. When the core dump process is complete, remove the core dump parameters as follows:

-	conf t
-	no service internal 
-	no exception core-file
-	no exception region-size
-	no exception dump
-	no exception protocol ftp
-	no ip ftp username <username>
-	no ip ftp password <password>
-	end

!!!note “Note: 1”
    This method assumes FTP as the method for transmitting this data, which can be several gigabytes large. Other methods include RCP, Flash Disk, and TFTP.

## Remote Collection Methods

Remote collection will largely depend on the target environment and what remote access tools the partner employs. Examples include PowerShell remoting, SSH, Telnet, Network Shares, Group Policy, and various methods of remote desktop connection. The primary tool for remote collection will be through established EDR agents. In the event the team is unable to deploy at scale this section will cover additional methods of log and memory collection.

### Windows

Collecting logs:

-	Carbon Black: Using live query, issue the following commands:
    -	(place holder)

-	Velociraptor: Can be completed using the client artifact System.VFS.DownloadFile or by recursively downloading C:\windows\system32\winevt\log manually via the virtual file system. 

-	Splunk Universal Forwarder: A properly configured agent will automatically ship logs from the target system to the Splunk server.

-	PowerShell: If the customer employs PSremoting to remotely administer machines the team can leverage this capability to collect host logs from individual machines or at scale:
    -	(Place Holder)

-	Group Policy: Group policy is an enormously powerful tool that can be configured for windows event forwarding, as well as scripted actions and other methods of remote access to domain joined machines at scale. Onetime scheduled tasks can be issued to machines to copy their log files to a shared network location for the team to collect.

Memory dump:

-	CarbonBlack: Carbon black has the capability to create a live memory dump on endpoints which can then be downloaded via the agent. Data transmission speeds are a limiting factor and file corruption is not uncommon using this method.
    -	Open a live response session open the target endpoint.
    -	Use the “cd” command to navigate to where the file should be staged.
    -	Use the “memdump” command.
    -	Use the “get” command to download the file form the agent.
    -	Verify successful download.
    -	Use “execfg cmd /c del [filename]" to delete the file from the remote location.
    -	Verify file deletion.

-	Velociraptor: Similar to CarbonBlack, remote memory acquisition will take significant time and resources. This can be completed using the live command portion to access and run dumpit.exe and then collecting the resulting memory dump.

-	Splunk:
    -	(Place Holder)

-	PowerShell: Similar to log collection, PSremoting can be used to have workstations execute FTKimager.exe or Dumpit.exe from an accessible network location and create a live memory capture. This file will need to be collected, uploaded to a share or otherwise delivered to team equipment for analysis.
    -	(Place holder, script pointed at an accessible dumpit.exe)

-	Group Policy:
    -	Same as above

Disk Image:

CAUTION: Collecting a disk image remotely can have adverse effects on partner machines and networks. File size is a consideration, as is bandwidth to the target and RAM/CPU consumption.

These methods will closely mirror the ones used for acquiring memory dumps but will target FTKIMager.exe instead of dumpit.exe.

### Unix (Place Holder)

-	Velociraptor:
-	Splunk:
-	SSH/SCP:
-	SAMBA:
-	Simple Python HTML Server:
-	RDP

### Routers, Switches, Firewalls.

SSH/SCP: If the customer employs SSH or similar remote administrative consoles such as Telnet the team can leverage this capability to remotely collect /var/log, system configurations, Iptables, crontab and any other likely locations of adversarial activity.

HTML: Many layer two devices support html based management portals that can also be used to view or even export logs and other forensically relevant data. The team should make every effort to collect this data with the partners support.
