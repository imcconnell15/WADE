# Host Ingest Process

After RAM and disk image have been acquired and uploaded to the kit share drive, the data needs to be ingested.

1. If needed, recombine E01 to a single file using `ewfexport`.
2. Dissect script (`wade.sh`) extracts baseline information in a json format. This data is forwarded to Splunk.
3. Dissect script runs a yara scan on the image. The alerts are written in json and forwarded to Splunk.
4. Dissect extracts Windows event logs.
5. Hayabusa scans the event logs with sigma rules. The alerts are written in json and forwarded to Splunk.
6. Use Log2timeline/plaso and psort to generate a json of the timestamped events on the disk.
7. Ingest the E01 file into Autopsy.
8. Run `volatility-output.sh` against the memory capture. The data is written in json and forwarded to splunk.