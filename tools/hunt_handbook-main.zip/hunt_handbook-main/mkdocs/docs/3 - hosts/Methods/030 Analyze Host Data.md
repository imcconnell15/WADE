# Analyze Host Data

## Prioritize by indicator

Begin with the specific indicator that triggered this investigation.  Document its interactions with each category of artifacts - memory, network connections, files, registry keys, logs, user activity.  Expand this for each new artifact found.

## Memory Analysis

### Memory Analysis with Volatility

- Volatility is the framework for memory analysis. This tool is vital for a forensic investigation. Volatility provides a means of digging into the volatile data that would otherwise be lost. Volatility comes in two flavors, Vol2 and Vol3. Vol2 is deprecated and requires an analyst to use profiles to run against specific operating systems. It still useful and should still be used in parallel with Vol3. Vol3 is the newest version of Volatility and does not require a user to use profiles.

### Vol2 Commands

- `volatility -f <ramcaptuerimageinfo> imageinfo`
    - This command attempts to identify the profile that will work on this specific imagine. This process can be difficult. Checking the system version information collected from the disk image can assist in the process. *Note: Windows 11 does not have any profiles*
- `volatility -f <ramcaptuerimageinfo> --profile=<chosen profile> <command>` - Replace `<command>` with the following options to get the information described by the command
    -`pslist`: provides a running process list, including PIDS and memory locations.
    - `pstree`: Shows a list of running processes and the lists family tree
    - `netscan`: One of the most important volatility commands that shows a list of network connections, connection states, IP and Port information, and can help identify any abnormal connections.
    - `memdump`: Memdump can be used to carve a file out of memory. This can be useful if the file does not exist on disk.
    - `cmdline`: A vital plugin for discovering previously ran commands.

### Vol3 Commands

- To eliminate redundancy, the below commands perform a similar function as volatility 2 unless noted otherwise. The main difference is that these commands do not require a profile.
    - `vol.py -f “/path/to/file” windows.pslist`
    - `vol.py -f “/path/to/file” windows.pstree`
    - `vol.py -f “/path/to/file” windows.cmdline`
    - `vol.py -f “/path/to/file” -o “/path/to/dir” windows.memmap ‑‑dump ‑‑pid <PID>`
    - `vol.py -f “/path/to/file” windows.netscan`
    - `vol.py -f “/path/to/file” windows.netstat`

### Strings

- Strings is Linux command line tool that prints the printable character sequences that are at least 4 characters long or as long as the user choses. This tool is useful in searching for artifacts in memory that are hidden, deleted, or otherwise not found by other means of analysis. Using strings to search for key items such as IP addresses, file names, or other logs provides another method of finding malicious activity. In this instance the strings command is ran against the memory dump and output to a file. Grep can then be used to search for key items of interest against that strings file. **Note: Runnings strings may show items that appear to be malicious. Often times, if it seems good to be true, it likely is. Any antivirus that is running will have signatures that will show up in memory. A good way to confirm this is by check for the EICAR signature file.
    - `strings ram.dmp > strings.txt`
    - `grep <search term> strings.txt`

### Volatile Data

- Magnet Response provides a packaged tool suite for memory forensic acquisition that includes the collection of pertinent volatile data and a full ram capture. Although some of this information can be analyzed via Volatility, Magnet Response provides important forensic artifacts that are collected concurrently with ram acquisition. This provides a quick triage before doing a full analysis of the memory. Important forensic artifacts that are gathered included event logs, the Master File Table, Scheduled Tasks, network connections, registry hives, and PowerShell history. The event logs can be ran through APT Hunter,  which uses pre-defined detection rules and focuses on statistics to uncover abnormalities which is very effective in compromise assessment. This provides a quick way to look for signs of an APT through event logs. The registry hives can be browsed using registry explorer. This tool helps uncover signs of persistence and signs of USB connections that could have been used for initial access. The other collected artifacts can be viewed using Visual Studio Code.

!!!note "Note:"
    The user account output from MR will likely show user accounts with the field of PasswordRequired: False. It is important to verify that the user account with that has a password. This field means that the user account can be configured to not have a password.

## Network Connections

The network team should be conducting focused targeted collection of the network traffic to and from the suspected endpoint. The host analyst should find out what processes and programs are generating traffic.

### Locations with information for Network Connections

- hosts file
- C:\\Windows\\System32\drivers\etc
- More artifacts exist via memory analysis. See Memory Tab

## Scheduled Tasks

- Scheduled tasks can be viewed on the disk by navigating to : C:\\Windows\\System32\\Tasks
- They can also be viewed within the saved files collected during the Magnet Response acquisition. "Saved_Files>Scheduled_Tasks"
- `%systemroot%\Tasks`
- Registry also can show schedules tasks:
    - `HKLM\Software\Microsoft\Windows NT\CurrentVersion\Schedule\Taskcache\Tasks`
    - `HKLM\Software\Microsoft\Windows NT\CurrentVersion\Schedule\Taskcache\Tree`

## Files

### Files and folder location on file system

- The file system is by far the most tedious avenue of analysis, but often provides the most concrete form of evidence. A full disk analysis takes time and patience. One of the biggest challenges is trying to find items that are different or standout in some sort of way. File names, their location and their timestamps. The below highlights some places that threat actors will store their tools or gathered artifacts. These are guiding principles and are by no means an all encompassing search.
- Look for suspicious files, some good starting points are:
    - prefetch, shimcache, etc
    - C:\\
    - C:\\Temp
    - C:\\Windows\Temp
    - User Folders
        - C:\\Users\Administrator\
    - Any non-default created Folders
        - C:\\NotNormal

### Executables

### Non-Executables

## Services

- Check for services that run upon boot
    - `System\\<CurrentControlSet>\\Services`
 0x02 means services will run on boot
- Search for services that are abnormal
    - No description, running out of Temp directory

## Registry Keys

- Compare against golden image or known good/standard when possible.
- Check For signs of persistence in run keys
    - HKLM\\Software\Microsoft\Windows\CurrentVersion\Run or RunOnce
- Registry can be search via the file system or RegistryExplorer
    - File System- C:\\Windows\\System32\\Config
        - Registry Can be viewed by clicking on the Application tab.
- Registry Explorer
    - A part of Zimmerman toolset
    - Extract the hive from the file system and Open using RE.
    - This tool gives an analyst the ability to browse logs, search for key items, and also comes with predefined bookmarks that are valuable in forensic investigations.

## Windows Event Logs

- There are two ways to view event logs, EventLog Viewer and APT-Hunter.
    - EventLog Viewer
    - [APT-Hunter](https://github.com/ahmedkhlief/APT-Hunter)
    - A python tool used to hunt APT activity through event logs. It uses pre-defined detection rules and focus on statistics to uncover abnormalities which is very effective in compromise assessment . the output produced with timeline that can be analyzed directly from Excel, Timeline Explorer and Time Sketch.
    - To run this tool:
        - `.\APT-Hunter.exe -p <path to logs> -o Project1 -allreport`
            - This will detect the type of log and then create a report based on its findings.