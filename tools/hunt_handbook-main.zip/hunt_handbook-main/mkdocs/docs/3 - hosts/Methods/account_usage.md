# Account Usage

## User Accounts

Identify both local and domain accounts with interactive logins to the system.

- Location: `SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList`
- Interpretation:
    - Subkeys are named for user SIDs and contain a ProfileImagePath indicating the user’s profile path
    - Useful for mapping SID to user account name

## Cloud Account Details

Microsoft Cloud Accounts store account information in the SAM hive, including the email address associated with the account.

- Location: `SAM\Domains\Account\Users\<RID>\InternetUserName`
- Interpretation:
    - InternetUserName value contains the email address tied to the account
    - The presence of this value identifies the account as a Microsoft cloud account

## Last Login and Password Change

The SAM registry hive maintains a list of local accounts and associated configuration information.

- Location: `SAM\Domains\Account\Users\<RID>\`
- Interpretation:
    - Last login time, last password change, login counts, group membership, account creation time and more can be determined
    - Accounts listed by their relative identifiers (RID)

## Service Events

Analyze logs for suspicious Windows service creation, persistence, and services started or stopped around the time of a suspected compromise. Service events also record account information.

- Location:
    - Win7+: `%SYSTEMROOT%\System32\winevt\logs\System.evtx`
    - Win10+: `%SYSTEMROOT%\System32\winevt\logs\Security.evtx`
- Interpretation:
    - Most relevant events are present in the System Log:
        - 7034 – Service crashed unexpectedly
        - 7035 – Service sent a Start/Stop control
        - 7036 – Service started or stopped
        - 7040 – Start type changed (Boot | On Request | Disabled)
        - 7045 – A service was installed on the system (Win2008R2+)
    - Auditing can be enabled in the Security log on Win10+:
        - 4697 – A service was installed on the system (from Security log)
- A large amount of malware and worms in the wild utilize Services
- Services started on boot illustrate persistence (desirable in malware)
- Services can crash due to attacks like process injection

## Remote Desktop Protocol (RDP) Usage

Track RDP logons and session reconnections to target machines.

- Location: (Security Log) - Win7+: `%SYSTEMROOT%\System32\winevt\logs\Security.evtx`
- Interpretation:
    - Multiple events can be used to track accounts used for RDP
        - Event ID 4624 – Logon Type 10
        - Event ID 4778 – Session Connected/Reconnected
        - Event ID 4779 – Session Disconnected
    - Event log provides hostname and IP address of remote machine making the connection
    - Multiple dedicated RDP/Terminal Services logs are also available on modern Windows versions

## Authentication Events

Authentication Events identify where authentication of credentials occurred. They can be particularly useful when tracking local vs. domain account usage.

- Location: (Security Log) - Win7+: `%SYSTEMROOT%\System32\winevt\logs\Security.evtx`
- Interpretation:
    - Event ID 4624 - Recorded on system that authenticated credentials
        – Logon Type 2 - Local Account/Workgroup = on workstation
        - Logon Type 3 - Domain/Active Directory = on domain controller
    - Event ID Codes (NTLM protocol)
        - 4624: Logon Type 2/3 (local/domain account)
        - 4776: Successful/Failed account authentication
    - Event ID Codes (Kerberos protocol)
        - 4768: Ticket Granting Ticket was granted (successful logon)
        - 4769: Service Ticket requested (access to server resource)
        - 4771: Pre-authentication failed (failed logon)
        - 4772: Ticket Granting Service (TGS) ticket request failed
        - 4777: Ticket Granting Ticket renewal failed

## Logon Event Types

Logon Events provide very specific information regarding the nature of account authorizations on a system. In addition to date, time, username, hostname, and success/failure status of a logon, Logon Events also enable us to determine by exactly what means a logon was attempted. Event ID 4624 is an audit logon event that records when an account was successfully logged. The logon type field indicates how the user logged on, such as interactively or over the network. There are nine different logon types, but the most common are 2 and 3. Logon type 3 is used when the client accesses the netlogon and/or sysvol shares for logon scripts or group policy. Logon type 2 is used when a user logged on to the computer directly.

- Location: (Security Log) - Win7+: `%SYSTEMROOT%\System32\winevt\logs\Security.evtx`
- Interpretation:
    - 2: Logon via console
    - 3: Network Logon
    - 4: Batch Logon
    - 5: Windows Service Logon
    - 7: Credentials used to unlock screen; RDP session reconnect
    - 8: Network logon sending credentials (cleartext)
    - 9: Different credentials used than logged on user
    - 10: Remote Interactive Logon (RDP)
    - 11: Cached Credentials
    - 12: Cached remote interactive (similar to Type 10) Cached unlock (similar to Type 7)

## Successful/Failed Logons

Profile account creation, attempted logons, and account usage.

- Location: (Security Log) - Win7+: `%SYSTEMROOT%\System32\winevt\logs\Security.evtx`
- Interpretation: Win7+
    - Event ID 4624 – Successful Logon
    - Event ID 4625 – Failed Logon
    - Event ID 4634 | 4647 – Successful Logoff
    - Event ID 4648 – Logon using explicit credentials (runas)
    - Event ID 4672 – Account logon with superuser rights (Administrator)
    - Event ID 4720 – An account was created
    - Event ID 4722 – A user account was enabled
    - Event ID 4723 – An attempt was made to change an account’s password
    - Event ID 4724 – An attempt was made to reset an account’s password
