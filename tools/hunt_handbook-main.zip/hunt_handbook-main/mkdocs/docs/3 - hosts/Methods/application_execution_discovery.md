# Application Execution

## Link Files

LNK files associated with files a user has recently accessed, typically by double-clicking on it in a Windows Explorer window.
    - Location: `C:\Users\%USERNAME%\AppData\Roaming\Microsoft\Windows\Recent`
    - LNK files do not give the entire information about the program that created the LNK file.  To view LNK file information use a tool like [LECmd](https://ericzimmerman.github.io/).

## Jump Lists

- Jump Lists allow user access to frequently or recently used items quickly via the task bar. First introduced in Windows 7, they can identify applications in use and a wealth of metadata about items accessed via those applications.
- Jump Lists are files that are generated on a per-user basis for two purposes.  
    - **AutomaticDestinations** Location: `C:\Users\%USERNAME%\AppData\Roaming\Microsoft\Windows\Recent\AutomaticDestinations` are auto-populated when an application associated with a file is run and stored in a subfolder within the Recent folder.  
    - **CustomDestinations** Location: `C:\Users\%USERNAME%\AppData\Roaming\Microsoft\Windows\Recent\CustomDestinations`folders are similarly
    stored in the Recent folder but are created when a user “pins” a file to the Start Menu or Task Bar.
- Interpretation
    - Each jump list file is named according to an application identifier (AppID). [List of Jump List IDs](https://dfir.to/EZJumpList)
    - Automatic Jump List Creation Time = First time an item added to the jump list. Typically, the first time an object was opened by the application.
    - Automatic Jump List Modification Time = Last time item added to the jump list. Typically, the last time the application opened an object.
- Jump Lists files themselves contain valuable information, including the last time the associated application was run and what files/LNKs were opened. To parse these, use an application like [JLECmd](https://ericzimmerman.github.io/).  

## Prefetch and Superfetch

- To improve application loading speed, Windows introduced Prefetch in Windows XP. Prefetch increases performance of a system by pre-loading code pages of commonly used applications. It monitors all files and directories referenced for each application or process and maps them into a .pf file. It provides evidence that an application was executed.
- In Vista, Superfetch was introduced which takes the concept further by tracking user behavior and attempting to predict which applications will be run and preemptively load them into memory.
- It should also be noted that Prefetch is not always enabled, particularly when the system is running on SSDs rather than spinning disk. This can be checked by examining the `HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters` registry key. If subkeys `EnablePrefetcher` and `EnableSuperfetch` show a value of 0, the function is not enabled.
- Limited to 128 files on XP and Win7
- Up to 1024 files on Win8+
- Location: `C:\Windows\Prefetch`
- Naming format: (exename)-(hash).pf
- `SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters EnablePrefetcher`
    - value: 0 = disabled or 3 = application launch and boot enabled
- Interpretation
    - Date/Time file by that name and path was first executed - Creation date of .pf file (-10 seconds)
    - Date/Time file by that name and path was last executed - Last modification date of .pf file (-10 seconds)
    - Each .pf file includes embedded data, including the last eight execution times (only one time available pre-Win8), total number of times executed, and device and file handles used by the program
- [PECmd](https://ericzimmerman.github.io/) can be used to parse .PF files. Two files are outputted from this application. One file is a CSV containing details about each file.
    - An empty space under the `PreviousRun0` field from **PECmd** indicates the program has only been run once.

## System Resource Usage Monitor(SRUM)

- Task Manager utilizes a small subset of data stored in the System Resource Monitor(SRUM) database, (introduced in Windows 8) for tracking resource use.
- While running, Windows temporarily stores this data in the `HKLM\SOFTWARE\Microsoft\Windows NT\CurrenVersion\SRUM\Extensions` and writes to **SRUDB.dat** at shutdown.
- SRUM records 30 to 60 days of historical system performance including applications run, user accounts responsible, network connections, and bytes sent/received per application per hour.
- Location: `C:\Windows\System32\SRU\SRUDB.dat`
- Interpretation
    - SRUDB.dat is an Extensible Storage Engine database
    - Three tables in SRUDB.dat are particularly important:
        - `{973F5D5C-1D90-4944-BE8E-24B94231A174}` = Network Data Usage
        - `{d10ca2fe-6fcf-4f6d-848e-b2e99266fa89}` = Application Resource Usage
        - `{DD6636C4-8929-4683-974E-22C046A43763}` = Network Connectivity Usage
- [SRUM Dump 2](https://github.com/MarkBaggett/srum-dump) can be used to examine SRUM.

## Registry Hives

- `HKCU\<User SID>\Software\Microsoft\Windows\CurrentVersion\Explorer\RecentDocs` – Stores several keys that can be used to determine what files were accessed by an account.
    - The **MRUListEx** key shows the order in which files were accessed.
- `HKCU\<User SID>\Software\Microsoft\Windows\CurrentVersion\Explorer\TypedPaths` - Shows items typed into the Windows Explorer bar by the user.
- `HKCU\<User SID>\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU` – Records items typed into the Windows Run dialog by the user.
- `HKCU\<User SID>\Software\Microsoft\Windows\CurrentVersion\Explorer\UserAssist` – ROT-13 encoded names of GUI programs that have been run and the number of times each has run.
- **Shellbags**:
    - For Windows XP, shellbag artifacts are located in the **NTUSER.dat** registry hive at the following locations:
        - `HKCU\Software\Microsoft\Windows\Shell`
        - `HKCU\Software\Microsoft\Windows\ShellNoRoam`
    - For Windows 7 and later, shellbags are also found in the **UsrClass.dat** hive:
        - `HKCR\Local Settings\Software\Microsoft\Windows\ShellBags`
        - `HKCR\Local Settings\Software\Microsoft\Windows\ShellBagMRU`
    - They can be manually parsed, but using a tool like [ShellBags Explorer](https://ericzimmerman.github.io/) can automate much of the work.

## Windows 10 Timeline

- Win10 records recently used applications and files in a “timeline” database in SQLite format.
- Location: `C:\Users\<profile>\AppData\Local\ConnectedDevicesPlatform\<account-ID>\ActivitiesCache.db`
- Interpretation
    - Full path of executed application
    - Start time, end time, and duration
    - Items opened within application
    - URLs visited
    - Databases still present even after feature deprecation in late-Win10

## BAM/DAM

- Windows Background/Desktop Activity Moderator (BAM/DAM) is maintained by the Windows power management sub-system. (Available in Win10+)
- Location:
    - `SYSTEM\CurrentControlSet\Services\bam\State\UserSettings\{SID}`
    - `SYSTEM\CurrentControlSet\Services\dam\State\UserSettings\{SID}`
- Interpretation
    - Provides full path of file executed and last execution date/time
    - Typically up to one week of data available
    - “State” key used in Win10 1809+

## CapabilityAccessManager

- Records application use of the microphone, camera, and other application-specific settings.
- Location:
    - `SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore`
    - `NTUSER\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore`
- Interpretation
    - LastUsedTimeStart and LastUsedTimeStop track the last session times
    - The NonPackaged key tracks non-Microsoft applications

## Shimcache - Windows Application Compatibility Database

- The Windows Application Compatibility Database is used by Windows to identify possible application compatibility challenges with executables. It tracks the executable file path and binary last modified time.
- Location:
    - `SYSTEM\CurrentControlSet\Control\SessionManager\AppCompatibility`
    - `SYSTEM\CurrentControlSet\Control\Session Manager\AppCompatCache`
- Interpretation
    - Any executable present in the file system could be found in this key. Data can be particularly useful to identify the presence of malware on devices where other application execution data is missing (such as Windows servers).
    - Full path of executable
    - Windows 7+ contains up to 1,024 entries (96 entries in WinXP)
    - Post-WinXP no execution time is available
    - Executables can be preemptively added to the database prior to execution.
    - The existence of an executable in this key does not prove actual execution.

## UserAssist

- UserAssist records metadata on GUI-based program executions.
- Location: `NTUSER.DAT\Software\Microsoft\Windows\CurrentVersion\Explorer\UserAssist\{GUID}\Count`
- Interpretation
    - GUIDs identify type of execution (Win7+)
        - CEBFF5CD Executable File Execution
        - F4E57C4B Shortcut File Execution
    - Values are ROT-13 Encoded
    - Application path, last run time, run count, focus time and focus count

## Task Bar Feature Usage

- Task Bar Feature Usage tracks how a user has interacted with the taskbar.
- Location: `NTUSER\Software\Microsoft\Windows\CurrentVersion\Explorer\FeatureUsage`
- Interpretation
    - Only tracks GUI applications
    - Does not include timestamps
    - AppLaunch tracks data only for pinned applications, showing user knowledge of the application
        - Data persists after an application is unpinned
    - AppSwitched tracks a count of application focus, showing user interaction directed at the application
        - Not tied to pinned applications

## Amcache.hve

- Amcache tracks installed applications, programs executed (or present), drivers loaded, and more. What sets this artifact apart is it also tracks the SHA1 hash for executables and drivers. (Available in Win7+)
- Location: `C:\Windows\AppCompat\Programs\Amcache.hve`
- Interpretation
    - A complete registry hive, with multiple sub-keys
    - Full path, file size, file modification time, compilation time, and publisher metadata
    - SHA1 hash of executables and drivers
    - Amcache should be used as an indication of executable and driver presence on the system, but not to prove actual execution

## Last Visited MRU

- Last Visited MRU tracks applications in use by the user and the directory location for the last file accessed by the application.
- Location: `NTUSER.DAT\Software\Microsoft\Windows\CurrentVersion\Explorer\ComDlg32\LastVisitedMRU`
- Interpretation
    - We get two important pieces of information from this key: applications executed by the user, and the last place in the file system that those applications interacted with. Interesting and hidden directories are often identified via this registry key.

## Commands Executed in the Run Dialog

- The Run dialog allows users to execute commands without using the command prompt. This artifact tracks commands executed by the user.
- Location: `NTUSER.DAT\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU`
- Interpretation
    - MRUList key shows the order in which commands were executed
    - Commands are stored in the form of ASCII strings

## References

- [FRSecure](https://frsecure.com/blog/windows-forensics-execution/#:~:text=The%20short%20answer%20is%20a%20lot%20of%20deep,to%20extract%20meaningful%20forensic%20data%20out%20of%20them.)
- [SANS](https://www.sans.org/posters/windows-forensic-analysis/)
