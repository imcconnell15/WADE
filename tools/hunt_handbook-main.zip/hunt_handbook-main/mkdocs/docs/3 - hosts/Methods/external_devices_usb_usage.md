# External Devices and USB Usage

## USB Device Identification

Track USB devices plugged into a machine.

- Location:
    - `SYSTEM\CurrentControlSet\Enum\USBSTOR`
    - `SYSTEM\CurrentControlSet\Enum\USB`
    - `SYSTEM\CurrentControlSet\Enum\SCSI`
    - `SYSTEM\CurrentControlSet\Enum\HID`
- Interpretation:
    - Identify vendor, product, and version of a USB device plugged into a machine
    - Determine the first and last times a device was plugged into the machine
    - Devices that do not have a unique internal serial number will have an “&” in the second character of the serial number
    - The internal serial number provided in these keys may not match the serial number printed on the device
    - ParentIdPrefix links USB key to SCSI key
    - `SCSI\<ParentIdPrefix>\Device Parameters\Partmgr\DiskId matches Partition/Diagnostic` log and Windows Portable Devices key
    - Different versions of Windows store this data for different amounts of time. Windows 10/11 can store up to one year of data
        - Some older data may be present in `SYSTEM\Setup\Upgrade\PnP\CurrentControlSet\Control\DeviceMigration`
    - HID key tracks peripherals connected to the system

## Event Logs

Removable device activity can be audited in multiple Windows event logs.

- Location: (Security Log) - Win7+: `%SYSTEMROOT%\System32\winevt\logs\Security.evtx`
- Interpretation:
    - Security log events are dependent on system audit settings
        - Event IDs 20001, 20003 – Plug and Play driver install attempted
        - Event ID 6416 – A new external device was recognized on system (Security log)
        - 4663 – Attempt to access removable storage object (Security log)
        - 4656 – Failure to access removable storage object (Security log)
    - Connection Times
        - Location: Win10+: `%SYSTEM ROOT%\System32\winevt\logs\Microsoft-Windows-Partition/Diagnostic.evtx`
        - Interpretation: Event ID 1006 is recorded for each device connect/disconnect

## Drive Letter and Volume Name

Discover the last drive letter and volume name of a device when it was plugged into the system.

- Location:
    - XP:
        - Find ParentIdPrefix – `SYSTEM\CurrentControlSet\Enum\USBSTOR`
        - Using ParentIdPrefix Discover Last Mount Point – `SYSTEM\MountedDevices`
    - Win7+:
        - `SOFTWARE\Microsoft\Windows Portable Devices\Devices`
        - `SYSTEM\MountedDevices` Examine available drive letter values looking for a serial number match in value data
        - `SOFTWARE\Microsoft\Windows Search\VolumeInfoCache`
- Interpretation:
    - Only the last USB device mapped to a specific drive letter can be identified. Historical records not available.

## User Information

Identify user accounts tied to a unique USB Device.

- Location:
    - Document device Volume GUID from `SYSTEM\MountedDevices`
    - `NTUSER.DAT\Software\Microsoft\Windows\CurrentVersion\Explorer\MountPoints2`
- Interpretation: If a Volume GUID match is made within MountPoints2, we can conclude the associated user profile was logged in while that device was present.

## Connection Timestamps

Connection timestamps determine temporal usage of specific USB devices connected to a Windows Machine.

- Location First Time Plug and Play Log Files:
    - XP: `C:\Windows\setupapi.log`
    - Win7+: `C:\Windows\inf\setupapi.dev.log`
- Interpretation:
    - Search for Device Serial Number
    - Log File times are set to local time zone
- Location First, Last, and Removal Times
    - XP: `SYSTEM\CurrentControlSet\Enum\USBSTOR\Disk&Ven_&Prod_\USBSerial#\Properties\{83da6326-97a6-4088-9453-a19231573b29}\####`
    - Win7+: `SYSTEM\CurrentControlSet\Enum\USBSTOR\Disk&Ven_&Prod_\USBSerial#\Properties\{83da6326-97a6-4088-9453-a19231573b29}\####`
    - Win7+: `SYSTEM\CurrentControlSet\Enum\SCSI\Ven_Prod_Version\USBSerial#\Properties\{83da6326-97a6-4088-9453-a19231573b29}\####`
        - 0064 = First Install (Win7+)
        - 0066 = Last Connected (Win8+)
        - 0067 = Last Removal (Win8+)
- Interpretation:
    - First Install, Last Connected, and Last Removal times are stored in UTC
    - Timestamps are stored in Windows 64-bit FILETIME format
- Location Connection Times
    - Win10+: `%SYSTEM ROOT%\System32\winevt\logs\Microsoft-Windows-Partition/Diagnostic.evtx`
- Interpretation:
    - Event ID 1006 is recorded for each device connect/disconnect
    - Log cleared during major OS updates

## Volume Serial Number (VSN)

Discover the VSN assigned to the file system partition on the USB. (NOTE: This is not the USB Unique Serial Number, which is hardcoded into the device firmware, nor the serial number on any external labels attached to the device.)

- Location:
    - `SOFTWARE\Microsoft\WindowsNT\CurrentVersion\EMDMgmt`
        - Find a key match using Volume Name and USB Unique Serial Number:
        - Find last integer number in matching line
        - Convert decimal value to hex serial number
        - This key is often missing from modern systems using SSD devices
- Location Win10+: `%SYSTEM ROOT%\System32\winevt\logs\Microsoft-Windows-Partition/Diagnostic.evtx`
    - Event ID 1006 may include VBR data, which contains the VSN
    - VSN is 4 bytes located at offsets 0x43 (FAT), 0x64 (exFAT), or 0x48 (NTFS)
    within each VBR
    - Log cleared during major OS updates
- Interpretation: The VSN and device Volume Name can help correlate devices to specific files via shell items present in LNK files and registry locations.

## Shortcut (LNK) Files

Shortcut files are automatically created by Windows, tracking files and folders opened by a user.

- Location:
    - XP: `%USERPROFILE%\Recent`
    - Win7+: `%USERPROFILE%\AppData\Roaming\Microsoft\Windows\Recent\`
    - Win7+: `%USERPROFILE%\AppData\Roaming\Microsoft\Office\Recent\`

!!!note "Note" 
    These are primary locations of LNK files. They can also be found in other locations.

- Interpretation:
    - Date/Time file of that name was first opened 
        - Creation Date of Shortcut (LNK) File
    - Date/Time file of that name was last opened 
        - Last Modification Date of Shortcut (LNK) File
    - LNK Target File (Internal LNK File Information) Data:
        - Modified, Access, and Creation times of the target file 
        - Volume Information (Name, Type, Serial Number)
        - Network Share information
        - Original Location
        - Name of System