# System Information

## Operating System Version

This determines the operating system type, version, build number and installation dates for current installation and previous updates.

- Location:
    - `SOFTWARE\Microsoft\Windows NT\CurrentVersion`
    - `SYSTEM\Setup\Source OS`
- Interpretation:
    - CurrentVersion key stores:
        - ProductName, EditionID – OS type
        - DisplayVersion, ReleaseId, CurrentBuildNumber – Version info
        - InstallTime – Installation time of current build (not original installation)
    - Source OS keys are created for each historical OS update:
        - ProductName, EditionID – OS type
        - BuildBranch, ReleaseId, CurrentBuildNumber – Version info
        - InstallTime – Installation time of this build version
        - Times present in names of Source OS keys are extraneous:
            - InstallTime = 64-bit FILETIME format (Win10+)
            - InstallDate = Unix 32-bit epoch format (both times should be equivalent)

## System Boot & Autostart Programs

System Boot and Autostart Programs are lists of programs that will run on system boot or at user login.

- Location:
    - `NTUSER.DAT\Software\Microsoft\Windows\CurrentVersion\Run`
    - `NTUSER.DAT\Software\Microsoft\Windows\CurrentVersion\RunOnce`
    - `SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce`
    - `SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer\Run`
    - `SOFTWARE\Microsoft\Windows\CurrentVersion\Run`
    - `SYSTEM\CurrentControlSet\Services`
        - If Start value is set to 0x02, then service application will start at boot (0x00 for drivers)
- Interpretation:
    - Useful to find malware and to audit installed software

!!! note "Not Complete"
    This is not an exhaustive list of autorun locations

## System Last Shutdown Time

It is the last time the system was shutdown. On Windows XP, the number of shutdowns is also recorded.

- Location:
    - `SYSTEM\CurrentControlSet\Control\Windows`
    - `SYSTEM\CurrentControlSet\Control\Watchdog\Display`
        - Shutdown Count – WinXP only
- Interpretation:
    - Determining last shutdown time can help to detect user behavior and system anomalies
    - Windows 64-bit FILETIME format

## Computer Name

This stores the hostname of the system in the ComputerName value.

- Location: `SYSTEM\CurrentControlSet\Control\ComputerName\ComputerName`
- Interpretation: Hostname can facilitate correlation of log data and other artifacts.
