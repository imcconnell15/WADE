# Network Activity and Physical Location

## Network History

Identify networks to which the computer connected. Available information includes domain name/intranet name, SSID, first and last time connected, and Gateway MAC Address.

- Location:
    - `SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces`
    - `SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkCards`
    - `SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList\Signatures\Unmanaged`
    - `SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList\Signatures\Managed`
    - `SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList\Nla\Cache`
    - `SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList\Profiles`
- Interpretation:
    - Multiple registry keys can be correlated to provide a rich picture of network activity.
        - Interfaces info can be correlated with other keys via DhcpDomain value
        - Signatures and Profiles keys are correlated via the network ProfileGUID value
    - Network data includes VPN connections
    - MAC Address of SSID for Gateway can assist with device geolocation
    - Network Profile NameType values:
        - 6 (0x06) = Wired
        - 23 (0x17) = VPN
        - 71 (0x47) = Wireless
        - 243 (0xF3) = Mobile Broadband

## Browser URL Parameters

Information leaked within browser history URL parameters can provide clues to captive portal sign-ins and other similar information sources that can identify connected networks and even approximate physical locations.
Example:
<https://maps.google.com/maps?hl=en-US&gl=US&um=1&ie=UTF-> 8&fb=1&sa=X&geocode=KWv-o9E_nLJBBdixYmN41uvu&daddr=Hyat t+Place+Portland-Old+Port,+433+Fore+St,+Portland,+ME+04101

- Location: Multiple – see the history information within the Browser Usage section

## Timezone

Registry data identifies the current system time zone. Event logs may be able to provide additional historical information.

- Location:
    - `SYSTEM\CurrentControlSet\Control\TimeZoneInformation`
    - `%SYSTEMROOT%\System32\winevt\logs\System.evtx`
- Interpretation:
    - Some log files and artifact timestamps can only be correctly interpreted by knowing the system time zone
    - Event ID 6013 in the System.evtx log can provide information on historical time zone settings

## WLAN Event Log

Determine historical view of wireless networks associations.

- Location: Win7+ `Microsoft-Windows-WLAN-AutoConfig Operational.evtx`
- Interpretation:
    - Provides historical record of wireless network connections
    - SSID can be used to correlate and retrieve additional network information from Network History registry keys
    - Relevant Event IDs:
        - 11000 – Wireless network association started
        - 8001 – Successful connection to wireless network
        - 8002 – Failed connection to wireless network
        - 8003 – Disconnect from wireless network
        - 6100 – Network diagnostics (System log)

## System Resource Usage Monitor (SRUM)

SRUM records 30 to 60 days of historical system performance including applications run, user accounts responsible, network connections, and bytes sent/received per application per hour.

- Location:
    - Win7: `C:\Windows\System32\sru\SRUDB.dat`
    - Win8+: `C:\Windows\System32\SRU\SRUDB.dat`
- Interpretation:
    - SRUDB.dat is an Extensible Storage Engine database
    - Three tables in SRUDB.dat are particularly important:
        - `{973F5D5C-1D90-4944-BE8E-24B94231A174}` = Network Data Usage
        - `{d10ca2fe-6fcf-4f6d-848e-b2e99266fa89}` = Application Resource Usage
        - `{DD6636C4-8929-4683-974E-22C046A43763}` = Network Connectivity Usage
    - Records data approx. once per hour, in batches

## Network Interfaces

List available network interfaces and their last known configurations.

- Location:
    - `SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces`
    - `SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkCards`
- Interpretation:
    - Interfaces key includes the last known IP address, DHCP and domain information for both physical and virtual network adapters. Subkeys may be present containing historical network data
    - NetworkCards key can provide more detail on network availability
    - The two keys are mapped via the interface GUID value
    - Unlikely to be a complete view of every connected network
