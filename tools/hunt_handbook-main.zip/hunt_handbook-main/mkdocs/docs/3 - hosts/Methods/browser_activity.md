# Browser Activity

## History and Download History

History and Download History records websites visited by date and time.

- Location:
    - Firefox
        - XP: `%USERPROFILE%\Application Data\Mozilla\Firefox\Profiles\<randomtext>.default\history.dat`
        - Win7+: `%USERPROFILE%\AppData\Roaming\Mozilla\Firefox\Profiles\<randomtext>.default\places.sqlite`
    - Chrome/Edge
        - XP: `%USERPROFILE%\Local Settings\Application Data\Google\Chrome\User Data\<Profile>\History`
        - Win7+: `%USERPROFILE%\AppData\Local\Google\Chrome\User Data\<Profile>\History`
        - Win7+: `%USERPROFILE%\AppData\Local\Microsoft\Edge\User Data\<Profile>\History`
- Interpretation:
    - Web browser artifacts are stored for each local user account
    - Most browsers also record number of times visited (frequency)
    - Look for multiple profiles in Chromium browsers, including “Default”, and
    “Profile1”, etc.

## Media History

Media History tracks media usage (audio and video played) on visited websites (Chromium browsers).

- Location
    - Chrome/Edge
        - `%USERPROFILE%\AppData\Local\Google\Chrome\User Data\<Profile>\Media History`
        - `%USERPROFILE%\AppData\Local\Microsoft\Edge\User Data\<Profile>\Media History`
- Interpretation
    - Three primary tables: playbackSession, origin, playback
    - Includes URLs, last play time, watch time duration, and last video position
    - Not cleared when other history data is cleared

## HTML5 Web Storage

HTML5 Web Storage are considered to be “Super Cookies”. Each domain can store up to 10MB of text-based data on the local system.

- Location
    - Firefox
        - `%USERPROFILE%\AppData\Roaming\Mozilla\Firefox\Profiles\<randomtext>.default\webappsstore.sqlite`
    - Chrome/Edge
        - `%USERPROFILE%\AppData\Local\Google\Chrome\User Data\<Profile>\Local Storage`
        - `%USERPROFILE%\AppData\Local\Microsoft\Edge\User Data\<Profile>\Local Storage`
- Interpretation: Chrome uses a LevelDB database, Firefox uses SQLite, and IE/EdgeHTML store data within XML files. Each domain can store up to 10MB of text-based data on the local system. Data is stored in key-value pairs. Data can be stored in plaintext.

## HTML5 FileSystem

HTML5 FileSystem implements the HTML5 local storage FileSystem API. It is similar to Web Storage, but designed to store larger binary data.

- Location
    - Chrome/Edge
        - `%USERPROFILE%\AppData\Local\Google\Chrome\User Data\<Profile>\File System`
        - `%USERPROFILE%\AppData\Local\Microsoft\Edge\User Data\<Profile>\File System`
- Interpretation
    - A LevelDB database in this folder stores visited URLs and assigned subfolders to locate the data
    - Files are stored temporarily (“t” subfolders) or in permanent (“p” subfolders) storage

## Auto-Complete Data

Many databases store data that a user has typed into the browser.

- Location
    - Firefox
        - `%USERPROFILE%\AppData\Roaming\Mozilla\Firefox\Profiles\<randomtext>.default\formhistory.sqlite`
        - `%USERPROFILE%\AppData\Roaming\Mozilla\Firefox\Profiles\<randomtext>.default\places.sqlite`
    - Chrome/Edge
        - `%USERPROFILE%\AppData\Local\Google\Chrome\User Data\<Profile>\History`
        - `%USERPROFILE%\AppData\Local\Microsoft\Edge\User Data\<Profile>\History`
            - keyword_search_terms – items typed into various search engines
        - `%USERPROFILE%\AppData\Local\Google\Chrome\User Data\<Profile>\Web Data`
        - `%USERPROFILE%\AppData\Local\Microsoft\Edge\User Data\<Profile>\Web Data`
            - autofill – items typed into web forms
        - `%USERPROFILE%\AppData\Local\Google\Chrome\User Data\<Profile>\Shortcuts`
        - `%USERPROFILE%\AppData\Local\Microsoft\Edge\User Data\<Profile>\Shortcuts`
            - keyword_search_terms – items typed into the Chrome URL address bar (Omnibox)
        - `%USERPROFILE%\AppData\Local\Google\Chrome\User Data\<Profile>\Network Action Predictor`
        - `%USERPROFILE%\AppData\Local\Microsoft\Edge\User Data\<Profile>\ Network Action Predictor`
            - Records what was typed, letter by letter
        - `%USERPROFILE%\AppData\Local\Google\Chrome\User Data\<Profile>\Login Data`
        - `%USERPROFILE%\AppData\Local\Microsoft\Edge\User Data\<Profile>\ Login Data`
            - Stores inputted user credentials
- Interpretation
    - Includes typed-in data, as well as data types
    - Connects typed data and knowledge to a user account

## Browser Preferences

Configuration data associated with the browser application, including privacy settings and synchronization preferences.

- Location
    - Firefox
        - `%USERPROFILE%\AppData\Roaming\Mozilla\Firefox\Profiles\<randomtext>.default\prefs.js`
    - Chrome/Edge
        - `%USERPROFILE%\AppData\Local\Google\Chrome\User Data\<Profile>\Preferences`
        - `%USERPROFILE%\AppData\Local\Microsoft\Edge\User Data\<Profile>\Preferences`
- Interpretation
    - Firefox prefs.js shows sync status, last sync time, and artifacts selected to sync
    - Chrome uses JSON format
        - per_host_zoom_levels, media-engagement, and site_engagement can help to show user interaction
        - Contains synchronization status, last sync time and artifacts selected to sync
    - Edge preferences include account_info, clear_data_on_exit, and sync settings

## Cache

The cache is where web page components can be stored locally to speed up subsequent visits.

- Location
    - Firefox - XP: `%USERPROFILE%\Application Data\Mozilla\Firefox\Profiles\<randomtext>.default\Cache`
    - Firefox 31 - Win7+: `%USERPROFILE%\AppData\Local\Mozilla\Firefox\Profiles\<randomtext>.default\Cache`
    - Firefox 32+ - Win7+: `%USERPROFILE%\AppData\Local\Mozilla\Firefox\Profiles\<randomtext>.default\cache2`
    - Chrome/Edge
        - XP: `%USERPROFILE%\Local Settings\Application Data\Google\Chrome\User Data\<Profile>\Cache - data_# and f_######`
        - Win7+: `%USERPROFILE%\AppData\Local\Google\Chrome\User Data\<Profile>\Cache\ - data_# and f_######`
        - Win7+: `%USERPROFILE%\AppData\Local\Microsoft\Edge\User Data\<Profile>\Cache\ - data_# and f_######`
- Interpretation
    - Gives the investigator a “snapshot in time” of what a user was looking at online
    - Identifies websites which were visited
    - Provides the actual files the user viewed on a given website
    - Similar to all browser artifacts, cached files are tied to a specific local user account
    - Timestamps show when the site was first saved and last viewed

## Bookmarks

Bookmarks include default items, as well as those the user chose to save for future reference.

- Location:
    - Firefox 3+
        - `%USERPROFILE%\AppData\Roaming\Mozilla\Firefox\Profiles\<randomtext>.default\places.sqlite`
        - `%USERPROFILE%\AppData\Roaming\Mozilla\Firefox\Profiles\<randomtext>.default\bookmarkbackups\bookmarks-<date>.jsonlz4`
    - Chrome/Edge
        - `%USERPROFILE%\AppData\Local\Google\Chrome\User Data\<Profile>\Bookmarks`
        - `%USERPROFILE%\AppData\Local\Microsoft\Edge\User Data\<Profile>\Bookmarks`
        - `%USERPROFILE%\AppData\Local\Google\Chrome\User Data\<Profile>\Bookmarks.bak`
        - `%USERPROFILE%\AppData\Local\Microsoft\Edge\User Data\<Profile>\Bookmarks.msbak`
- Interpretation
    - Firefox stores bookmarks in a SQLite database
        - moz_bookmarks table contains the bookmark hierarchy
        - moz_places table contains the bookmarked URLs
        - moz_bookmarks_roots table contains the default bookmarks
    - Chromium-based browsers store bookmarks in a JSON file
        - The bookmarks file is a JSON object with a single key named roots
        - The roots key contains a JSON object with keys for each bookmark folder
        - Each folder key contains a JSON object with keys for each bookmark
        - Each bookmark key contains a JSON object with keys for the bookmark URL and title
    - Provides the website of interest and the specific URL that was saved
    - Firefox bookmark backups folder can contain multiple backup copies of
    bookmarks in JSON format. Field names match those in places.sqlite
    - Chromium Bookmark files are in JSON format
    - Note: not all bookmarks are user-generated; it is possible to bookmark a site and never visit it

## Stored Credentials

Browser-based credential storage typically uses Windows DPAPI encryption. If the login account is a Microsoft cloud account in Windows 10 or 11, DPAPI uses a 44-character randomly generated password in lieu of the account password.

- Location:
    - Firefox
        - `%USERPROFILE%\AppData\Roaming\Mozilla\Firefox\Profiles\logins.json`
    - Chrome/Edge
        - `%USERPROFILE%\AppData\Local\Google\Chrome\User Data\<Profile>\Login Data`
        - `%USERPROFILE%\AppData\Local\Microsoft\Edge\User Data\<Profile>\Login Data`
- Interpretation:
    - Firefox stores the hostname and URL, creation time, last used time, times used, and time of last password change in JSON format.
    - Chromium-based browsers use a SQLite database and include the origin URL, action URL, username, date created, and date last used.
    - Credential metadata can be available even if actual credentials are encrypted. Actual credentials are easiest to retrieve on a live system with the user account logged in.

## Browser Downloads

Modern browsers include built-in download manager applications capable of keeping a history of every file downloaded by the user. This browser artifact can provide excellent information about websites visited and corresponding items downloaded.

- Location
    - Firefox 3-25: `%USERPROFILE%\AppData\Roaming\Mozilla\Firefox\Profiles\<random text>.default\downloads.sqlite`
    - Firefox 26+: `%USERPROFILE%\AppData\Roaming\Mozilla\Firefox\Profiles\<random text>.default\places.sqlite`
        - moz_annos table
    - Chrome/Edge
        - `%USERPROFILE%\AppData\Local\Google\Chrome\User Data\<Profile>\History`
        - `%USERPROFILE%\AppData\Local\Microsoft\Edge\User Data\<Profile>\History`
        - downloads and download_url_chains tables
- Interpretation
    - Download metadata includes:
        - Filename, size, and type
        - Source website and referring page
        - Download start and end times
        - File system save location
        - State information including success and failure

## Extensions

Browser functionality can be extended through the use of extensions, or browser plugins.

- Location
    - Firefox 4-25
        - `%USERPROFILE%\AppData\Roaming\Mozilla\Firefox\Profiles\<randomtext>.default\extensions.sqlite`
        - `%USERPROFILE%\AppData\Roaming\Mozilla\Firefox\Profiles\<randomtext>.default\addons.sqlite`
    - Firefox 26+
        - `%USERPROFILE%\AppData\Roaming\Mozilla\Firefox\Profiles\<randomtext>.default\addons.json`
    - Chrome/Edge
        - `%USERPROFILE%\AppData\Local\Google\Chrome\User Data\<Profile>\Extensions\<GUID>\<version>`
        - `%USERPROFILE%\AppData\Local\Microsoft\Edge\User Data\<Profile>\Extensions\<GUID>\<version>`
- Interpretation
    - The newer Firefox JSON format stores more information than in older versions
    - Extension name, installation source, installation time, last update, and plugin status
    - Chrome/Edge extensions each have their own folder on the local system, named with a GUID, containing the code and metadata
    - Creation time of the folder indicates the installation time for the extension. Beware that extensions can be synced across devices affecting the interpretation of this timestamp.
    - A manifest.json file provides plugin details including name, URL, permissions, and version.
    - The preferences file can also include additional extension data

## Session Restore

Automatic crash recovery features are built into the browser.

- Location
    - Firefox (older versions)
        - `%USERPROFILE%\AppData\Roaming\Mozilla\Firefox\Profiles\<randomtext>.default\sessionstore.js`
    - Firefox (newer versions)
        - `%USERPROFILE%\AppData\Roaming\Mozilla\Firefox\Profiles\<randomtext>.default\sessionstore.jsonlz4`
        - `%USERPROFILE%\AppData\Roaming\Mozilla\Firefox\Profiles\<randomtext>.default\sessionstore-backups\`
    - Chrome/Edge (older versions)
        - `%USERPROFILE%\AppData\Local\Google\Chrome\User Data\<Profile>\`
        - `%USERPROFILE%\AppData\Local\Microsoft\Edge\User Data\<Profile>\`
        - Restore files = Current Session, Current Tabs, Last Session, Last Tabs
    - Chrome/Edge (newer versions)
        - `%USERPROFILE%\AppData\Local\Google\Chrome\User Data\<Profile>\Sessions`
        - `%USERPROFILE%\AppData\Local\Microsoft\Edge\User Data\<Profile>\Sessions`
        - Restore files = Session_<timestamp>, Tabs_<timestamp>
- Interpretation
    - Historical websites viewed in each tab
    - Referring websites
    - Time session started or ended
    - HTML, JavaScript, XML, and form data from the page
    - Other artifacts such as transition type, browser window size and pinned tabs

## Cookies

Cookies provide insight into what websites have been visited and what activities might have taken place there.

- Location
    - Firefox
        - XP: `%USERPROFILE%\Application Data\Mozilla\Firefox\Profiles\<randomtext>.default\cookies.sqlite`
        - Win7+: `%USERPROFILE%\AppData\Roaming\Mozilla\Firefox\Profiles\<randomtext>.default\cookies.sqlite`
    - Chrome/Edge
        - XP: `%USERPROFILE%\Local Settings\Application Data\Google\Chrome\User Data\<Profile>\Cookies`
        - Win7+: `%USERPROFILE%\AppData\Local\Google\Chrome\User Data\<Profile>\Network\Cookies`
        - Win7+: `%USERPROFILE%\AppData\Local\Microsoft\Edge\User Data\<Profile>\Network\Cookies`
