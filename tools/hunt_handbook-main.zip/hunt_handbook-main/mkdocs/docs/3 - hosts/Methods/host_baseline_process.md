# Host Baseline and Analysis Process V0.2.0

## Preparation

1. Identify the host analysis tools to be used and download the offline installers.
*Image analysis tools*

    - Autopsy
    - FTK Imager
    *Memory Analysis Tools*
    - Volatility
    - RamCapturer
    *Utility*
    - Sysinternals Suite
    - Cyberchef

2. Acquire the correct version of documentation for the relevant tools.

    - This may not be necessary for some tools as they come with their documentation built-in.

3. Acquire relevant cheat-sheets, references, and ebooks.

    - SANS Posters are great resources, which can be acquired from the official SANS website.

4. Transfer data to transferrable media for upload to kit. ex. CD, USB, Secure Drive (Be wary of guidelines regarding classified data and systems)

    - Have backups of this data available for use on mission.

## On Mission

!!! success "Document!"
    DOCUMENT YOUR ANALYSIS :smile:
    

- Create a directory to store personal notes, and a directory to consolidate analyst notes for analyzed systems.
- Create a datashare for backups of forensic images.

### Host baselining & analysis process

1. Acquire situational awareness

    - Gather information about the environment and system being analyzed.  Identify any discrepancies found.

2. Document user accounts purpose and typical usage.

    - Review any information known about the network and systems, and information provided by the customer.
    - View user account description
    - View commonly used directories (Desktop, Documents, Downloads)
    - Identify commonly used/accessed files and applications
    - Reference SANS FOR500 Poster 'Account Usage' section.

3. Proceed with analysis

    - *Below is a general guide for order of analysis on Windows systems.*

    1. System Information
        - Refer to the [Operating System Version](./system_information.md#operating-system-version) section of  **System Information** for OS information.
        - Refer to the [Computer Name](./system_information.md#computer-name) section of **System Information** for the Computer Name.
    2. Network Information & Physical Location Information
        - Refer to the [Network Activity & Physical Location](./network_activity.md) sections to find interfaces, IPs, and timezone information.
    3. Autostart Locations
        - Group Policy
            - Location to view GPO: `%windir%\System32\GroupPolicy\...` There will be folders that label the different groups on that system. Traverse through them to find the **Policies** folder.
        - Run keys
            - Refer to the [System Boot & Autostart Programs](./system_information.md#system-boot--autostart-programs) of the **System Information** for locations of system registry run keys.
    4. Account Information
        - [Account Usage]( ./account_usage.md#account-usage) information
        - [Authentication Events]( ./account_usage.md#authentication-events)
        - [Cloud Account Details]( ./account_usage.md#cloud-account-details)
        - [Last logon and password change]( ./account_usage.md#last-login-and-password-change)
        - [Different Logon Types]( ./account_usage.md#logon-event-types)
        - [Remote Desktop Usage]( ./account_usage.md#remote-desktop-protocol-rdp-usage)
        - [Successful or Failed Logons]( ./account_usage.md#successfulfailed-logons)
        - [User Accounts]( ./account_usage.md#user-accounts)
    5. External Devices and USB Connections/History
        - Refer to the [USB Device Identification](./external_devices_usb_usage.md#usb-device-identification) section of the **External Device/USB Usage** for current and previous USB connections.
            - Refer to [Event Logs](./external_devices_usb_usage.md#event-logs) section of **External Device/USB Usage** and review the event viewer logs for USB connections, focus on 4663, 4656, and 6416 logs when conducting analysis.
    6. Services
        - Refer to [Service Events]( ./account_usage.md#service-events) in the section of **Account Usage** for the location (depending on OS version) to view service events. Focus on 7034, 7035, 7036, 7040, 7045, and 4697 logs when conducting analysis.
        - Also, Autopsy utilizes a module that enumerates the services on a host machine, which can provide useful information on current services.
    7. Browser Activity
        - Investigate the numerous types of data available from [Browser Activity](./browser_activity.md).
    8. Files
        - [File and Folder Opening]( ./file_folder_opening.md) information
        - [Deleted Files]( ./deleted_files_existence.md)
            - Refer to **Recycle Bin** in the [Deleted Files]( ./deleted_files_existence.md#recycle-bin) for location of recently deleted files.
            - Autopsy does an amazing job of carving deleted files from a host machine. Refer to the **Deleted Files** section in Autopsy.
        - Different locations for recent file access in the [Deleted Files Existence]( ./deleted_files_existence.md) document.
            - Autopsy has a **Recent File** section to observe files recently accessed.
        - Obfuscated Files
            - Utilize PowerShell to view alternate data streams and Autopsy to view automatically highlighted files.
            - Utilize the **Hashlist** function in Autopsy to run team IOC list against all files on system.
    9. Application
        - Refer to the [Application Execution Discovery]( ./application_execution_discovery.md) for methods to view numerous types of different application activity.

!!! note "**NOTE**:"
    Checklist will vary based on systems, sites, and customer preference.

#### Conducting Log Analysis

Windows Log Analysis

- Background Information of Event Logs
    - In a windows 10 environment, logs are stored by default in `%System32%\winevt\Logs` (Event logs in XP were found at `%Windows%System32/config/*.evt`)
    - Event logs provide details about: the date and time, source, fault type, and a Unique ID for the event type
- The three main event logs are: System, Security, and Application
    - System logs contain data about hardware changes, device drivers, system changes, and all activities related to the machine to include when the machine was last updated
    - Security logs contain Logon/Logoff activity as well as other activities related to windows security and is the best option to detect and investigate attempted and/or successful unauthorized activity in logs
    - Application logs contain the errors that occur in an application, informational events, and warnings from the software that we can use to troubleshoot any software problem that prevent them from either logging in or functioning properly
- 2 examples of tools that can be used to parse event logs, which are stored in a binary XML format, include:
    - LogParser
    - Event Log Explorer

- Logs of Interest
    - Event ID's vary depending on the windows version so one of the first things that needs to be done is to verify the OS (Windows XP, Windows 7, Windows 10, Windows Server, etc.)
    - For specific Event IDs that may be of interest, refer to the SANS FOR500 poster under and look at the account usage section (Not an exhaustive list but for more event IDs, refer to the Microsoft documentation of event IDs and their descriptions)

Linux Log Analysis

- Information on Linux logs
    - On a linux system, log files are stored by default in `/var/log`
    - There are many different log files in Linux but a few of the most important log files are: `/var/log/syslog`, `/var/log/messages`, `/var/log/auth.log`, `/var/log/secure`, `/var/log/kern.log`, and `/var/log/cron`
    - `/var/log/syslog` and `/var/log/messages` store all global system activity data, including startup messages. Debian-based systems like Ubuntu store this in `/var/log/syslog`, while Red Hat-based systems like CentOS use `/var/log/messages`
    - `/var/log/auth.log` and `/var/log/secure` store all security-related events such as logins, root user actions, and output from pluggable authentication modules (PAM). Ubuntu and Debian use `/var/log/auth.log`, while Red Hat uses `/var/log/secure`
    - `/var/log/kern.log` stores kernel events, errors, and warning logs, which are particularly helpful for troubleshooting
    - `/var/log/cron` stores information about scheduled tasks (cron jobs). Use this data to verify your cron jobs
