# File and Folder opening

## Operating System

### Open/Save MRU

In the simplest terms, this key tracks files that have been opened or saved within a Windows shell dialog box. This happens to be a big data set, including Microsoft Office applications, web browsers, chat clients, and a majority of commonly used applications.

- Location:
    - XP: `NTUSER.DAT\Software\Microsoft\Windows\CurrentVersion\Explorer\ComDlg32\OpenSaveMRU`
    - Win7/8/10: `NTUSER.DAT\Software\Microsoft\Windows\CurrentVersion\Explorer\ComDlg32\OpenSavePIDlMRU`
- Interpretation:
    - The “*” key – This subkey tracks the most recent files of any extension input in an OpenSave dialog
    - .??? (Three letter extension) – This subkey stores file info from the OpenSave dialog by specific extension type. The most recently used (MRU) item is associated with the last write time of the key, providing one timestamp of file opening for each file extension type.

### Recent Files

Registry key tracking the last files and folders opened. Used to populate data in places like the “Recent” menus present in some Start menus.

- Location: `NTUSER.DAT\Software\Microsoft\Windows\CurrentVersion\Explorer\RecentDocs`
- Interpretation:
    - RecentDocs – Rollup key tracking the overall order of the last 150 files or folders opened. MRU list tracks the temporal order in which each file/ folder was opened.
    - .??? – These subkeys store the last 20 files opened by the user of each extension type. MRU list tracks the temporal order in which each file was opened. The most recently used (MRU) item is associated with the last write time of the key, providing one timestamp of file opening for each file extension type.
    - Folder – This subkey stores the last 30 folders opened by the user. The most recently used (MRU) item in this key is associated with the last write time of the key, providing the time of opening for that folder.

### Shortcut (LNK) Files

Shortcut files are automatically created by Windows, tracking files and folders opened by a user.

- Location:
    - XP: `%USERPROFILE%\Recent`
    - Win7+: `%USERPROFILE%\AppData\Roaming\Microsoft\Windows\Recent\`
    - Win7+: `%USERPROFILE%\AppData\Roaming\Microsoft\Office\Recent\`
- Interpretation:
    - Date/Time file of that name was first opened - Creation Date of Shortcut (LNK) File
    - Date/Time file of that name was last opened - Last Modification Date of Shortcut (LNK) File
    - LNK Target File (Internal LNK File Information) Data:
        - Modified, Access, and Creation times of the target file
        - Volume Information (Name, Type, Serial Number)
        - Network Share information
        - Original Location
        - Name of System

### Jump Lists

Windows Jump Lists allow user access to frequently or recently used items quickly via the task bar. First introduced in Windows 7, they can identify applications in use and a wealth of metadata about items accessed via those applications.

- Location:
    - `%USERPROFILE%\AppData\Roaming\Microsoft\Windows\Recent\AutomaticDestinations`
    - `%USERPROFILE%\AppData\Roaming\Microsoft\Windows\Recent\CustomDestinations`
- Interpretation:
    - Each jump list file is named according to an application identifier (AppID).
    - Each Jump List contains a collection of items interacted with (up to ~2000 items per application)
    - Each entry is represented as a LNK shell item providing additional data
        - Target Timestamps
        - File Size
        - Local Drive | Removable Media | Network Share Info
        - Entries kept in MRU order including a timestamp for each item

### Last Visited MRU

Tracks applications in use by the user and the directory location for the last file accessed by the application.

- Location:
    - XP: `NTUSER.DAT\Software\Microsoft\Windows\CurrentVersion\Explorer\ComDlg32\LastVisitedMRU`
    - Win7+: `NTUSER.DAT\Software\Microsoft\Windows\CurrentVersion\Explorer\ComDlg32\`
- Interpretation:
    - We get two important pieces of information from this key: applications executed by the user and the last place in the file system that those applications interacted with. Interesting and hidden directories are often identified via this registry key.

### Shell Bags

Shell bags identifies which folders were accessed on the local machine, via the network, and on removable devices, per user. It also shows evidence of previously existing folders still present after deletion/overwrite.

- Location:
    - Primary Data:
        - `USRCLASS.DAT\Local Settings\Software\Microsoft\Windows\Shell\Bags`
        - `USRCLASS.DAT\Local Settings\Software\Microsoft\Windows\Shell\BagMRU`
    - Residual Desktop Items and Network Shares:
        - `NTUSER.DAT\Software\Microsoft\Windows\Shell\BagMRU`
        - `NTUSER.DAT\Software\Microsoft\Windows\Shell\Bags`
- Interpretation:
    - Massive collection of data on folders accessed by each user
    - Folder file system timestamps are archived in addition to first and last interaction times
    - “Exotic” items recorded like mobile device info, control panel access, and Zip archive access

### Internet Explorer file:///

Internet Explorer History databases have long held information on local and remote file access (via network shares), giving us an excellent means for determining files accessed on the system, per user. Information can be present even on Win11+ systems missing the Internet Explorer application.

- Location:
    - IE6–7: `%USERPROFILE%\LocalSettings\History\History.IE5`
    - IE8–9: `%USERPROFILE%\AppData\Local\Microsoft\Windows\History\History.IE5`
    - IE10–11 & Win10+: `%USERPROFILE%\AppData\Local\Microsoft\Windows\WebCache\WebCacheV*.dat`
- Interpretation:
    - Entries recorded as: `file:///C:/directory/filename.ext`
    - Does not mean file was opened in a browser, only that the file was accessed by the browser

## MS Office Applications

### Office Recent Files

MS Office programs track their own recent files list, to make it easier for users to access previously opened files.

- Location:
    - `NTUSER.DAT\Software\Microsoft\Office\<Version>\<AppName>\File MRU`
        - 16.0 = Office 2016/2019/M365
        - 15.0 = Office 2013
        - 14.0 = Office 2010
        - 12.0 = Office 2007
        - 11.0 = Office 2003
        - 10.0 = Office XP
    - `NTUSER.DAT\Software\Microsoft\Office\<Version>\<AppName>\User MRU\LiveId_####\File MRU` - Microsoft 365
    - `NTUSER.DAT\Software\Microsoft\Office\<Version>\<AppName>\User MRU\AD_####\File MRU` - Microsoft 365 (Azure Active Directory)
- Interpretation:
    - Similar to the Recent Files registry key, this tracks the last files opened by each MS Office application
    - Unlike the Recent Files registry key, full path information is recorded along with a last opened time for each entry

### MS Word Reading Locations

Beginning with Word 2013, the last known position of the user within a Word document is recorded.

- Location:
    - `NTUSER\Software\Microsoft\Office\<Version>\Word\Reading Locations`
- Interpretation:
    - Another source tracking recent documents opened
    - The last closed time is also tracked along with the last position within the file
    - Together with the last opened date in the Office File MRU key, a last session duration can be determined

### Office Trust Records

Records trust relationships afforded to documents by a user when presented with a security warning. This is stored so the user is only required to grant permission the first time the document is opened.

- Location: `NTUSER\Software\Microsoft\Office\<Version>\<AppName>\Security\Trusted Documents\TrustRecords`
- Interpretation:
    - Can identify documents opened by the user and user interaction in trusting the file
    - Records file path, time the document was trusted, and which permissions were granted

### Office OAlerts

MS Office programs produce alerts for the user when they attempt actions such as closing a file without saving it first.

- Location: `NTUSER\Software\Microsoft\Office\<Version>\<AppName>\OAlerts\OAlerts.evtx`
- Interpretation:
    - All Office applications use Event ID 300
    - Events include the program name and dialog message, showing some user activity within the application
