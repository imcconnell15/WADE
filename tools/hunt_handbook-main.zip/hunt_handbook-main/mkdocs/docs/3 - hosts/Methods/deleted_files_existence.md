# Deleted Items and File Existence

## Thumbs.db

The hidden database file is created in directories where images were viewed as thumbnails. It can catalog previous contents of a folder even upon file deletion.

- Location: Each folder maintains a separate Thumbs.db file after being viewed in thumbnail view (OS version dependent)
- Includes:
    - Thumbnail image of original picture
    - Last Modification Time (XP Only)
    - Original Filename (XP Only)
    - Most relevant for XP systems, but Thumbs.db files can be created on more modern OS versions in unusual circumstances such as when folders are viewed via UNC paths.

## Thumbcache

Thumbnails of pictures, documents, and folders exist in a set of databases called the thumbcache. It is maintained for each user based on the thumbnail sizes viewed (e.g., small, medium, large, and extra large). It can catalog previous contents of a folder even upon file deletion. (Available in Windows Vista+)

- Location: `%USERPROFILE%\AppData\Local\Microsoft\Windows\Explorer`
- Interpretation:
    - Database files are named similar to: `Thumbcache_256.db`
    - Each database file represents thumbnails stored as different sizes or to fit different user interface components
    - Thumbnail copies of pictures can be extracted and the Thumbnail Cache ID can be cross-referenced within the Windows Search Database to identify filename, path, and additional file metadata
    - The hidden database file is created in directories where images were viewed as thumbnails. It can catalog previous contents of a folder even upon file deletion.

## Windows Search Database

Windows Search indexes more than 900 file types, including email and file metadata, allowing users to search based on keywords.

- Location:
    - Win XP: `C:\Documents and Settings\All Users\Application Data\ Microsoft\Search\Data\ Applications\Windows\Windows.edb`
    - Win7+: `C:\ProgramData\Microsoft\Search\Data\Applications\Windows\Windows.edb`
    - Win7+: `C:\ProgramData\Microsoft\Search\Data\Applications\Windows\GatherLogs\SystemIndex\`
- Interpretation:
    - Database in Extensible Storage Engine format
    - Gather logs contain a candidate list for files to be indexed over each 24 hour period
    - Extensive file metadata and even partial content can be present

## Search - WordWheelQuery

This maintains an ordered list of terms put into the File Explorer search dialog.

- Location: Win7+: `NTUSER.DAT\Software\Microsoft\Windows\CurrentVersion\Explorer\WordWheelQuery`
- Interpretation: Keywords are added in Unicode and listed in temporal order in an MRUlist

## User Typed Paths

A user can type a path directly into the File Explorer path bar to locate a file instead of navigating the folder structure. Folders accessed in this manner are recorded in the TypedPaths key.

- Location: `NTUSER.DAT\Software\Microsoft\Windows\CurrentVersion\Explorer\TypedPaths`
- Interpretation:
    - Each entry is a path typed by the user
    - Each entry is associated with a timestamp
    - Each entry is associated with a volume serial number
    - This indicates a user had knowledge of a particular file system location
    - It can expose hidden and commonly accessed locations, including those present on external drives or network shares

## Internet Explorer file:///

Internet Explorer History databases have long held information on local and remote (via network shares) file access, giving us an excellent means for determining files accessed on the system, per user. Information can be present even on Win11+ systems missing the Internet Explorer application.

- Location:
    - IE6–7: `%USERPROFILE%\LocalSettings\History\History.IE5`
    - IE8–9: `%USERPROFILE%\AppData\Local\Microsoft\Windows\History\History.IE5`
    - IE10–11 & Win10+: `%USERPROFILE%\AppData\Local\Microsoft\Windows\WebCache\WebCacheV*.dat`
- Interpretation:
    - Entries recorded as: `file:///C:/directory/filename.ext`
    - Does not mean file was opened in a browser, only that the file was accessed by the browser

## Recycle Bin

The recycle bin collects items soft-deleted by each user and associated metadata—only relevant for recycle-bin aware applications.

- Location: (Hidden System Folder)
    - Win XP: `C:\Recycler`
    - Win7+: `C:\$Recycle.Bin`
- Interpretation:
    - Each user is assigned a SID sub-folder that can be mapped to a user via the Registry
    - XP: INFO2 database contains deletion times and original filenames
    - Win7+: Files preceded by `$I######` contain original filename and deletion date/time
    - Win7+: Files preceded by `$R######` contain original deleted file contents
