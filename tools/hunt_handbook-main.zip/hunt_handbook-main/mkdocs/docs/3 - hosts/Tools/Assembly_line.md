# Assmebly Line

- After installation under `Administration\Services` change the defaults for the timeouts to allow Assembly Line to process large files.