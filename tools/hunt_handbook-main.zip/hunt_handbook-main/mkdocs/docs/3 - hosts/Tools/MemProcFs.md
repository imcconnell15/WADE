# MemProcFS Installation

- Download the latest version of [MemProcFS zip from Github](https://github.com/ufrisk/MemProcFS/releases/).
- Download the latest version of [Dokany from Github](https://github.com/dokan-dev/dokany/releases/tag/v2.0.6.1000)
- Ensure that the Dokany is in the same directory of the extracted Zip.
- Navigate to where Memproc directory where the executable lives.
- Running the below common
    - `.\MemProcFS.exe -device <path to memory\ram38.dmp> -forensic 1`
- You should now see a mounted file system under this PC, likely M:
- Some useful information is within the sys directory
    - tasks, users, proc, services, net, drivers
    - There are also text documents with useful computer information
