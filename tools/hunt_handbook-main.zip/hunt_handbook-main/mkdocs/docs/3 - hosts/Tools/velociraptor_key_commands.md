## Useful Commands to run via Velociraptor Command Line
- `netstat -ano`
- `tasklist`
- `Get-MpComputerStatus`
- `Get-ExecutionPolicy -List`
- `sc queryex`

## Useful Hunts
- `Windows.Detections.Mutants` - Mutant is a kernel object which allows programs to synchronize events between them. Malware often uses a named Mutant to ensure it does not re-infect the same machine and only run a single copy of the malware.
- `Windows.System.Powershell.PSReadline` - This Artifact will search and extract lines from PSReadline history file
- `Windows.Network.Netstat` - This will show network connections and listening ports.
- `Windows.System.TaskScheduler` - This artifact enumerates all the task jobs, which could be used by an attacker for persistence.
- `Windows.Detection.Yara.NTFS` - Hunt for specific APTs using YARA. This artifact searches the MFT, returns a list of target files then runs Yara over the target list
- `Windows.Applications.TeamViewer.Incoming` - Parses the TeamViewer Connections_incoming.txt log file, which could reveal unknown TeamViewer connections.
- `Windows.Registry.HiddenUsers` - Find hidden user accounts through registry values on the filesystem that may not be seen through normal analysis.
- `Generic.System.Pstree` - This artifact displays the call chain for every process on the system by traversing the process’s parent ID.
- `Windows.Packs.Persistence` - This artifact pack collects various persistence mechanisms in Windows in locations typically used by attackers.
- `Windows.Packs.LateralMovement` - Checks for signs of lateral movement.
- `Windows.System.UntrustedBinaries` - This artifact checks that the common systems binaries are signed. If a malware replaces these files or names itself in this way their signature might not be correct.

## Alternate data streams
- Search for Alternate Data Stream (Velciraptor)
- Run a commmand from the powershell console, if powershell does not work run from command line starting with "powershell.exe <command>
- Get-Item * -Stream *
- this will identify any sort of alternate data streams that exist on the computer