# Velociraptor Setup

- Get the latest release: `wget https://github.com/Velocidex/velociraptor/releases/download/v0.6.8-2/velociraptor-v0.6.8-2-linux-amd64`
- change the file to an executable: `chmod +x ./velociraptor-v0.6.8-2-linux-amd64`
- move the executable to `/usr/sbin` which is a better place to run a service from: `mv ./velociraptor-v0.6.8-2-linux-amd64 /usr/sbin`
- generate the basic config: `/usr/sbin/velociraptor-v0.6.8-2-linux-amd64 config generate > velociraptor.config.yaml`
- Edit the configuration that was generated and change all instances of `localhost` & `127.0.0.1` - to the IP address of the servers - making the services accessible from other machines
- Add an initial user: `/usr/sbin/velociraptor-v0.6.8-2-linux-amd64 user add admin --role administrator`
- Test the server working: `/usr/sbin/velociraptor-v0.6.8-2-linux-amd64 --config ./velociraptor.config.yaml frontend -v`
- If everything is working - stop the server - `Ctrl-C`
- create a script to run the server - `sudo nano start_velo.sh`

```bash
#! /bin/bash
/usr/sbin/velociraptor-v0.6.8-2-linux-amd64 --config /usr/sbin/velociraptor.config.yaml frontend -v
```

- make sure the start script and the config are in `/usr/sbin`
    - `cp ./start_velo.sh /usr/sbin`
    - `cp ./velociraptor.config.yaml /usr/sbin`
- create a systemd service to run Velociraptor - `sudo nano /etc/systemd/system/velociraptor.service`

```bash
[Unit]
Description=Velociraptor Service
After=network.target
StartLimitIntervalSec=0

[Service]
Type=simple
Restart=always
RestartSec=1
User=ubuntu
ExecStart=/bin/bash /usr/sbin/start_velo.sh

[Install]
WantedBy=multi-user.target
```

- reload systemctl daemon - `sudo sytemctl daemon-reload`
- enabled the service - `sudo systemctl enable velociraptor.service`
- reboot the computer to ensure the service is running at startup - `sudo systemctl status velociraptor.service`

## Repackage Velociraptor client package with config

- Get the Windows client - `wget https://github.com/Velocidex/velociraptor/releases/download/v0.6.8-2/velociraptor-v0.6.8-2-windows-amd64.exe`
- Create the client config: `/usr/sbin/velociraptor-v0.6.8-2-linux-amd64 config client > ./client.config.yaml`
- Repackage with the configuration and specify executable name for output: `/usr/sbin/velociraptor-v0.6.8-2-linux-amd64 config repack --exe velociraptor-v0.6.8-2-windows-amd64.exe client.config.yaml client_velociraptor.exe
