# Magnet Response

[Magnet RESPONSE  - Magnet Forensics](https://www.magnetforensics.com/resources/magnet-response/)

## Overview

Magnet RESPONSE is a data capture tool designed to work with Magnet Axiom. This is an easy-to-use acquisition tool that can be provided to a customer on an external device to acquire the data. Analysis of the acquired data can be done using the free Magnet Axiom Examine tool, or the acquired information can be reviewed by an individual outside of Magnet software by other software.

## Steps for Data Acquisition

1. Download the Magnet Response tool from the Magnet Forensics website.
2. Copy the Magnet Response tool to an external device.
    1. This external device must have enough free space to contain the acquired data.
    2. The external device that is formatted with exFAT (this is important to ensure compatibility between different operating systems).
3. Provide the external device to the customer.
4. The customer will run the Magnet Response tool on the target system.
    1. Plug into target computer and run the exe from the external device. Double click `MagnetResponse.exe`. Unclick "Send Diagnostic Data" > click "Agree and Continue"
    2. Minimum data required - case number/reference number, output folder, collection options
    3. Leave Everything Checked except Collect Ransomware Files
    4. Check "Save a copy of files that have file names containing these keywords:" and "Skip Files larger than 500MB"
    5. For output- browse to the capture directory on the USB
    6. "Start Capture"
    7. Identify and collect any error logs
    8. After the acquisition ensure file hashes match
5. The customer will provide the acquired data back to the analyst.

## Data Acquired

Magnet Response will acquire the following data:

### RAM capture

- Magnet dumpit
- microsoft crashdump format
- Magnet RAM capture
- option to grab pagefile.sys after RAM capture

### Volatile Data

- Network connections
- running processes (basic list)
- logged-on users
- scheduled tasks
- ip config
- firewall
- wifi
- windows services
- local user accounts
- windows version details

### Critical System Files

- open dialog to select individual items
- Dropdown - All, All except browser, All except browser and MFT

### Running processes - extended

- save a copy to a zip file

### File collection

- ransomware notes
- scripts
- keywords (collectkeywords.txt)
- skip folders
- file size limits

## Auto Run

If the executable name is changed to include "AutoCapture" it will run automatically. Examples of executables that will autorun when double-clicked.

- `MagnetRESPONSEAutoCapture.exe`
- `MagnetRESPONSEAutoCaptureMinimal.exe`

!!!note "Quick Selections"
    `Autocapture` will acquire **ALL** artifacts available from Magnet Response.  `Autocapture Minimal` will acquire only the baseline artifacts (as configured by Magnet Response).
