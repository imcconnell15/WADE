# Dissect

Dissect is a python suite that extracts data from disk images. It can also run yara scans.