# FTKImager

## Disk Acquisition (Windows)

- Copy FTK Image.exe onto a hard drive.

- Plug USB into target computer. Double click `FTK Imager.exe`.  Follow the steps below to complete acquisition.
    - File
    - Capture Memory
    - Include pagefile
    - Capture Memory
    - File
    - Create Disk Image
    - Logical OR Physical Drive (See note 1)
    - Next
    - Select Drive(Likely C:\\)
    - Finish
    - Add
    - Raw(dd)
    - Next
    - Add Pertinent Case Information
    - Browse To Capture Folder on USB
    - Add Relevant File Name
    - Finish
- After the acquisition ensure file hashes match

!!!note "Note: 1"
    Physical or logical acquisition is determined by the analyst needs. Logical will be faster, but physical will ensure a complete acquisition of the entire drive.
