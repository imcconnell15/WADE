# Autopsy Usage

## YARA Rules

- Autopsy allows the user to run Yara rules against the file system. These rules can be from authors like Florian Roth or custom rules written by the user.
- Within Autopsy to add Yara rules complete the following menu options and select rules to add:
    - Tools
    - Options
    - YaraRuleSets
    - NewSet
    - OpenFolder

!!!note "Note"
    You can add .yar rule sets here. After adding them navigate to the disk in which you want to run them against. Right click on disk> Run ingest modules>Yara Analyzer. You can then chose what rule set to run. If there are any hits, they will populate under Analysis results.

## Hash Sets

- Hash sets work very similar to Yara. Hashes from OSINT or custom hashes can be placed here and ran against the disk imagine.
    - From Autopsy complete the following menu selections:
        - Tools
        - Options
        - Hash Sets
        - New Hash Set
        - Add - choose the hashes - **These need to be MD5 hashes**
    - To run them against the disk- Right click on disk> Run ingest modules> Hash Lookup
    - The user is then able to chose which lists to run against the disk. If there are any matches, they will show up in the Analysis Results.

## Data Artifacts

- **Installed Programs**: This artifact will show what programs were downloaded, when they were downloaded, and where they were downloaded to. It also produces a hash for the file that was downloaded.
- **Metadata**: This artifact produces a trove of metadata from files, including the user, owner, sources, and important date information.
- **Operating System Information**: A valuable tab that gives vital operating system information that can be used for reporting and creating volatility profiles.
- **Recent Documents**: An artifact that provides important information about the most recently open documents and includes the path from where it was executed on the time.
- **Recycle Bin**: Show cases what is in the recycle bin as well as a means to carve those items out of the disk for analysis.
- **Run Programs**: One of the most important artifacts that provides evidence of execution including time, location, and how the program was ran. It also includes an overview of the amount of data sent and received.
- **Shell Bags**: Provides a way to view data enumeration and damage assessments in intrusion cases, removable devices, and encrypted devices or cloud sharing folders. Windows uses Shellbags to store user preferences. This can be a complicated piece to analyze, but the juice is worth the squeeze.
- **USB Device Attached**: This gives detailed information about connected USB devices including time, Device ID, and the device manufacturer.
- **Web Accounts**: Web account information is gathered here, including URL, username, and other important web account information.
- **Web Bookmarks**: Extracted user bookmarks from search engines.
- **Web Cache**: A valuable source of web browser artifacts that shows information like headers and URLs.
- **Web Cookies**: Cookies! This tab gives URL cookies and their values.
- **Web Downloads**: User download artifacts including what was downloaded, where it was downloaded to, and when it was downloaded.
- **Web Form Autofill**: An analyst can use this artifact to find data that is autofill in going to certain websites.
- **Web History**: A vital artifact that shows how a web search was conducted, its contents, what was accessed, and when it was accessed.
- **Web Search**: Similar to web history, but shows exactly what was typed into a search engine.
- **Wireless Networks**: A powerful tool that shows the history of wireless network connectivity and the SSID of that network.

## Tagging

- This provides a way for analysis to work collaboratively on multiple disk imagines. Tagging is done by right clicking on the file or folder of interesting, clicking add file tag, and then choosing which tag appropriately matches the situation.

## Timeline Analysis

- A timeline analysis can be difficult but it is critical to forming an overall understanding of an intrusion. Using the above artifacts can help piece together how a system was accessed, what was done on the system, what was dropped on the system, and can even provide clues into lateral movement.

## Scheduled Tasks
