# Host Hunting

The overall flow of Host Crew activities are:
1. Preparation
2. Tool Setup and Configuration
3. Host Data Acquisition
- disk image
- memory capture
- agents
- scripts
4. Data Ingest
- Dissect script for baseline data
- Timeline generation (plaso)
- Yara scan
- Sigma Scan (Hayabusa)
5. Analysis - prioritized by:
- open cases
- alerts
- hunt plan
6. Document
7. Malware Analysis

Divided into two sections **Tools** and **Methods**.

- **Methods** contains information for conducting investigations and artifacts of interest, some tool usage is covered, but this is high level information.

- **Tools** contains information about setting up the utilities that the teams generally uses and how to use them to perform different actions.
