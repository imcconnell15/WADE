
# 83 N-CPT Hunt Handbook

This guide serves as a resource for building the Purple Safari kit, supplemented by insights gathered from years of mission experience. It is not intended to be a definitive solution, but rather a reference to support and guide a successful Hunt Forward Operation (HFO).


---
# Overview
:octicons-tag-24: 0.4.0

This documentation is divided into five sections:

1. **Setup**: This is a step-by-step guide to building the purple safari kit, from installation of ESXi to laptop configurations and everything in between.
2. **Network**: Cases and examples of network investigations that can be assigned/worked by analyst complete with some example searches.  
3. **Host**: Cases and examples for host investigations.  
4. **Learning Center**: A work-in-progress location for useful information related to hunt.
5. **Ops Managment**: Roles and responsibilities for mission leadership and team members, daily battle rhythm, documentation templates and other useful mission management resources.